/**
 * Initialize TNG Swap Pools
 * Creates liquidity pools for TNG/SOL and TNG/USDC
 */

import * as anchor from '@coral-xyz/anchor'
import { Connection, Keypair, PublicKey } from '@solana/web3.js'
import { 
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  getOrCreateAssociatedTokenAccount,
  mintTo,
  createMint,
  getAssociatedTokenAddress
} from '@solana/spl-token'
import fs from 'fs'
import path from 'path'

// Program ID
const TNG_SWAP_PROGRAM_ID = new PublicKey('FWfcH4Zcp8HztJFqui3wX3AkG9XjV9PoKnNPCgsctSVV')

// Token mints
const TNG_MINT = new PublicKey('FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs')
const SOL_MINT = new PublicKey('So11111111111111111111111111111111111111112') // Wrapped SOL
const USDC_MINT = new PublicKey('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v') // USDC devnet

async function main() {
  console.log(' Initializing TNG Swap Pools...')

  // Setup connection
  const connection = new Connection('https://api.devnet.solana.com', 'confirmed')
  
  // Load sponsor keypair
  const sponsorKeypairPath = path.join(__dirname, '../../../keys/mvp-sponsor-keypair.json')
  if (!fs.existsSync(sponsorKeypairPath)) {
    throw new Error(`Sponsor keypair not found at: ${sponsorKeypairPath}`)
  }
  
  const sponsorKeypair = Keypair.fromSecretKey(
    new Uint8Array(JSON.parse(fs.readFileSync(sponsorKeypairPath, 'utf8')))
  )
  
  console.log(' Sponsor:', sponsorKeypair.publicKey.toBase58())

  // Setup provider and program
  const wallet = new anchor.Wallet(sponsorKeypair)
  const provider = new anchor.AnchorProvider(connection, wallet, {
    commitment: 'confirmed'
  })
  anchor.setProvider(provider)

  // Load program
  const idl = JSON.parse(fs.readFileSync(path.join(__dirname, '../target/idl/tng_swap.json'), 'utf8'))
  const program = new anchor.Program(idl, provider)

  // Initialize TNG/SOL pool
  await initializePool(
    program,
    connection,
    sponsorKeypair,
    TNG_MINT,
    SOL_MINT,
    1_000_000_000_000, // 1,000 TNG
    1_000_000_000,     // 1 SOL
    'TNG/SOL'
  )

  // Initialize TNG/USDC pool
  await initializePool(
    program,
    connection,
    sponsorKeypair,
    TNG_MINT,
    USDC_MINT,
    1_000_000_000_000, // 1,000 TNG
    2_200_000,         // 2.2 USDC (equivalent to ~1 SOL at $98.45 SOL price)
    'TNG/USDC'
  )

  console.log(' All TNG swap pools initialized successfully!')
}

async function initializePool(
  program: anchor.Program,
  connection: Connection,
  authority: Keypair,
  tngMint: PublicKey,
  otherMint: PublicKey,
  initialTngAmount: number,
  initialOtherAmount: number,
  poolName: string
) {
  console.log(`\n Initializing ${poolName} pool...`)

  try {
    // Get swap pool PDA
    const [swapPoolPDA] = PublicKey.findProgramAddressSync(
      [
        Buffer.from('swap_pool'),
        tngMint.toBuffer(),
        otherMint.toBuffer(),
      ],
      TNG_SWAP_PROGRAM_ID
    )

    console.log(' Pool PDA:', swapPoolPDA.toBase58())

    // Check if pool already exists
    try {
      await program.account.swapPool.fetch(swapPoolPDA)
      console.log(` ${poolName} pool already exists, skipping...`)
      return
    } catch {
      // Pool doesn't exist, continue with initialization
    }

    // Create LP mint
    const lpMintKeypair = Keypair.generate()

    // Get vault addresses
    const tngVault = await getAssociatedTokenAddress(tngMint, swapPoolPDA, true)
    const otherVault = await getAssociatedTokenAddress(otherMint, swapPoolPDA, true)

    console.log(' Vault addresses:', {
      tngVault: tngVault.toBase58(),
      otherVault: otherVault.toBase58(),
      lpMint: lpMintKeypair.publicKey.toBase58()
    })

    // Initialize pool
    const tx = await program.methods
      .initializePool(new anchor.BN(initialTngAmount), new anchor.BN(initialOtherAmount))
      .accounts({
        authority: authority.publicKey,
        payer: authority.publicKey,
        swapPool: swapPoolPDA,
        tngMint: tngMint,
        otherMint: otherMint,
        tngVault: tngVault,
        otherVault: otherVault,
        lpMint: lpMintKeypair.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .signers([authority, lpMintKeypair])
      .rpc()

    console.log(` ${poolName} pool initialized:`, {
      signature: tx,
      poolPDA: swapPoolPDA.toBase58(),
      lpMint: lpMintKeypair.publicKey.toBase58(),
      initialTngAmount: `${initialTngAmount / 1e9} TNG`,
      initialOtherAmount: `${initialOtherAmount / (otherMint.equals(SOL_MINT) ? 1e9 : 1e6)} ${poolName.split('/')[1]}`,
      explorer: `https://explorer.solana.com/tx/${tx}?cluster=devnet`
    })

    // Save pool info
    const poolInfo = {
      name: poolName,
      programId: TNG_SWAP_PROGRAM_ID.toBase58(),
      poolPDA: swapPoolPDA.toBase58(),
      tngMint: tngMint.toBase58(),
      otherMint: otherMint.toBase58(),
      lpMint: lpMintKeypair.publicKey.toBase58(),
      tngVault: tngVault.toBase58(),
      otherVault: otherVault.toBase58(),
      initialTngAmount,
      initialOtherAmount,
      signature: tx
    }

    // Save to deployment info
    const deploymentInfoPath = path.join(__dirname, '../../deployment-info.json')
    let deploymentInfo: any = {}
    
    if (fs.existsSync(deploymentInfoPath)) {
      deploymentInfo = JSON.parse(fs.readFileSync(deploymentInfoPath, 'utf8'))
    }
    
    if (!deploymentInfo.tngSwap) {
      deploymentInfo.tngSwap = {}
    }
    
    deploymentInfo.tngSwap[poolName.toLowerCase().replace('/', '_')] = poolInfo
    
    fs.writeFileSync(deploymentInfoPath, JSON.stringify(deploymentInfo, null, 2))
    
    console.log(` Pool info saved to deployment-info.json`)

  } catch (error) {
    console.error(` Failed to initialize ${poolName} pool:`, error)
    throw error
  }
}

main().catch(console.error)
