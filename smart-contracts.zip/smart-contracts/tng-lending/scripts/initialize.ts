import * as anchor from "@coral-xyz/anchor";
import { Program, AnchorProvider, Wallet, BN } from "@coral-xyz/anchor";
import { 
  PublicKey, 
  Keypair, 
  SystemProgram,
  Connection,
  clusterApiUrl
} from "@solana/web3.js";
import {
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  getAssociatedTokenAddress,
} from "@solana/spl-token";
import fs from 'fs';

// Load keypairs
const sponsorKeypair = Keypair.fromSecretKey(
  new Uint8Array(JSON.parse(fs.readFileSync('../../keys/mvp-sponsor-keypair.json', 'utf-8')))
);

// Token mint addresses
const TNG_MINT = new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs");

async function initialize() {
  // Configure the client to use the devnet cluster
  const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
  const wallet = new Wallet(sponsorKeypair);
  const provider = new AnchorProvider(connection, wallet, {
    commitment: "confirmed",
  });
  anchor.setProvider(provider);

  // Load program
  const idl = JSON.parse(fs.readFileSync('./target/idl/tng_lending.json', 'utf-8'));
  const program = new Program(idl, provider);

  console.log(" Initializing TNG Lending Pool...");
  console.log(" Program ID:", program.programId.toString());
  console.log(" Authority:", sponsorKeypair.publicKey.toString());
  console.log(" Asset Mint (TNG):", TNG_MINT.toString());

  // Find PDA for lending pool
  const [lendingPoolPda, bump] = PublicKey.findProgramAddressSync(
    [Buffer.from("lending_pool"), TNG_MINT.toBuffer()],
    program.programId
  );

  console.log(" Lending Pool PDA:", lendingPoolPda.toString());
  console.log(" Bump:", bump);

  // Find vault PDA
  const vault = await getAssociatedTokenAddress(
    TNG_MINT,
    lendingPoolPda,
    true
  );

  console.log(" Vault:", vault.toString());

  // Create liquidity mint keypair
  const liquidityMintKeypair = Keypair.generate();
  console.log(" Liquidity Mint:", liquidityMintKeypair.publicKey.toString());

  try {
    // Check if already initialized
    console.log(" Proceeding with TNG Lending initialization...");

    // Initialize the lending pool
    const optimalUtilizationRate = new BN(8000); // 80% in basis points
    const maxBorrowRate = new BN(3000); // 30% APR in basis points
    const baseBorrowRate = new BN(500); // 5% APR in basis points
    const liquidationThreshold = new BN(8500); // 85% in basis points
    const liquidationBonus = new BN(500); // 5% bonus in basis points
    const reserveFactor = new BN(1000); // 10% in basis points

    const tx = await program.methods
      .initializePool(
        optimalUtilizationRate,
        maxBorrowRate,
        baseBorrowRate,
        liquidationThreshold,
        liquidationBonus,
        reserveFactor
      )
      .accounts({
        authority: sponsorKeypair.publicKey,
        payer: sponsorKeypair.publicKey,
        lendingPool: lendingPoolPda,
        assetMint: TNG_MINT,
        vault: vault,
        liquidityMint: liquidityMintKeypair.publicKey,
        liquidityMintKeypair: liquidityMintKeypair.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      })
      .signers([sponsorKeypair, liquidityMintKeypair])
      .rpc();

    console.log(" Lending pool initialized!");
    console.log(" Transaction signature:", tx);
    console.log(" Explorer:", `https://explorer.solana.com/tx/${tx}?cluster=devnet`);

    console.log(" Lending pool configuration created successfully!");

    // Save deployment info
    const deploymentInfo = {
      network: "devnet",
      programId: program.programId.toString(),
      lendingPool: lendingPoolPda.toString(),
      vault: vault.toString(),
      liquidityMint: liquidityMintKeypair.publicKey.toString(),
      bump: bump,
      timestamp: new Date().toISOString(),
      txSignature: tx
    };

    fs.writeFileSync('./deployment-info.json', JSON.stringify(deploymentInfo, null, 2));
    console.log(" Deployment info saved to deployment-info.json");

  } catch (error) {
    console.error(" Error initializing lending pool:", error);
    throw error;
  }
}

initialize()
  .then(() => {
    console.log(" TNG Lending initialization completed!");
    process.exit(0);
  })
  .catch((error) => {
    console.error(" Initialization failed:", error);
    process.exit(1);
  });