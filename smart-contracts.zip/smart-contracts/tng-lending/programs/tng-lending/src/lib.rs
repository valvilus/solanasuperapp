/**
 * TNG Lending - Supply and Borrow Protocol
 * Supports: SOL, TNG, USDC, USDT lending and borrowing
 * Features: Collateral, Liquidation, Dynamic Interest Rates
 * Solana SuperApp
 */

use anchor_lang::prelude::*;
use anchor_spl::{
    associated_token::AssociatedToken,
    token::{self, Mint, Token, TokenAccount, Transfer, MintTo, Burn},
};
use std::mem::size_of;

declare_id!("BuHFovMPpwNbRjzhXTJsiJ3BBqDycpTN8mrw2Ho8bjq4");

// Constants
const BASIS_POINTS: u64 = 10000;
const SECONDS_PER_YEAR: u64 = 31_536_000;
const LIQUIDATION_THRESHOLD: u64 = 8500; // 85% 
const LIQUIDATION_BONUS: u64 = 500; // 5% bonus for liquidators

#[program]
pub mod tng_lending {
    use super::*;

    /// Initialize a new lending pool
    pub fn initialize_pool(
        ctx: Context<InitializePool>,
        optimal_utilization_rate: u64, // basis points (e.g., 8000 = 80%)
        max_borrow_rate: u64, // basis points per year
        base_borrow_rate: u64, // basis points per year  
        liquidation_threshold: u64, // basis points
        liquidation_bonus: u64, // basis points
        reserve_factor: u64, // basis points
    ) -> Result<()> {
        let pool = &mut ctx.accounts.lending_pool;
        
        pool.authority = ctx.accounts.authority.key();
        pool.asset_mint = ctx.accounts.asset_mint.key();
        pool.vault = ctx.accounts.vault.key();
        pool.liquidity_mint = ctx.accounts.liquidity_mint.key();
        
        // Pool parameters
        pool.optimal_utilization_rate = optimal_utilization_rate;
        pool.max_borrow_rate = max_borrow_rate;
        pool.base_borrow_rate = base_borrow_rate;
        pool.liquidation_threshold = liquidation_threshold;
        pool.liquidation_bonus = liquidation_bonus;
        pool.reserve_factor = reserve_factor;
        
        // Initialize state
        pool.total_supply = 0;
        pool.total_borrows = 0;
        pool.total_reserves = 0;
        pool.last_update_timestamp = Clock::get()?.unix_timestamp;
        pool.supply_rate = 0;
        pool.borrow_rate = base_borrow_rate;
        pool.liquidity_cumulative_index = 1_000_000_000; // 1.0 in 9 decimals
        pool.borrow_cumulative_index = 1_000_000_000;
        pool.bump = ctx.bumps.lending_pool;
        
        msg!("Lending pool initialized for asset: {}", ctx.accounts.asset_mint.key());
        msg!("Optimal utilization: {}%", optimal_utilization_rate / 100);
        msg!("Base borrow rate: {}%", base_borrow_rate / 100);

        Ok(())
    }

    /// Supply assets to earn interest
    pub fn supply(
        ctx: Context<Supply>,
        amount: u64,
    ) -> Result<()> {
        msg!("Supplying {} tokens to pool", amount);
        
        require!(amount > 0, LendingError::InvalidAmount);
        
        // Get immutable references first
        let asset_mint_key = ctx.accounts.lending_pool.asset_mint;
        let pool_bump = ctx.accounts.lending_pool.bump;
        let lending_pool_key = ctx.accounts.lending_pool.key();
        let lending_pool_info = ctx.accounts.lending_pool.to_account_info();
        
        // Now get mutable references
        let pool = &mut ctx.accounts.lending_pool;
        let user_account = &mut ctx.accounts.user_account;
        
        // Initialize user account if needed
        if user_account.owner == Pubkey::default() {
            user_account.owner = ctx.accounts.user.key();
            user_account.pool = lending_pool_key;
            user_account.supplied_amount = 0;
            user_account.borrowed_amount = 0;
            user_account.liquidity_tokens = 0;
            user_account.last_supply_timestamp = 0;
            user_account.last_borrow_timestamp = 0;
            user_account.nft_collateral_count = 0;
        }
        
        // Update interest rates
        update_interest_rates(pool)?;
        
        // Calculate liquidity tokens to mint
        let liquidity_tokens = if pool.total_supply == 0 {
            amount // 1:1 for first deposit
        } else {
            // liquidity_tokens = amount * total_liquidity_supply / total_supply
            (amount as u128)
                .checked_mul(ctx.accounts.liquidity_mint.supply as u128)
                .ok_or(LendingError::MathOverflow)?
                .checked_div(pool.total_supply as u128)
                .ok_or(LendingError::MathOverflow)? as u64
        };
        
        require!(liquidity_tokens > 0, LendingError::InsufficientLiquidity);
        
        // Transfer tokens from user to vault
        token::transfer(
            CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                    from: ctx.accounts.user_token_account.to_account_info(),
                    to: ctx.accounts.vault.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
            ),
            amount,
        )?;
        
        // Mint liquidity tokens to user
        let seeds = &[
            b"lending_pool",
            asset_mint_key.as_ref(),
            &[pool_bump],
        ];
        let signer = &[&seeds[..]];

        token::mint_to(
            CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            MintTo {
                    mint: ctx.accounts.liquidity_mint.to_account_info(),
                    to: ctx.accounts.user_liquidity_account.to_account_info(),
                    authority: lending_pool_info,
            },
            signer,
            ),
            liquidity_tokens,
        )?;
        
        // Update pool state
        pool.total_supply = pool.total_supply.checked_add(amount).ok_or(LendingError::MathOverflow)?;
        
        // Update user account
        user_account.supplied_amount = user_account.supplied_amount.checked_add(amount).ok_or(LendingError::MathOverflow)?;
        user_account.liquidity_tokens = user_account.liquidity_tokens.checked_add(liquidity_tokens).ok_or(LendingError::MathOverflow)?;
        user_account.last_supply_timestamp = Clock::get()?.unix_timestamp;
        
        msg!("Supplied {} tokens, minted {} liquidity tokens", amount, liquidity_tokens);

        Ok(())
    }

    /// Withdraw supplied assets
    pub fn withdraw(
        ctx: Context<Withdraw>,
        liquidity_amount: u64,
    ) -> Result<()> {
        msg!("Withdrawing {} liquidity tokens", liquidity_amount);
        
        require!(liquidity_amount > 0, LendingError::InvalidAmount);
        
        // Get immutable references first
        let asset_mint_key = ctx.accounts.lending_pool.asset_mint;
        let pool_bump = ctx.accounts.lending_pool.bump;
        let lending_pool_info = ctx.accounts.lending_pool.to_account_info();
        
        // Now get mutable references
        let pool = &mut ctx.accounts.lending_pool;
        let user_account = &mut ctx.accounts.user_account;
        
        require!(user_account.liquidity_tokens >= liquidity_amount, LendingError::InsufficientBalance);
        
        // Update interest rates
        update_interest_rates(pool)?;
        
        // Calculate underlying tokens to withdraw
        let withdraw_amount = (liquidity_amount as u128)
            .checked_mul(pool.total_supply as u128)
            .ok_or(LendingError::MathOverflow)?
            .checked_div(ctx.accounts.liquidity_mint.supply as u128)
            .ok_or(LendingError::MathOverflow)? as u64;
        
        require!(withdraw_amount <= pool.total_supply, LendingError::InsufficientLiquidity);
        
        // Check if user has outstanding borrows that would make them undercollateralized
        if user_account.borrowed_amount > 0 {
            let remaining_collateral_value = calculate_collateral_value(
                user_account.supplied_amount.checked_sub(withdraw_amount).ok_or(LendingError::MathOverflow)?,
                pool.liquidation_threshold,
            )?;
            
            require!(
                remaining_collateral_value >= user_account.borrowed_amount,
                LendingError::InsufficientCollateral
            );
        }
        
        // Burn liquidity tokens
        token::burn(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Burn {
                    mint: ctx.accounts.liquidity_mint.to_account_info(),
                    from: ctx.accounts.user_liquidity_account.to_account_info(),
                    authority: ctx.accounts.user.to_account_info(),
                },
            ),
            liquidity_amount,
        )?;
        
        // Transfer tokens from vault to user
        let seeds = &[
            b"lending_pool",
            asset_mint_key.as_ref(),
            &[pool_bump],
        ];
        let signer = &[&seeds[..]];
        
        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.vault.to_account_info(),
                    to: ctx.accounts.user_token_account.to_account_info(),
                    authority: lending_pool_info,
                },
                signer,
            ),
            withdraw_amount,
        )?;
        
        // Update pool state  
        pool.total_supply = pool.total_supply.checked_sub(withdraw_amount).ok_or(LendingError::MathOverflow)?;
        
        // Update user account
        user_account.supplied_amount = user_account.supplied_amount.checked_sub(withdraw_amount).ok_or(LendingError::MathOverflow)?;
        user_account.liquidity_tokens = user_account.liquidity_tokens.checked_sub(liquidity_amount).ok_or(LendingError::MathOverflow)?;
        
        msg!("Withdrew {} tokens by burning {} liquidity tokens", withdraw_amount, liquidity_amount);
        
        Ok(())
    }

    /// Borrow assets against collateral
    pub fn borrow(
        ctx: Context<Borrow>,
        amount: u64,
    ) -> Result<()> {
        msg!("Borrowing {} tokens", amount);
        
        require!(amount > 0, LendingError::InvalidAmount);
        
        // Get immutable references first
        let asset_mint_key = ctx.accounts.lending_pool.asset_mint;
        let pool_bump = ctx.accounts.lending_pool.bump;
        let lending_pool_key = ctx.accounts.lending_pool.key();
        let lending_pool_info = ctx.accounts.lending_pool.to_account_info();
        
        // Now get mutable references
        let pool = &mut ctx.accounts.lending_pool;
        let user_account = &mut ctx.accounts.user_account;
        
        // Initialize user account if needed
        if user_account.owner == Pubkey::default() {
            user_account.owner = ctx.accounts.user.key();
            user_account.pool = lending_pool_key;
            user_account.supplied_amount = 0;
            user_account.borrowed_amount = 0;
            user_account.liquidity_tokens = 0;
            user_account.last_supply_timestamp = 0;
            user_account.last_borrow_timestamp = 0;
            user_account.nft_collateral_count = 0;
        }
        
        require!(amount <= pool.total_supply, LendingError::InsufficientLiquidity);
        
        // Update interest rates
        update_interest_rates(pool)?;
        
        // Check collateral (tokens + NFTs)
        let token_collateral_value = calculate_collateral_value(
            user_account.supplied_amount,
            pool.liquidation_threshold,
        )?;
        
        // Calculate NFT collateral value (simplified - assume fixed value per NFT)
        let nft_collateral_value: u64 = (user_account.nft_collateral_count as u64) * 1000; // 1000 tokens per NFT
        
        let total_collateral_value = token_collateral_value + nft_collateral_value;
        let new_borrowed_amount = user_account.borrowed_amount.checked_add(amount).ok_or(LendingError::MathOverflow)?;
        
        require!(
            total_collateral_value >= new_borrowed_amount,
            LendingError::InsufficientCollateral
        );
        
        // Transfer tokens from vault to user
        let seeds = &[
            b"lending_pool",
            asset_mint_key.as_ref(),
            &[pool_bump],
        ];
        let signer = &[&seeds[..]];
        
        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.vault.to_account_info(),
                    to: ctx.accounts.user_token_account.to_account_info(),
                    authority: lending_pool_info,
                },
                signer,
            ),
            amount,
        )?;
        
        // Update pool state
        pool.total_borrows = pool.total_borrows.checked_add(amount).ok_or(LendingError::MathOverflow)?;
        
        // Update user account
        user_account.borrowed_amount = new_borrowed_amount;
        user_account.last_borrow_timestamp = Clock::get()?.unix_timestamp;
        
        msg!("Borrowed {} tokens, total borrowed: {}", amount, new_borrowed_amount);
        
        Ok(())
    }

    /// Repay borrowed assets
    pub fn repay(
        ctx: Context<Repay>,
        amount: u64,
    ) -> Result<()> {
        let pool = &mut ctx.accounts.lending_pool;
        let user_account = &mut ctx.accounts.user_account;
        
        msg!("Repaying {} tokens", amount);
        
        require!(amount > 0, LendingError::InvalidAmount);
        
        // Update interest rates
        update_interest_rates(pool)?;
        
        // Calculate actual repay amount (can't repay more than borrowed)
        let repay_amount = std::cmp::min(amount, user_account.borrowed_amount);
        
        // Transfer tokens from user to vault
        token::transfer(
            CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                    from: ctx.accounts.user_token_account.to_account_info(),
                    to: ctx.accounts.vault.to_account_info(),
                    authority: ctx.accounts.user.to_account_info(),
                },
            ),
            repay_amount,
        )?;
        
        // Update pool state
        pool.total_borrows = pool.total_borrows.checked_sub(repay_amount).ok_or(LendingError::MathOverflow)?;
        
        // Update user account
        user_account.borrowed_amount = user_account.borrowed_amount.checked_sub(repay_amount).ok_or(LendingError::MathOverflow)?;
        
        msg!("Repaid {} tokens, remaining borrowed: {}", repay_amount, user_account.borrowed_amount);

        Ok(())
    }

    /// Liquidate undercollateralized position
    pub fn liquidate(
        ctx: Context<Liquidate>,
        debt_to_cover: u64,
    ) -> Result<()> {
        msg!("Liquidating position, debt to cover: {}", debt_to_cover);
        
        require!(debt_to_cover > 0, LendingError::InvalidAmount);
        
        // Get immutable references first
        let asset_mint_key = ctx.accounts.lending_pool.asset_mint;
        let pool_bump = ctx.accounts.lending_pool.bump;
        let lending_pool_info = ctx.accounts.lending_pool.to_account_info();
        
        // Now get mutable references
        let pool = &mut ctx.accounts.lending_pool;
        let borrower_account = &mut ctx.accounts.borrower_account;
        
        require!(borrower_account.borrowed_amount > 0, LendingError::NothingToLiquidate);
        
        // Update interest rates
        update_interest_rates(pool)?;
        
        // Check if position is liquidatable
        let collateral_value = calculate_collateral_value(
            borrower_account.supplied_amount,
            pool.liquidation_threshold,
        )?;
        
        require!(
            collateral_value < borrower_account.borrowed_amount,
            LendingError::PositionHealthy
        );
        
        // Calculate liquidation amounts
        let actual_debt_to_cover = std::cmp::min(debt_to_cover, borrower_account.borrowed_amount);
        let collateral_to_liquidate = calculate_liquidation_amount(
            actual_debt_to_cover,
            pool.liquidation_bonus,
        )?;
        
        require!(
            collateral_to_liquidate <= borrower_account.supplied_amount,
            LendingError::InsufficientCollateral
        );
        
        // Transfer debt payment from liquidator to vault
        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.liquidator_token_account.to_account_info(),
                    to: ctx.accounts.vault.to_account_info(),
                    authority: ctx.accounts.liquidator.to_account_info(),
                },
            ),
            actual_debt_to_cover,
        )?;
        
        // Transfer collateral from vault to liquidator
        let seeds = &[
            b"lending_pool",
            asset_mint_key.as_ref(),
            &[pool_bump],
        ];
        let signer = &[&seeds[..]];
        
        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.vault.to_account_info(),
                    to: ctx.accounts.liquidator_token_account.to_account_info(),
                    authority: lending_pool_info,
                },
                signer,
            ),
            collateral_to_liquidate,
        )?;
        
        // Update pool state
        pool.total_borrows = pool.total_borrows.checked_sub(actual_debt_to_cover).ok_or(LendingError::MathOverflow)?;
        pool.total_supply = pool.total_supply.checked_sub(collateral_to_liquidate).ok_or(LendingError::MathOverflow)?;
        
        // Update borrower account
        borrower_account.borrowed_amount = borrower_account.borrowed_amount.checked_sub(actual_debt_to_cover).ok_or(LendingError::MathOverflow)?;
        borrower_account.supplied_amount = borrower_account.supplied_amount.checked_sub(collateral_to_liquidate).ok_or(LendingError::MathOverflow)?;
        
        msg!("Liquidated {} debt, seized {} collateral", actual_debt_to_cover, collateral_to_liquidate);
        
        Ok(())
    }

    /// Execute a flash loan - must be repaid within same transaction  
    pub fn flash_loan(
        ctx: Context<FlashLoan>,
        amount: u64,
    ) -> Result<()> {
        msg!("Executing flash loan for {} tokens", amount);
        
        require!(amount > 0, LendingError::InvalidAmount);
        
        let pool = &mut ctx.accounts.lending_pool;
        let flash_loan_state = &mut ctx.accounts.flash_loan_state;
        
        // Check if pool has enough liquidity
        require!(
            ctx.accounts.vault.amount >= amount,
            LendingError::InsufficientLiquidity
        );
        
        // Calculate flash loan fee (0.09% = 9 basis points)
        let fee_amount = (amount as u128 * 9 / BASIS_POINTS as u128) as u64;
        
        // Initialize flash loan state
        flash_loan_state.borrower = ctx.accounts.borrower.key();
        flash_loan_state.amount = amount;
        flash_loan_state.fee = fee_amount;
        flash_loan_state.is_active = true;
        flash_loan_state.callback_program = ctx.accounts.callback_program.key();
        
        // Get pool seeds for signing
        let asset_mint_key = pool.asset_mint;
        let pool_bump = pool.bump;
        let seeds = &[
            b"lending_pool",
            asset_mint_key.as_ref(),
            &[pool_bump],
        ];
        let signer = &[&seeds[..]];
        
        // Transfer tokens to borrower
        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.vault.to_account_info(),
                    to: ctx.accounts.borrower_token_account.to_account_info(),
                    authority: pool.to_account_info(),
                },
                signer,
            ),
            amount,
        )?;
        
        msg!("Flash loan executed successfully. Amount: {}, Fee: {}", amount, fee_amount);
        
        Ok(())
    }


    /// Repay flash loan - called after callback execution
    pub fn repay_flash_loan(
        ctx: Context<RepayFlashLoan>,
    ) -> Result<()> {
        msg!("Repaying flash loan");
        
        let flash_loan_state = &mut ctx.accounts.flash_loan_state;
        let pool = &mut ctx.accounts.lending_pool;
        
        require!(flash_loan_state.is_active, LendingError::FlashLoanNotActive);
        require!(
            flash_loan_state.borrower == ctx.accounts.borrower.key(),
            LendingError::InvalidAmount
        );
        
        let total_repayment = flash_loan_state.amount + flash_loan_state.fee;
        
        // Check borrower has enough tokens for repayment
        require!(
            ctx.accounts.borrower_token_account.amount >= total_repayment,
            LendingError::InsufficientBalance
        );
        
        // Transfer repayment from borrower to vault
        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.borrower_token_account.to_account_info(),
                    to: ctx.accounts.vault.to_account_info(),
                    authority: ctx.accounts.borrower.to_account_info(),
                },
            ),
            total_repayment,
        )?;
        
        // Add fee to reserves
        pool.total_reserves = pool.total_reserves.checked_add(flash_loan_state.fee)
            .ok_or(LendingError::MathOverflow)?;
        
        // Clear flash loan state
        flash_loan_state.is_active = false;
        flash_loan_state.amount = 0;
        flash_loan_state.fee = 0;
        
        msg!("Flash loan repaid successfully, total: {}", total_repayment);
        
        Ok(())
    }

    /// Deposit NFT as collateral
    pub fn deposit_nft_collateral(
        ctx: Context<DepositNftCollateral>,
        appraised_value: u64,
    ) -> Result<()> {
        msg!("Depositing NFT as collateral, appraised value: {}", appraised_value);
        
        let user_account = &mut ctx.accounts.user_account;
        
        // Initialize user account if needed
        if user_account.owner == Pubkey::default() {
            user_account.owner = ctx.accounts.user.key();
            user_account.pool = ctx.accounts.lending_pool.key();
            user_account.supplied_amount = 0;
            user_account.borrowed_amount = 0;
            user_account.liquidity_tokens = 0;
            user_account.last_supply_timestamp = 0;
            user_account.last_borrow_timestamp = 0;
            user_account.nft_collateral_count = 0;
        }
        
        // Transfer NFT to program-controlled account (escrow)
        // This would typically involve Metaplex token metadata program
        // For now, we'll just increment the counter and assume the NFT is held
        user_account.nft_collateral_count = user_account.nft_collateral_count
            .checked_add(1)
            .ok_or(LendingError::MathOverflow)?;
        
        msg!("NFT deposited as collateral, total NFTs: {}", user_account.nft_collateral_count);
        
        Ok(())
    }

    /// Withdraw NFT collateral
    pub fn withdraw_nft_collateral(
        ctx: Context<WithdrawNftCollateral>,
        nft_mint: Pubkey,
    ) -> Result<()> {
        msg!("Withdrawing NFT collateral: {}", nft_mint);
        
        let pool = &ctx.accounts.lending_pool;
        let user_account = &mut ctx.accounts.user_account;
        
        require!(user_account.nft_collateral_count > 0, LendingError::InsufficientCollateral);
        
        // Check if user can withdraw NFT without becoming undercollateralized
        if user_account.borrowed_amount > 0 {
            let remaining_token_collateral = calculate_collateral_value(
                user_account.supplied_amount,
                pool.liquidation_threshold,
            )?;
            
            // Calculate remaining NFT collateral (subtract one NFT)
            let remaining_nft_collateral = ((user_account.nft_collateral_count - 1) as u64) * 1000;
            let total_remaining_collateral = remaining_token_collateral + remaining_nft_collateral;
            
            require!(
                total_remaining_collateral >= user_account.borrowed_amount,
                LendingError::InsufficientCollateral
            );
        }
        
        // Transfer NFT back to user
        // This would typically involve Metaplex token metadata program
        // For now, we'll just decrement the counter
        user_account.nft_collateral_count = user_account.nft_collateral_count
            .checked_sub(1)
            .ok_or(LendingError::MathOverflow)?;
        
        msg!("NFT withdrawn, remaining NFTs: {}", user_account.nft_collateral_count);
        
        Ok(())
    }

    pub fn get_oracle_price(
        ctx: Context<GetOraclePrice>,
        asset_mint: Pubkey,
    ) -> Result<u64> {
        let oracle_price_feed = &ctx.accounts.oracle_price_feed;
        
        require!(oracle_price_feed.owner == &crate::ID, LendingError::InvalidOracle);
        
        let data = oracle_price_feed.try_borrow_data()?;
        if data.len() < 8 + 32 + 32 + 8 + 8 + 1 + 8 + 1 {
            return Err(LendingError::InvalidOracleData.into());
        }

        let asset_mint_bytes = &data[40..72];
        let stored_mint = Pubkey::new_from_array(asset_mint_bytes.try_into().unwrap());
        require!(stored_mint == asset_mint, LendingError::InvalidAsset);

        let is_active = data[89] == 1;
        require!(is_active, LendingError::PriceFeedInactive);

        let last_updated = i64::from_le_bytes(data[81..89].try_into().unwrap());
        let current_time = Clock::get()?.unix_timestamp;
        let age = current_time - last_updated;
        require!(age < 300, LendingError::PriceStale);

        let price = u64::from_le_bytes(data[73..81].try_into().unwrap());
        Ok(price)
    }

    pub fn liquidate_with_oracle(
        ctx: Context<LiquidateWithOracle>,
        debt_to_cover: u64,
    ) -> Result<()> {
        let lending_pool = &mut ctx.accounts.lending_pool;
        let user_account = &mut ctx.accounts.user_account;
        let liquidator_account = &mut ctx.accounts.liquidator_account;
        
        require!(user_account.borrowed_amount > 0, LendingError::NoDebtToLiquidate);
        require!(debt_to_cover > 0, LendingError::InvalidAmount);
        require!(debt_to_cover <= user_account.borrowed_amount, LendingError::ExcessiveDebtCover);

        let collateral_oracle_data = ctx.accounts.collateral_oracle.try_borrow_data()?;
        let debt_oracle_data = ctx.accounts.debt_oracle.try_borrow_data()?;

        let collateral_price = u64::from_le_bytes(collateral_oracle_data[73..81].try_into().unwrap());
        let debt_price = u64::from_le_bytes(debt_oracle_data[73..81].try_into().unwrap());
        
        let collateral_value = (user_account.supplied_amount as u128)
            .checked_mul(collateral_price as u128)
            .ok_or(LendingError::MathOverflow)?;
            
        let debt_value = (user_account.borrowed_amount as u128)
            .checked_mul(debt_price as u128)
            .ok_or(LendingError::MathOverflow)?;

        let health_factor = collateral_value
            .checked_mul(LIQUIDATION_THRESHOLD as u128)
            .ok_or(LendingError::MathOverflow)?
            .checked_div(debt_value)
            .ok_or(LendingError::MathOverflow)?
            .checked_div(BASIS_POINTS as u128)
            .ok_or(LendingError::MathOverflow)?;

        require!(health_factor < BASIS_POINTS as u128, LendingError::HealthyPosition);

        let collateral_to_liquidate = (debt_to_cover as u128)
            .checked_mul(debt_price as u128)
            .ok_or(LendingError::MathOverflow)?
            .checked_mul((BASIS_POINTS + LIQUIDATION_BONUS) as u128)
            .ok_or(LendingError::MathOverflow)?
            .checked_div(BASIS_POINTS as u128)
            .ok_or(LendingError::MathOverflow)?
            .checked_div(collateral_price as u128)
            .ok_or(LendingError::MathOverflow)? as u64;

        require!(
            collateral_to_liquidate <= user_account.supplied_amount,
            LendingError::InsufficientCollateral
        );

        user_account.borrowed_amount = user_account.borrowed_amount
            .checked_sub(debt_to_cover)
            .ok_or(LendingError::MathOverflow)?;
            
        user_account.supplied_amount = user_account.supplied_amount
            .checked_sub(collateral_to_liquidate)
            .ok_or(LendingError::MathOverflow)?;

        liquidator_account.supplied_amount = liquidator_account
            .supplied_amount
            .checked_add(collateral_to_liquidate)
            .ok_or(LendingError::MathOverflow)?;

        lending_pool.total_borrows = lending_pool.total_borrows
            .checked_sub(debt_to_cover)
            .ok_or(LendingError::MathOverflow)?;

        Ok(())
    }

    pub fn create_loan_request(
        ctx: Context<CreateLoanRequest>,
        amount: u64,
        interest_rate: u64,
        duration: i64,
        collateral_type: CollateralType,
        collateral_amount: u64,
    ) -> Result<()> {
        require!(amount > 0, LendingError::InvalidAmount);
        require!(interest_rate > 0, LendingError::InvalidInterestRate);
        require!(duration > 0, LendingError::InvalidDuration);
        require!(collateral_amount > 0, LendingError::InvalidCollateralAmount);

        let loan_request = &mut ctx.accounts.loan_request;
        loan_request.request_id = Clock::get()?.unix_timestamp as u64;
        loan_request.borrower = ctx.accounts.borrower.key();
        loan_request.amount = amount;
        loan_request.interest_rate = interest_rate;
        loan_request.duration = duration;
        loan_request.collateral_type = collateral_type;
        loan_request.collateral_amount = collateral_amount;
        loan_request.status = LoanRequestStatus::Open;
        loan_request.created_at = Clock::get()?.unix_timestamp;
        loan_request.bump = ctx.bumps.loan_request;

        Ok(())
    }

    pub fn fulfill_loan_request(
        ctx: Context<FulfillLoanRequest>,
        request_id: u64,
    ) -> Result<()> {
        let loan_request = &mut ctx.accounts.loan_request;
        let p2p_loan = &mut ctx.accounts.p2p_loan;

        require!(loan_request.status == LoanRequestStatus::Open, LendingError::RequestNotOpen);
        require!(loan_request.request_id == request_id, LendingError::InvalidRequestId);

        let current_time = Clock::get()?.unix_timestamp;
        
        p2p_loan.loan_id = Clock::get()?.unix_timestamp as u64;
        p2p_loan.borrower = loan_request.borrower;
        p2p_loan.lender = ctx.accounts.lender.key();
        p2p_loan.amount = loan_request.amount;
        p2p_loan.interest_rate = loan_request.interest_rate;
        p2p_loan.start_time = current_time;
        p2p_loan.end_time = current_time + loan_request.duration;
        p2p_loan.repaid_amount = 0;
        p2p_loan.collateral_amount = loan_request.collateral_amount;
        p2p_loan.collateral_type = loan_request.collateral_type.clone();
        p2p_loan.status = LoanStatus::Active;
        p2p_loan.bump = ctx.bumps.p2p_loan;

        loan_request.status = LoanRequestStatus::Fulfilled;

        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            anchor_spl::token::Transfer {
                from: ctx.accounts.lender_token_account.to_account_info(),
                to: ctx.accounts.borrower_token_account.to_account_info(),
                authority: ctx.accounts.lender.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_ctx, loan_request.amount)?;

        Ok(())
    }

    pub fn repay_p2p_loan(
        ctx: Context<RepayP2PLoan>,
        loan_id: u64,
        amount: u64,
    ) -> Result<()> {
        let p2p_loan = &mut ctx.accounts.p2p_loan;

        require!(p2p_loan.status == LoanStatus::Active, LendingError::LoanNotActive);
        require!(p2p_loan.loan_id == loan_id, LendingError::InvalidLoanId);
        require!(amount > 0, LendingError::InvalidAmount);

        let current_time = Clock::get()?.unix_timestamp;
        let time_elapsed = current_time - p2p_loan.start_time;
        
        let interest_amount = (p2p_loan.amount as u128)
            .checked_mul(p2p_loan.interest_rate as u128)
            .ok_or(LendingError::MathOverflow)?
            .checked_mul(time_elapsed as u128)
            .ok_or(LendingError::MathOverflow)?
            .checked_div(SECONDS_PER_YEAR as u128)
            .ok_or(LendingError::MathOverflow)?
            .checked_div(BASIS_POINTS as u128)
            .ok_or(LendingError::MathOverflow)? as u64;

        let total_due = p2p_loan.amount
            .checked_add(interest_amount)
            .ok_or(LendingError::MathOverflow)?
            .checked_sub(p2p_loan.repaid_amount)
            .ok_or(LendingError::MathOverflow)?;

        require!(amount <= total_due, LendingError::ExcessiveRepayment);

        p2p_loan.repaid_amount = p2p_loan.repaid_amount
            .checked_add(amount)
            .ok_or(LendingError::MathOverflow)?;

        if p2p_loan.repaid_amount >= p2p_loan.amount.checked_add(interest_amount).ok_or(LendingError::MathOverflow)? {
            p2p_loan.status = LoanStatus::Repaid;
        }

        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            anchor_spl::token::Transfer {
                from: ctx.accounts.borrower_token_account.to_account_info(),
                to: ctx.accounts.lender_token_account.to_account_info(),
                authority: ctx.accounts.borrower.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_ctx, amount)?;

        Ok(())
    }

    pub fn liquidate_p2p_loan(
        ctx: Context<LiquidateP2PLoan>,
        loan_id: u64,
    ) -> Result<()> {
        let p2p_loan = &mut ctx.accounts.p2p_loan;

        require!(p2p_loan.status == LoanStatus::Active, LendingError::LoanNotActive);
        require!(p2p_loan.loan_id == loan_id, LendingError::InvalidLoanId);

        let current_time = Clock::get()?.unix_timestamp;
        require!(current_time > p2p_loan.end_time, LendingError::LoanNotExpired);

        let interest_amount = (p2p_loan.amount as u128)
            .checked_mul(p2p_loan.interest_rate as u128)
            .ok_or(LendingError::MathOverflow)?
            .checked_mul((p2p_loan.end_time - p2p_loan.start_time) as u128)
            .ok_or(LendingError::MathOverflow)?
            .checked_div(SECONDS_PER_YEAR as u128)
            .ok_or(LendingError::MathOverflow)?
            .checked_div(BASIS_POINTS as u128)
            .ok_or(LendingError::MathOverflow)? as u64;

        let total_due = p2p_loan.amount
            .checked_add(interest_amount)
            .ok_or(LendingError::MathOverflow)?;

        let remaining_debt = total_due
            .checked_sub(p2p_loan.repaid_amount)
            .ok_or(LendingError::MathOverflow)?;

        require!(remaining_debt > 0, LendingError::LoanAlreadyRepaid);

        p2p_loan.status = LoanStatus::Liquidated;

        let liquidation_amount = if p2p_loan.collateral_amount >= remaining_debt {
            remaining_debt
        } else {
            p2p_loan.collateral_amount
        };

        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            anchor_spl::token::Transfer {
                from: ctx.accounts.collateral_vault.to_account_info(),
                to: ctx.accounts.lender_token_account.to_account_info(),
                authority: ctx.accounts.vault_authority.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_ctx, liquidation_amount)?;

        Ok(())
    }
}

// Helper functions
fn update_interest_rates(pool: &mut LendingPool) -> Result<()> {
    let current_time = Clock::get()?.unix_timestamp;
    let time_elapsed = current_time - pool.last_update_timestamp;
    
    if time_elapsed > 0 {
        // Calculate utilization rate
        let utilization_rate = if pool.total_supply > 0 {
            (pool.total_borrows as u128 * BASIS_POINTS as u128) / pool.total_supply as u128
        } else {
            0
        };
        
        // Calculate new borrow rate
        let new_borrow_rate = if utilization_rate <= pool.optimal_utilization_rate as u128 {
            // Linear interpolation from base to optimal rate
            let rate_slope = (pool.max_borrow_rate - pool.base_borrow_rate) * utilization_rate as u64 / pool.optimal_utilization_rate;
            pool.base_borrow_rate + rate_slope
        } else {
            // Steep increase after optimal utilization
            let excess_utilization = utilization_rate - pool.optimal_utilization_rate as u128;
            let steep_slope = (pool.max_borrow_rate - pool.base_borrow_rate) * 2; // 2x steeper
            pool.base_borrow_rate + steep_slope + (steep_slope * excess_utilization as u64 / BASIS_POINTS)
        };
        
        // Calculate supply rate (borrow rate * utilization * (1 - reserve factor))
        let new_supply_rate = (new_borrow_rate as u128 * utilization_rate * (BASIS_POINTS - pool.reserve_factor) as u128) 
            / (BASIS_POINTS as u128 * BASIS_POINTS as u128);
        
        pool.borrow_rate = new_borrow_rate;
        pool.supply_rate = new_supply_rate as u64;
        pool.last_update_timestamp = current_time;
    }
    
    Ok(())
}

fn calculate_collateral_value(supplied_amount: u64, liquidation_threshold: u64) -> Result<u64> {
    Ok((supplied_amount as u128 * liquidation_threshold as u128 / BASIS_POINTS as u128) as u64)
}

fn calculate_liquidation_amount(debt_amount: u64, liquidation_bonus: u64) -> Result<u64> {
    Ok((debt_amount as u128 * (BASIS_POINTS + liquidation_bonus) as u128 / BASIS_POINTS as u128) as u64)
}

// Error types
#[error_code]
pub enum LendingError {
    #[msg("Invalid amount")]
    InvalidAmount,
    #[msg("Insufficient balance")]
    InsufficientBalance,
    #[msg("Insufficient liquidity")]
    InsufficientLiquidity,
    #[msg("Insufficient collateral")]
    InsufficientCollateral,
    #[msg("Math overflow")]
    MathOverflow,
    #[msg("Nothing to liquidate")]
    NothingToLiquidate,
    #[msg("Position is healthy")]
    PositionHealthy,
    #[msg("Flash loan not active")]
    FlashLoanNotActive,
    #[msg("Flash loan callback failed")]
    FlashLoanCallbackFailed,
    #[msg("Invalid oracle")]
    InvalidOracle,
    #[msg("Invalid oracle data")]
    InvalidOracleData,
    #[msg("Invalid asset")]
    InvalidAsset,
    #[msg("Price feed inactive")]
    PriceFeedInactive,
    #[msg("Price data is stale")]
    PriceStale,
    #[msg("No debt to liquidate")]
    NoDebtToLiquidate,
    #[msg("Excessive debt cover")]
    ExcessiveDebtCover,
    #[msg("Healthy position")]
    HealthyPosition,
    #[msg("Invalid interest rate")]
    InvalidInterestRate,
    #[msg("Invalid duration")]
    InvalidDuration,
    #[msg("Invalid collateral amount")]
    InvalidCollateralAmount,
    #[msg("Request not open")]
    RequestNotOpen,
    #[msg("Invalid request ID")]
    InvalidRequestId,
    #[msg("Loan not active")]
    LoanNotActive,
    #[msg("Invalid loan ID")]
    InvalidLoanId,
    #[msg("Excessive repayment")]
    ExcessiveRepayment,
    #[msg("Loan not expired")]
    LoanNotExpired,
    #[msg("Loan already repaid")]
    LoanAlreadyRepaid,
}

// Account structures
#[account]
pub struct LendingPool {
    pub authority: Pubkey,
    pub asset_mint: Pubkey,
    pub vault: Pubkey,
    pub liquidity_mint: Pubkey,
    
    // Pool parameters
    pub optimal_utilization_rate: u64, // basis points
    pub max_borrow_rate: u64,         // basis points per year
    pub base_borrow_rate: u64,        // basis points per year
    pub liquidation_threshold: u64,   // basis points
    pub liquidation_bonus: u64,       // basis points
    pub reserve_factor: u64,          // basis points
    
    // Pool state
    pub total_supply: u64,
    pub total_borrows: u64,
    pub total_reserves: u64,
    pub last_update_timestamp: i64,
    pub supply_rate: u64,             // basis points per year
    pub borrow_rate: u64,             // basis points per year
    pub liquidity_cumulative_index: u64,
    pub borrow_cumulative_index: u64,
    pub bump: u8,
}

#[account]
pub struct UserAccount {
    pub owner: Pubkey,
    pub pool: Pubkey,
    pub supplied_amount: u64,
    pub borrowed_amount: u64,
    pub liquidity_tokens: u64,
    pub last_supply_timestamp: i64,
    pub last_borrow_timestamp: i64,
    // NEW: NFT collateral support (simplified - store count only)
    pub nft_collateral_count: u32,
}


#[account]
pub struct FlashLoanState {
    pub borrower: Pubkey,
    pub amount: u64,
    pub fee: u64,
    pub is_active: bool,
    pub callback_program: Pubkey,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub enum CollateralType {
    Token,
    Nft,
    LpToken,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq)]
pub enum LoanRequestStatus {
    Open,
    Fulfilled,
    Cancelled,
    Expired,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq)]
pub enum LoanStatus {
    Active,
    Repaid,
    Defaulted,
    Liquidated,
}

#[account]
pub struct LoanRequest {
    pub request_id: u64,
    pub borrower: Pubkey,
    pub amount: u64,
    pub interest_rate: u64,
    pub duration: i64,
    pub collateral_type: CollateralType,
    pub collateral_amount: u64,
    pub status: LoanRequestStatus,
    pub created_at: i64,
    pub bump: u8,
}

#[account]
pub struct P2PLoan {
    pub loan_id: u64,
    pub borrower: Pubkey,
    pub lender: Pubkey,
    pub amount: u64,
    pub interest_rate: u64,
    pub start_time: i64,
    pub end_time: i64,
    pub repaid_amount: u64,
    pub collateral_amount: u64,
    pub collateral_type: CollateralType,
    pub status: LoanStatus,
    pub bump: u8,
}

// Account Contexts
#[derive(Accounts)]
pub struct InitializePool<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,

    #[account(mut)]
    pub payer: Signer<'info>,

    #[account(
        init,
        payer = payer,
        space = 8 + size_of::<LendingPool>(),
        seeds = [b"lending_pool", asset_mint.key().as_ref()],
        bump
    )]
    pub lending_pool: Account<'info, LendingPool>,

    pub asset_mint: Account<'info, Mint>,

    #[account(
        init,
        payer = payer,
        associated_token::mint = asset_mint,
        associated_token::authority = lending_pool,
    )]
    pub vault: Account<'info, TokenAccount>,

    #[account(
        init,
        payer = payer,
        mint::decimals = asset_mint.decimals,
        mint::authority = lending_pool,
    )]
    pub liquidity_mint: Account<'info, Mint>,
    
    pub liquidity_mint_keypair: Signer<'info>,
    
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Supply<'info> {
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(mut)]
    pub payer: Signer<'info>,

    #[account(
        mut,
        seeds = [b"lending_pool", lending_pool.asset_mint.as_ref()],
        bump = lending_pool.bump
    )]
    pub lending_pool: Account<'info, LendingPool>,
    
    #[account(
        init_if_needed,
        payer = payer,
        space = 8 + size_of::<UserAccount>(),
        seeds = [b"user_account", user.key().as_ref(), lending_pool.key().as_ref()],
        bump
    )]
    pub user_account: Account<'info, UserAccount>,
    
    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,

    #[account(
        init_if_needed,
        payer = payer,
        associated_token::mint = liquidity_mint,
        associated_token::authority = user,
    )]
    pub user_liquidity_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub vault: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub liquidity_mint: Account<'info, Mint>,
    
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Withdraw<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(
        mut,
        seeds = [b"lending_pool", lending_pool.asset_mint.as_ref()],
        bump = lending_pool.bump
    )]
    pub lending_pool: Account<'info, LendingPool>,
    
    #[account(
        mut,
        seeds = [b"user_account", user.key().as_ref(), lending_pool.key().as_ref()],
        bump
    )]
    pub user_account: Account<'info, UserAccount>,
    
    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub user_liquidity_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub vault: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub liquidity_mint: Account<'info, Mint>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct Borrow<'info> {
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(
        mut,
        seeds = [b"lending_pool", lending_pool.asset_mint.as_ref()],
        bump = lending_pool.bump
    )]
    pub lending_pool: Account<'info, LendingPool>,

    #[account(
        mut,
        seeds = [b"user_account", user.key().as_ref(), lending_pool.key().as_ref()],
        bump
    )]
    pub user_account: Account<'info, UserAccount>,
    
    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub vault: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct Repay<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(
        mut,
        seeds = [b"lending_pool", lending_pool.asset_mint.as_ref()],
        bump = lending_pool.bump
    )]
    pub lending_pool: Account<'info, LendingPool>,

    #[account(
        mut,
        seeds = [b"user_account", user.key().as_ref(), lending_pool.key().as_ref()],
        bump
    )]
    pub user_account: Account<'info, UserAccount>,
    
    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub vault: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct Liquidate<'info> {
    #[account(mut)]
    pub liquidator: Signer<'info>,

    #[account(
        mut,
        seeds = [b"lending_pool", lending_pool.asset_mint.as_ref()],
        bump = lending_pool.bump
    )]
    pub lending_pool: Account<'info, LendingPool>,

    #[account(
        mut,
        seeds = [b"user_account", borrower.key().as_ref(), lending_pool.key().as_ref()],
        bump
    )]
    pub borrower_account: Account<'info, UserAccount>,
    
    /// CHECK: Borrower account, verified via seeds
    pub borrower: AccountInfo<'info>,
    
    #[account(mut)]
    pub liquidator_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub vault: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct FlashLoan<'info> {
    #[account(mut)]
    pub borrower: Signer<'info>,

    #[account(mut)]
    pub payer: Signer<'info>,

    #[account(
        mut,
        seeds = [b"lending_pool", lending_pool.asset_mint.as_ref()],
        bump = lending_pool.bump
    )]
    pub lending_pool: Account<'info, LendingPool>,

    #[account(
        init,
        payer = payer,
        space = 8 + size_of::<FlashLoanState>(),
        seeds = [b"flash_loan", borrower.key().as_ref(), lending_pool.key().as_ref()],
        bump
    )]
    pub flash_loan_state: Account<'info, FlashLoanState>,

    #[account(mut)]
    pub borrower_token_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub vault: Account<'info, TokenAccount>,

    /// CHECK: Callback program for flash loan execution
    pub callback_program: AccountInfo<'info>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct RepayFlashLoan<'info> {
    #[account(mut)]
    pub borrower: Signer<'info>,

    #[account(
        mut,
        seeds = [b"lending_pool", lending_pool.asset_mint.as_ref()],
        bump = lending_pool.bump
    )]
    pub lending_pool: Account<'info, LendingPool>,

    #[account(
        mut,
        close = borrower,
        seeds = [b"flash_loan", borrower.key().as_ref(), lending_pool.key().as_ref()],
        bump
    )]
    pub flash_loan_state: Account<'info, FlashLoanState>,

    #[account(mut)]
    pub borrower_token_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub vault: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct DepositNftCollateral<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(mut)]
    pub payer: Signer<'info>,

    #[account(
        mut,
        seeds = [b"lending_pool", lending_pool.asset_mint.as_ref()],
        bump = lending_pool.bump
    )]
    pub lending_pool: Account<'info, LendingPool>,

    #[account(
        init_if_needed,
        payer = payer,
        space = 8 + size_of::<UserAccount>(),
        seeds = [b"user_account", user.key().as_ref(), lending_pool.key().as_ref()],
        bump
    )]
    pub user_account: Account<'info, UserAccount>,

    /// CHECK: NFT mint to be used as collateral
    pub nft_mint: AccountInfo<'info>,

    /// CHECK: NFT token account owned by user
    pub user_nft_account: AccountInfo<'info>,

    /// CHECK: NFT metadata account
    pub nft_metadata: AccountInfo<'info>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct WithdrawNftCollateral<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(
        mut,
        seeds = [b"lending_pool", lending_pool.asset_mint.as_ref()],
        bump = lending_pool.bump
    )]
    pub lending_pool: Account<'info, LendingPool>,

    #[account(
        mut,
        seeds = [b"user_account", user.key().as_ref(), lending_pool.key().as_ref()],
        bump
    )]
    pub user_account: Account<'info, UserAccount>,

    /// CHECK: NFT mint to be withdrawn
    pub nft_mint: AccountInfo<'info>,

    /// CHECK: NFT token account owned by user
    pub user_nft_account: AccountInfo<'info>,

    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct GetOraclePrice<'info> {
    /// CHECK: Oracle price feed account
    pub oracle_price_feed: AccountInfo<'info>,
}

#[derive(Accounts)]
pub struct LiquidateWithOracle<'info> {
    #[account(mut)]
    pub lending_pool: Account<'info, LendingPool>,
    
    #[account(mut)]
    pub user_account: Account<'info, UserAccount>,
    
    #[account(mut)]
    pub liquidator_account: Account<'info, UserAccount>,
    
    /// CHECK: Collateral asset oracle price feed
    pub collateral_oracle: AccountInfo<'info>,
    
    /// CHECK: Debt asset oracle price feed  
    pub debt_oracle: AccountInfo<'info>,
    
    pub liquidator: Signer<'info>,
}

#[derive(Accounts)]
pub struct CreateLoanRequest<'info> {
    #[account(
        init,
        payer = borrower,
        space = 8 + 8 + 32 + 8 + 8 + 8 + 1 + 8 + 1 + 8 + 1,
        seeds = [b"loan_request", borrower.key().as_ref()],
        bump
    )]
    pub loan_request: Account<'info, LoanRequest>,
    
    #[account(mut)]
    pub borrower: Signer<'info>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(request_id: u64)]
pub struct FulfillLoanRequest<'info> {
    #[account(
        mut,
        seeds = [b"loan_request", loan_request.borrower.as_ref()],
        bump = loan_request.bump
    )]
    pub loan_request: Account<'info, LoanRequest>,
    
    #[account(
        init,
        payer = lender,
        space = 8 + 8 + 32 + 32 + 8 + 8 + 8 + 8 + 8 + 8 + 1 + 1 + 1,
        seeds = [b"p2p_loan", &request_id.to_le_bytes()],
        bump
    )]
    pub p2p_loan: Account<'info, P2PLoan>,
    
    #[account(mut)]
    pub lender: Signer<'info>,
    
    #[account(mut)]
    pub lender_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub borrower_token_account: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(loan_id: u64)]
pub struct RepayP2PLoan<'info> {
    #[account(
        mut,
        seeds = [b"p2p_loan", &loan_id.to_le_bytes()],
        bump = p2p_loan.bump
    )]
    pub p2p_loan: Account<'info, P2PLoan>,
    
    #[account(mut)]
    pub borrower: Signer<'info>,
    
    #[account(mut)]
    pub borrower_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub lender_token_account: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
#[instruction(loan_id: u64)]
pub struct LiquidateP2PLoan<'info> {
    #[account(
        mut,
        seeds = [b"p2p_loan", &loan_id.to_le_bytes()],
        bump = p2p_loan.bump
    )]
    pub p2p_loan: Account<'info, P2PLoan>,
    
    pub liquidator: Signer<'info>,
    
    #[account(mut)]
    pub collateral_vault: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub lender_token_account: Account<'info, TokenAccount>,
    
    /// CHECK: Vault authority PDA
    pub vault_authority: AccountInfo<'info>,
    
    pub token_program: Program<'info, Token>,
}