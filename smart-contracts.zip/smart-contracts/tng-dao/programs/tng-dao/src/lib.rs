/**
 * TNG DAO - Decentralized Governance for TNG Ecosystem
 * Supports: Proposals, Voting, Treasury Management, Cross-Program Calls
 * Solana SuperApp
 */

use anchor_lang::prelude::*;
use anchor_spl::{
    token::{self, Mint, Token, TokenAccount, Transfer},
    associated_token::AssociatedToken,
};

declare_id!("HbDYHpNrayUvx5z4m81QRaQR7iLapK5Co7eW27Zn2ZYh");

#[program]
pub mod tng_dao {
    use super::*;

    /// Initialize the DAO configuration
    pub fn initialize_dao(
        ctx: Context<InitializeDAO>,
        voting_duration: u64,
        execution_delay: u64,
        quorum_threshold: u64,
        proposal_threshold: u64,
    ) -> Result<()> {
        msg!("Initializing TNG DAO");
        
        let dao_config = &mut ctx.accounts.dao_config;
        dao_config.authority = ctx.accounts.authority.key();
        dao_config.treasury = ctx.accounts.treasury.key();
        dao_config.tng_mint = ctx.accounts.tng_mint.key();
        dao_config.voting_duration = voting_duration;
        dao_config.execution_delay = execution_delay;
        dao_config.quorum_threshold = quorum_threshold;
        dao_config.proposal_threshold = proposal_threshold;
        dao_config.total_proposals = 0;
        dao_config.bump = ctx.bumps.dao_config;

        msg!("DAO initialized successfully");
        msg!("Authority: {}", dao_config.authority);
        msg!("Voting Duration: {} seconds", voting_duration);
        msg!("Execution Delay: {} seconds", execution_delay);
        msg!("Quorum Threshold: {} TNG", quorum_threshold);
        msg!("Proposal Threshold: {} TNG", proposal_threshold);

        Ok(())
    }

    /// Create a new governance proposal
    pub fn create_proposal(
        ctx: Context<CreateProposal>,
        title: String,
        description: String,
        actions: Vec<ProposalAction>,
    ) -> Result<()> {
        let dao_config = &mut ctx.accounts.dao_config;
        let proposal = &mut ctx.accounts.proposal;
        let current_time = Clock::get()?.unix_timestamp;

        msg!("Creating new proposal");
        msg!("Creator: {}", ctx.accounts.creator.key());
        msg!("Title: {}", title);
        msg!("Actions count: {}", actions.len());

        // Check if creator has enough TNG to create proposal
        let creator_balance = ctx.accounts.creator_tng_account.amount;
        require!(
            creator_balance >= dao_config.proposal_threshold,
            DAOError::InsufficientTNGForProposal
        );

        // Validate title and description length
        require!(title.len() <= 100, DAOError::TitleTooLong);
        require!(description.len() <= 1000, DAOError::DescriptionTooLong);
        require!(!actions.is_empty(), DAOError::NoActionsProvided);
        require!(actions.len() <= 10, DAOError::TooManyActions);

        // Initialize proposal
        let proposal_id = dao_config.total_proposals;
        proposal.id = proposal_id;
        proposal.creator = ctx.accounts.creator.key();
        proposal.title = title;
        proposal.description = description;
        proposal.actions = actions.clone();
        proposal.status = ProposalStatus::Active;
        proposal.votes_for = 0;
        proposal.votes_against = 0;
        proposal.votes_abstain = 0;
        proposal.voting_power_snapshot = get_total_tng_supply()?; // Snapshot at creation
        proposal.created_at = current_time;
        proposal.voting_ends_at = current_time + dao_config.voting_duration as i64;
        proposal.execution_eta = 0; // Set when proposal passes
        proposal.executed_actions = vec![false; actions.len()];

        // Increment total proposals
        dao_config.total_proposals = dao_config.total_proposals
            .checked_add(1)
            .ok_or(DAOError::MathOverflow)?;

        msg!("Proposal created successfully");
        msg!("Proposal ID: {}", proposal_id);
        msg!("Voting ends at: {}", proposal.voting_ends_at);

        emit!(ProposalCreatedEvent {
            proposal_id,
            creator: ctx.accounts.creator.key(),
            title: proposal.title.clone(),
            actions_count: actions.len() as u8,
            voting_ends_at: proposal.voting_ends_at,
            timestamp: current_time,
        });

        Ok(())
    }

    /// Cast a vote on a proposal
    pub fn vote(
        ctx: Context<Vote>,
        choice: VoteChoice,
        weight: u64,
    ) -> Result<()> {
        let proposal = &mut ctx.accounts.proposal;
        let vote_record = &mut ctx.accounts.vote_record;
        let current_time = Clock::get()?.unix_timestamp;

        msg!("Casting vote on proposal {}", proposal.id);
        msg!("Voter: {}", ctx.accounts.voter.key());
        msg!("Choice: {:?}", choice);
        msg!("Weight: {}", weight);

        // Check if proposal is still active
        require!(
            proposal.status == ProposalStatus::Active,
            DAOError::ProposalNotActive
        );

        // Check if voting period is still open
        require!(
            current_time <= proposal.voting_ends_at,
            DAOError::VotingPeriodEnded
        );

        // Validate voting weight against voter's TNG balance
        let voter_balance = ctx.accounts.voter_tng_account.amount;
        require!(weight <= voter_balance, DAOError::InsufficientVotingPower);
        require!(weight > 0, DAOError::InvalidVoteWeight);

        // Check if user already voted (vote_record should not exist)
        require!(
            vote_record.voter == Pubkey::default(),
            DAOError::AlreadyVoted
        );

        // Record the vote
        vote_record.voter = ctx.accounts.voter.key();
        vote_record.proposal = proposal.key();
        vote_record.choice = choice;
        vote_record.weight = weight;
        vote_record.timestamp = current_time;

        // Update proposal vote counts
        match choice {
            VoteChoice::For => {
                proposal.votes_for = proposal.votes_for
                    .checked_add(weight)
                    .ok_or(DAOError::MathOverflow)?;
            },
            VoteChoice::Against => {
                proposal.votes_against = proposal.votes_against
                    .checked_add(weight)
                    .ok_or(DAOError::MathOverflow)?;
            },
            VoteChoice::Abstain => {
                proposal.votes_abstain = proposal.votes_abstain
                    .checked_add(weight)
                    .ok_or(DAOError::MathOverflow)?;
            },
        }

        msg!("Vote recorded successfully");
        msg!("Current votes - For: {}, Against: {}, Abstain: {}", 
             proposal.votes_for, proposal.votes_against, proposal.votes_abstain);

        emit!(VoteCastEvent {
            proposal_id: proposal.id,
            voter: ctx.accounts.voter.key(),
            choice,
            weight,
            timestamp: current_time,
        });

        Ok(())
    }

    /// Finalize a proposal after voting period ends
    pub fn finalize_proposal(ctx: Context<FinalizeProposal>) -> Result<()> {
        let dao_config = &ctx.accounts.dao_config;
        let proposal = &mut ctx.accounts.proposal;
        let current_time = Clock::get()?.unix_timestamp;

        msg!("Finalizing proposal {}", proposal.id);

        // Check if proposal is active
        require!(
            proposal.status == ProposalStatus::Active,
            DAOError::ProposalNotActive
        );

        // Check if voting period has ended
        require!(
            current_time > proposal.voting_ends_at,
            DAOError::VotingPeriodNotEnded
        );

        let total_votes = proposal.votes_for
            .checked_add(proposal.votes_against)
            .ok_or(DAOError::MathOverflow)?
            .checked_add(proposal.votes_abstain)
            .ok_or(DAOError::MathOverflow)?;

        msg!("Total votes: {}", total_votes);
        msg!("Quorum threshold: {}", dao_config.quorum_threshold);

        // Check quorum
        if total_votes < dao_config.quorum_threshold {
            proposal.status = ProposalStatus::Rejected;
            msg!("Proposal rejected: insufficient quorum");
        } else if proposal.votes_for > proposal.votes_against {
            proposal.status = ProposalStatus::Passed;
            proposal.execution_eta = current_time + dao_config.execution_delay as i64;
            msg!("Proposal passed! Execution ETA: {}", proposal.execution_eta);
        } else {
            proposal.status = ProposalStatus::Rejected;
            msg!("Proposal rejected: more votes against");
        }

        emit!(ProposalFinalizedEvent {
            proposal_id: proposal.id,
            status: proposal.status,
            votes_for: proposal.votes_for,
            votes_against: proposal.votes_against,
            votes_abstain: proposal.votes_abstain,
            execution_eta: proposal.execution_eta,
            timestamp: current_time,
        });

        Ok(())
    }

    /// Execute a specific action from a passed proposal
    pub fn execute_action(
        ctx: Context<ExecuteAction>,
        action_index: u8,
    ) -> Result<()> {
        let current_time = Clock::get()?.unix_timestamp;
        let executor_key = ctx.accounts.executor.key();

        // Borrow proposal mutably for validation and updates
        {
            let proposal = &mut ctx.accounts.proposal;
            
            msg!("Executing action {} for proposal {}", action_index, proposal.id);

            // Validate proposal status
            require!(
                proposal.status == ProposalStatus::Passed,
                DAOError::ProposalNotPassed
            );

            // Check if execution delay has passed
            require!(
                current_time >= proposal.execution_eta,
                DAOError::ExecutionDelayNotPassed
            );

            // Validate action index
            require!(
                (action_index as usize) < proposal.actions.len(),
                DAOError::InvalidActionIndex
            );

            // Check if action already executed
            require!(
                !proposal.executed_actions[action_index as usize],
                DAOError::ActionAlreadyExecuted
            );
        }

        // Clone the action to avoid borrowing issues
        let action = ctx.accounts.proposal.actions[action_index as usize].clone();
        let proposal_id = ctx.accounts.proposal.id;
        
        // Execute the action based on its type
        match action {
            ProposalAction::UpdateStakingAPY { new_apy } => {
                msg!("Executing: Update Staking APY to {}", new_apy);
                // This would be a CPI call to staking contract
                // execute_update_staking_apy(&ctx, new_apy)?;
            },
            ProposalAction::UpdateFarmingRewardRate { new_rate } => {
                msg!("Executing: Update Farming Reward Rate to {}", new_rate);
                // This would be a CPI call to farming contract
                // execute_update_farming_reward_rate(&ctx, new_rate)?;
            },
            ProposalAction::PausePool { pool_type } => {
                msg!("Executing: Pause {:?} pool", pool_type);
                // This would be a CPI call to respective contract
                // execute_pause_pool(&ctx, pool_type)?;
            },
            ProposalAction::TreasuryTransfer { recipient, amount } => {
                msg!("Executing: Treasury transfer {} TNG to {}", amount, recipient);
                execute_treasury_transfer(&ctx, recipient, amount)?;
            },
            ProposalAction::UpdateDAOConfig { new_config } => {
                msg!("Executing: Update DAO config");
                execute_update_dao_config(&ctx, &new_config)?;
            },
        }

        // Mark action as executed and check completion
        {
            let proposal = &mut ctx.accounts.proposal;
            proposal.executed_actions[action_index as usize] = true;

            // Check if all actions are executed
            let all_executed = proposal.executed_actions.iter().all(|&executed| executed);
            if all_executed {
                proposal.status = ProposalStatus::Executed;
                msg!("All actions executed. Proposal completed.");
            }
        }

        emit!(ActionExecutedEvent {
            proposal_id,
            action_index,
            executor: executor_key,
            timestamp: current_time,
        });

        Ok(())
    }

    /// Fund the DAO treasury
    pub fn fund_treasury(
        ctx: Context<FundTreasury>,
        amount: u64,
    ) -> Result<()> {
        msg!("Funding treasury with {} TNG", amount);
        msg!("Funder: {}", ctx.accounts.funder.key());

        require!(amount > 0, DAOError::InvalidAmount);

        // Transfer TNG tokens to treasury
        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.funder_token_account.to_account_info(),
                to: ctx.accounts.treasury_token_account.to_account_info(),
                authority: ctx.accounts.funder.to_account_info(),
            },
        );
        token::transfer(transfer_ctx, amount)?;

        msg!("Treasury funded successfully");

        emit!(TreasuryFundedEvent {
            funder: ctx.accounts.funder.key(),
            amount,
            timestamp: Clock::get()?.unix_timestamp,
        });

        Ok(())
    }

    pub fn initialize_governance_mining(
        ctx: Context<InitializeGovernanceMining>,
        rewards_per_vote: u64,
        rewards_per_proposal: u64,
        mining_duration: i64,
    ) -> Result<()> {
        let governance_mining = &mut ctx.accounts.governance_mining;
        
        governance_mining.rewards_per_vote = rewards_per_vote;
        governance_mining.rewards_per_proposal = rewards_per_proposal;
        governance_mining.total_rewards_distributed = 0;
        governance_mining.mining_start = Clock::get()?.unix_timestamp;
        governance_mining.mining_end = governance_mining.mining_start + mining_duration;
        governance_mining.is_active = true;
        governance_mining.bump = ctx.bumps.governance_mining;

        msg!("Governance Mining initialized");
        msg!("Rewards per vote: {} TNG", rewards_per_vote);
        msg!("Rewards per proposal: {} TNG", rewards_per_proposal);
        msg!("Mining duration: {} seconds", mining_duration);

        Ok(())
    }

    pub fn claim_voting_rewards(
        ctx: Context<ClaimVotingRewards>,
        user: Pubkey,
    ) -> Result<()> {
        let governance_mining = &ctx.accounts.governance_mining;
        let user_rewards = &mut ctx.accounts.user_governance_rewards;
        
        require!(governance_mining.is_active, DAOError::GovernanceMiningInactive);
        
        let current_time = Clock::get()?.unix_timestamp;
        require!(
            current_time >= governance_mining.mining_start && current_time <= governance_mining.mining_end,
            DAOError::MiningPeriodInvalid
        );

        let pending_vote_rewards = user_rewards.total_votes
            .checked_mul(governance_mining.rewards_per_vote)
            .ok_or(DAOError::MathOverflow)?;

        let claimable_rewards = pending_vote_rewards
            .checked_sub(user_rewards.claimed_rewards)
            .ok_or(DAOError::MathOverflow)?;

        require!(claimable_rewards > 0, DAOError::NoRewardsToClaim);

        user_rewards.claimed_rewards = user_rewards.claimed_rewards
            .checked_add(claimable_rewards)
            .ok_or(DAOError::MathOverflow)?;

        user_rewards.last_claim = current_time;

        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            anchor_spl::token::Transfer {
                from: ctx.accounts.rewards_vault.to_account_info(),
                to: ctx.accounts.user_token_account.to_account_info(),
                authority: ctx.accounts.vault_authority.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_ctx, claimable_rewards)?;

        msg!("Voting rewards claimed: {} TNG", claimable_rewards);

        Ok(())
    }

    pub fn claim_proposal_rewards(
        ctx: Context<ClaimProposalRewards>,
        proposal_id: u64,
    ) -> Result<()> {
        let governance_mining = &ctx.accounts.governance_mining;
        let user_rewards = &mut ctx.accounts.user_governance_rewards;
        let proposal = &ctx.accounts.proposal;
        
        require!(governance_mining.is_active, DAOError::GovernanceMiningInactive);
        require!(proposal.id == proposal_id, DAOError::InvalidProposalId);
        require!(proposal.proposer == ctx.accounts.user.key(), DAOError::NotProposalCreator);
        require!(proposal.status == ProposalStatus::Passed, DAOError::ProposalNotPassed);

        let proposal_rewards = governance_mining.rewards_per_proposal;
        
        user_rewards.successful_proposals = user_rewards.successful_proposals
            .checked_add(1)
            .ok_or(DAOError::MathOverflow)?;

        user_rewards.pending_rewards = user_rewards.pending_rewards
            .checked_add(proposal_rewards)
            .ok_or(DAOError::MathOverflow)?;

        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            anchor_spl::token::Transfer {
                from: ctx.accounts.rewards_vault.to_account_info(),
                to: ctx.accounts.user_token_account.to_account_info(),
                authority: ctx.accounts.vault_authority.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_ctx, proposal_rewards)?;

        msg!("Proposal rewards claimed: {} TNG for proposal {}", proposal_rewards, proposal_id);

        Ok(())
    }

    pub fn update_user_voting_rewards(
        ctx: Context<UpdateUserVotingRewards>,
        user: Pubkey,
        votes_cast: u64,
    ) -> Result<()> {
        let user_rewards = &mut ctx.accounts.user_governance_rewards;
        
        if user_rewards.user == Pubkey::default() {
            user_rewards.user = user;
            user_rewards.total_votes = votes_cast;
            user_rewards.successful_proposals = 0;
            user_rewards.claimed_rewards = 0;
            user_rewards.pending_rewards = 0;
            user_rewards.last_claim = 0;
            user_rewards.bump = ctx.bumps.user_governance_rewards;
        } else {
            user_rewards.total_votes = user_rewards.total_votes
                .checked_add(votes_cast)
                .ok_or(DAOError::MathOverflow)?;
        }

        Ok(())
    }

    pub fn toggle_governance_mining(
        ctx: Context<ToggleGovernanceMining>,
        is_active: bool,
    ) -> Result<()> {
        let governance_mining = &mut ctx.accounts.governance_mining;
        let dao_config = &ctx.accounts.dao_config;
        
        require!(
            ctx.accounts.authority.key() == dao_config.authority,
            DAOError::Unauthorized
        );

        governance_mining.is_active = is_active;

        msg!("Governance Mining status changed to: {}", is_active);

        Ok(())
    }
}

// Helper functions for action execution
fn execute_treasury_transfer(
    _ctx: &Context<ExecuteAction>,
    recipient: Pubkey,
    amount: u64,
) -> Result<()> {
    // Implementation for treasury transfer
    msg!("Treasury transfer: {} TNG to {}", amount, recipient);
    // This would involve transferring from treasury to recipient
    // For now, just log the action
    Ok(())
}

fn execute_update_dao_config(
    _ctx: &Context<ExecuteAction>,
    _new_config: &DAOConfigUpdate,
) -> Result<()> {
    // Implementation for updating DAO config
    msg!("Updating DAO configuration");
    // For now, just log the action
    Ok(())
}

fn get_total_tng_supply() -> Result<u64> {
    // This would query the TNG mint to get total supply
    // For now, return a placeholder
    Ok(100_000_000 * 1_000_000_000) // 100M TNG with 9 decimals
}

// ============================================================================
// Account Structures
// ============================================================================

#[account]
#[derive(InitSpace)]
pub struct DAOConfig {
    pub authority: Pubkey,          // Current authority (can be changed via proposal)
    pub treasury: Pubkey,           // Treasury PDA
    pub tng_mint: Pubkey,           // TNG token mint
    pub voting_duration: u64,       // Voting duration in seconds (e.g., 7 days)
    pub execution_delay: u64,       // Time delay before execution (e.g., 24 hours)
    pub quorum_threshold: u64,      // Minimum votes needed for quorum
    pub proposal_threshold: u64,    // Minimum TNG needed to create proposal
    pub total_proposals: u64,       // Total number of proposals created
    pub bump: u8,                   // PDA bump seed
}

#[account]
#[derive(InitSpace)]
pub struct Proposal {
    pub id: u64,                        // Unique proposal ID
    pub creator: Pubkey,                // Proposal creator
    #[max_len(100)]
    pub title: String,                  // Proposal title
    #[max_len(1000)]
    pub description: String,            // Proposal description
    #[max_len(10)]
    pub actions: Vec<ProposalAction>,   // Actions to execute if passed
    pub status: ProposalStatus,         // Current status
    pub votes_for: u64,                 // Total votes in favor
    pub votes_against: u64,             // Total votes against
    pub votes_abstain: u64,             // Total abstain votes
    pub voting_power_snapshot: u64,     // Total voting power at creation
    pub created_at: i64,                // Creation timestamp
    pub voting_ends_at: i64,            // Voting end timestamp
    pub execution_eta: i64,             // When actions can be executed
    #[max_len(10)]
    pub executed_actions: Vec<bool>,    // Track which actions are executed
}

#[account]
#[derive(InitSpace)]
pub struct VoteRecord {
    pub voter: Pubkey,              // Voter's public key
    pub proposal: Pubkey,           // Proposal being voted on
    pub choice: VoteChoice,         // Vote choice
    pub weight: u64,                // Voting weight (TNG amount)
    pub timestamp: i64,             // Vote timestamp
}

#[account]
#[derive(InitSpace)]
pub struct GovernanceMining {
    pub rewards_per_vote: u64,
    pub rewards_per_proposal: u64,
    pub total_rewards_distributed: u64,
    pub mining_start: i64,
    pub mining_end: i64,
    pub is_active: bool,
    pub bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct UserGovernanceRewards {
    pub user: Pubkey,
    pub total_votes: u64,
    pub successful_proposals: u64,
    pub claimed_rewards: u64,
    pub pending_rewards: u64,
    pub last_claim: i64,
    pub bump: u8,
}

// ============================================================================
// Types and Enums
// ============================================================================

#[derive(AnchorSerialize, AnchorDeserialize, Clone, InitSpace)]
pub enum ProposalAction {
    UpdateStakingAPY { new_apy: u16 },
    UpdateFarmingRewardRate { new_rate: u64 },
    PausePool { pool_type: PoolType },
    TreasuryTransfer { recipient: Pubkey, amount: u64 },
    UpdateDAOConfig { new_config: DAOConfigUpdate },
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, Debug, PartialEq, InitSpace)]
pub enum VoteChoice {
    For,
    Against,
    Abstain,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, Debug, PartialEq, InitSpace)]
pub enum ProposalStatus {
    Active,     // Currently accepting votes
    Passed,     // Passed, waiting for execution
    Rejected,   // Rejected or failed quorum
    Executed,   // All actions executed
    Cancelled,  // Cancelled by authority
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, Debug, InitSpace)]
pub enum PoolType {
    Staking,
    Farming,
    Swap,
    Lending,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, InitSpace)]
pub struct DAOConfigUpdate {
    pub voting_duration: Option<u64>,
    pub execution_delay: Option<u64>,
    pub quorum_threshold: Option<u64>,
    pub proposal_threshold: Option<u64>,
}

// ============================================================================
// Account Contexts
// ============================================================================

#[derive(Accounts)]
pub struct InitializeDAO<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,

    #[account(mut)]
    pub payer: Signer<'info>, // payer = sponsor

    #[account(
        init,
        payer = payer, // payer = sponsor
        space = 8 + DAOConfig::INIT_SPACE,
        seeds = [b"dao_config"],
        bump
    )]
    pub dao_config: Account<'info, DAOConfig>,

    #[account(
        init,
        payer = payer, // payer = sponsor
        associated_token::mint = tng_mint,
        associated_token::authority = dao_config,
    )]
    pub treasury: Account<'info, TokenAccount>,

    pub tng_mint: Account<'info, Mint>,
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(title: String)]
pub struct CreateProposal<'info> {
    #[account(mut)]
    pub creator: Signer<'info>,

    #[account(mut)]
    pub payer: Signer<'info>, // payer = sponsor

    #[account(
        mut,
        seeds = [b"dao_config"],
        bump = dao_config.bump
    )]
    pub dao_config: Account<'info, DAOConfig>,

    #[account(
        init,
        payer = payer, // payer = sponsor
        space = 8 + Proposal::INIT_SPACE,
        seeds = [b"proposal", dao_config.total_proposals.to_le_bytes().as_ref()],
        bump
    )]
    pub proposal: Account<'info, Proposal>,

    #[account(
        constraint = creator_tng_account.mint == dao_config.tng_mint,
        constraint = creator_tng_account.owner == creator.key()
    )]
    pub creator_tng_account: Account<'info, TokenAccount>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Vote<'info> {
    #[account(mut)]
    pub voter: Signer<'info>,

    #[account(
        mut,
        seeds = [b"proposal", proposal.id.to_le_bytes().as_ref()],
        bump
    )]
    pub proposal: Account<'info, Proposal>,

    #[account(
        init,
        payer = voter,
        space = 8 + VoteRecord::INIT_SPACE,
        seeds = [b"vote", voter.key().as_ref(), proposal.key().as_ref()],
        bump
    )]
    pub vote_record: Account<'info, VoteRecord>,

    #[account(
        constraint = voter_tng_account.mint == dao_config.tng_mint,
        constraint = voter_tng_account.owner == voter.key()
    )]
    pub voter_tng_account: Account<'info, TokenAccount>,

    #[account(
        seeds = [b"dao_config"],
        bump = dao_config.bump
    )]
    pub dao_config: Account<'info, DAOConfig>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct FinalizeProposal<'info> {
    #[account(
        mut,
        seeds = [b"proposal", proposal.id.to_le_bytes().as_ref()],
        bump
    )]
    pub proposal: Account<'info, Proposal>,

    #[account(
        seeds = [b"dao_config"],
        bump = dao_config.bump
    )]
    pub dao_config: Account<'info, DAOConfig>,
}

#[derive(Accounts)]
pub struct ExecuteAction<'info> {
    pub executor: Signer<'info>,

    #[account(
        mut,
        seeds = [b"proposal", proposal.id.to_le_bytes().as_ref()],
        bump
    )]
    pub proposal: Account<'info, Proposal>,

    #[account(
        seeds = [b"dao_config"],
        bump = dao_config.bump
    )]
    pub dao_config: Account<'info, DAOConfig>,

    #[account(
        mut,
        seeds = [b"treasury"],
        bump,
    )]
    pub treasury: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct FundTreasury<'info> {
    #[account(mut)]
    pub funder: Signer<'info>,

    #[account(
        mut,
        seeds = [b"treasury"],
        bump,
    )]
    pub treasury_token_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub funder_token_account: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
}

// ============================================================================
// Events
// ============================================================================

#[event]
pub struct ProposalCreatedEvent {
    pub proposal_id: u64,
    pub creator: Pubkey,
    pub title: String,
    pub actions_count: u8,
    pub voting_ends_at: i64,
    pub timestamp: i64,
}

#[event]
pub struct VoteCastEvent {
    pub proposal_id: u64,
    pub voter: Pubkey,
    pub choice: VoteChoice,
    pub weight: u64,
    pub timestamp: i64,
}

#[event]
pub struct ProposalFinalizedEvent {
    pub proposal_id: u64,
    pub status: ProposalStatus,
    pub votes_for: u64,
    pub votes_against: u64,
    pub votes_abstain: u64,
    pub execution_eta: i64,
    pub timestamp: i64,
}

#[event]
pub struct ActionExecutedEvent {
    pub proposal_id: u64,
    pub action_index: u8,
    pub executor: Pubkey,
    pub timestamp: i64,
}

#[event]
pub struct TreasuryFundedEvent {
    pub funder: Pubkey,
    pub amount: u64,
    pub timestamp: i64,
}

// ============================================================================
// Error Codes
// ============================================================================

#[error_code]
pub enum DAOError {
    #[msg("Invalid amount: must be greater than 0")]
    InvalidAmount,
    
    #[msg("Insufficient TNG balance to create proposal")]
    InsufficientTNGForProposal,
    
    #[msg("Proposal title too long (max 100 characters)")]
    TitleTooLong,
    
    #[msg("Proposal description too long (max 1000 characters)")]
    DescriptionTooLong,
    
    #[msg("No actions provided in proposal")]
    NoActionsProvided,
    
    #[msg("Too many actions in proposal (max 10)")]
    TooManyActions,
    
    #[msg("Proposal is not active")]
    ProposalNotActive,
    
    #[msg("Voting period has ended")]
    VotingPeriodEnded,
    
    #[msg("Voting period has not ended yet")]
    VotingPeriodNotEnded,
    
    #[msg("Insufficient voting power")]
    InsufficientVotingPower,
    
    #[msg("Invalid vote weight")]
    InvalidVoteWeight,
    
    #[msg("User has already voted on this proposal")]
    AlreadyVoted,
    
    #[msg("Proposal has not passed")]
    ProposalNotPassed,
    
    #[msg("Execution delay has not passed")]
    ExecutionDelayNotPassed,
    
    #[msg("Invalid action index")]
    InvalidActionIndex,
    
    #[msg("Action already executed")]
    ActionAlreadyExecuted,
    
    #[msg("Mathematical overflow occurred")]
    MathOverflow,
    
    #[msg("Governance mining inactive")]
    GovernanceMiningInactive,
    
    #[msg("Mining period invalid")]
    MiningPeriodInvalid,
    
    #[msg("No rewards to claim")]
    NoRewardsToClaim,
    
    #[msg("Invalid proposal ID")]
    InvalidProposalId,
    
    #[msg("Not proposal creator")]
    NotProposalCreator,
}

#[derive(Accounts)]
pub struct InitializeGovernanceMining<'info> {
    #[account(
        init,
        payer = authority,
        space = 8 + 8 + 8 + 8 + 8 + 8 + 1 + 1,
        seeds = [b"governance_mining"],
        bump
    )]
    pub governance_mining: Account<'info, GovernanceMining>,
    
    #[account(mut)]
    pub authority: Signer<'info>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct ClaimVotingRewards<'info> {
    #[account(
        seeds = [b"governance_mining"],
        bump = governance_mining.bump
    )]
    pub governance_mining: Account<'info, GovernanceMining>,
    
    #[account(
        mut,
        seeds = [b"user_governance_rewards", user.key().as_ref()],
        bump = user_governance_rewards.bump
    )]
    pub user_governance_rewards: Account<'info, UserGovernanceRewards>,
    
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub rewards_vault: Account<'info, TokenAccount>,
    
    /// CHECK: Vault authority PDA
    pub vault_authority: AccountInfo<'info>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct ClaimProposalRewards<'info> {
    #[account(
        seeds = [b"governance_mining"],
        bump = governance_mining.bump
    )]
    pub governance_mining: Account<'info, GovernanceMining>,
    
    #[account(
        mut,
        seeds = [b"user_governance_rewards", user.key().as_ref()],
        bump = user_governance_rewards.bump
    )]
    pub user_governance_rewards: Account<'info, UserGovernanceRewards>,
    
    #[account(
        seeds = [b"proposal", proposal.id.to_le_bytes().as_ref()],
        bump
    )]
    pub proposal: Account<'info, Proposal>,
    
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub rewards_vault: Account<'info, TokenAccount>,
    
    /// CHECK: Vault authority PDA
    pub vault_authority: AccountInfo<'info>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct UpdateUserVotingRewards<'info> {
    #[account(
        init_if_needed,
        payer = payer,
        space = 8 + 32 + 8 + 8 + 8 + 8 + 8 + 1,
        seeds = [b"user_governance_rewards", user.key().as_ref()],
        bump
    )]
    pub user_governance_rewards: Account<'info, UserGovernanceRewards>,
    
    /// CHECK: User whose rewards are being updated
    pub user: AccountInfo<'info>,
    
    #[account(mut)]
    pub payer: Signer<'info>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct ToggleGovernanceMining<'info> {
    #[account(
        mut,
        seeds = [b"governance_mining"],
        bump = governance_mining.bump
    )]
    pub governance_mining: Account<'info, GovernanceMining>,
    
    #[account(
        seeds = [b"dao_config"],
        bump = dao_config.bump
    )]
    pub dao_config: Account<'info, DAOConfig>,
    
    pub authority: Signer<'info>,
}
