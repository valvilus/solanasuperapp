/**
 * Fund SOL vault with system transfer
 */

const { 
  Connection, 
  PublicKey, 
  Keypair,
  SystemProgram,
  Transaction,
  LAMPORTS_PER_SOL 
} = require('@solana/web3.js');
const { getAssociatedTokenAddress } = require('@solana/spl-token');
const fs = require('fs');

// Constants
const TNG_SWAP_PROGRAM_ID = new PublicKey('FWfcH4Zcp8HztJFqui3wX3AkG9XjV9PoKnNPCgsctSVV');
const TNG_MINT = new PublicKey('FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs');
const SOL_MINT = new PublicKey('So11111111111111111111111111111111111111112');

async function main() {
  console.log(' Funding SOL vault with system transfer...');
  
  // Setup connection
  const connection = new Connection('https://api.devnet.solana.com', 'confirmed');
  
  // Load sponsor keypair
  const sponsorKeypair = Keypair.fromSecretKey(
    Uint8Array.from(JSON.parse(fs.readFileSync('./keys/mvp-sponsor-keypair.json', 'utf8')))
  );
  console.log(' Sponsor:', sponsorKeypair.publicKey.toBase58());
  
  // Calculate pool PDA and SOL vault
  const [poolPDA] = PublicKey.findProgramAddressSync(
    [Buffer.from('swap_pool'), TNG_MINT.toBuffer(), SOL_MINT.toBuffer()],
    TNG_SWAP_PROGRAM_ID
  );
  
  const solVault = await getAssociatedTokenAddress(SOL_MINT, poolPDA, true);
  
  console.log(' Pool PDA:', poolPDA.toBase58());
  console.log(' SOL Vault:', solVault.toBase58());

  // Check current balances
  const sponsorBalance = await connection.getBalance(sponsorKeypair.publicKey);
  console.log(' Sponsor SOL balance:', sponsorBalance / LAMPORTS_PER_SOL, 'SOL');
  
  try {
    const vaultBalance = await connection.getBalance(solVault);
    console.log(' Current SOL Vault balance:', vaultBalance / LAMPORTS_PER_SOL, 'SOL');
  } catch (error) {
    console.log(' SOL Vault check failed');
  }

  // Send 2 SOL directly to vault
  const transferAmount = 2 * LAMPORTS_PER_SOL;
  
  console.log(' Transferring 2 SOL to vault...');
  
  const transaction = new Transaction().add(
    SystemProgram.transfer({
      fromPubkey: sponsorKeypair.publicKey,
      toPubkey: solVault,
      lamports: transferAmount,
    })
  );

  try {
    const signature = await connection.sendTransaction(transaction, [sponsorKeypair]);
    console.log(' SOL transferred to vault successfully!');
    console.log(' Transaction:', `https://explorer.solana.com/tx/${signature}?cluster=devnet`);
    
    // Verify new balance
    await connection.confirmTransaction(signature);
    const newBalance = await connection.getBalance(solVault);
    console.log(' New SOL Vault balance:', newBalance / LAMPORTS_PER_SOL, 'SOL');
    
  } catch (error) {
    console.error(' Failed to transfer SOL:', error);
  }
}

main().catch(console.error);
