/**
 * Initialize DAO Script
 * Initializes the TNG DAO contract with default parameters
 * Run: npx ts-node scripts/initialize-dao.ts
 */

import * as anchor from "@coral-xyz/anchor"
import { Program } from "@coral-xyz/anchor"
import { TngDao } from "../target/types/tng_dao"
import { 
  PublicKey, 
  Keypair, 
  SystemProgram,
  LAMPORTS_PER_SOL
} from "@solana/web3.js"
import { 
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  createMint,
  mintTo,
  createAccount,
  getAssociatedTokenAddress
} from "@solana/spl-token"
import fs from 'fs'

// Load sponsor keypair
const sponsorKeypairPath = './keys/mvp-sponsor-keypair.json'
let sponsorKeypair: Keypair

try {
  const sponsorKeypairData = JSON.parse(fs.readFileSync(sponsorKeypairPath, 'utf8'))
  sponsorKeypair = Keypair.fromSecretKey(new Uint8Array(sponsorKeypairData))
} catch (error) {
  console.error('Could not load sponsor keypair:', error)
  process.exit(1)
}

// Configuration
const VOTING_DURATION = 7 * 24 * 60 * 60 // 7 days in seconds
const EXECUTION_DELAY = 24 * 60 * 60 // 24 hours in seconds  
const QUORUM_THRESHOLD = new anchor.BN('1000000000000') // 1000 TNG (with 9 decimals)
const PROPOSAL_THRESHOLD = new anchor.BN('100000000000') // 100 TNG (with 9 decimals)

// TNG Mint address (from environment or default devnet)
const TNG_MINT = new PublicKey(process.env.TNG_MINT_ADDRESS || 'FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs')

async function main() {
  console.log(' Initializing TNG DAO...')
  
  // Configure the client to use devnet
  const connection = new anchor.web3.Connection(
    process.env.SOLANA_RPC_URL || 'https://api.devnet.solana.com',
    'confirmed'
  )
  
  const wallet = new anchor.Wallet(sponsorKeypair)
  const provider = new anchor.AnchorProvider(connection, wallet, {
    commitment: 'confirmed'
  })
  
  anchor.setProvider(provider)
  
  const program = anchor.workspace.TngDao as Program<TngDao>
  
  console.log('Program ID:', program.programId.toString())
  console.log('Authority:', sponsorKeypair.publicKey.toString())
  console.log('TNG Mint:', TNG_MINT.toString())
  
  // Derive PDA addresses
  const [daoConfig, daoConfigBump] = PublicKey.findProgramAddressSync(
    [Buffer.from('dao_config')],
    program.programId
  )
  
  // Calculate treasury as ATA for dao_config
  const treasury = await getAssociatedTokenAddress(
    TNG_MINT,
    daoConfig,
    true // allowOwnerOffCurve for PDA
  )
  
  console.log('DAO Config PDA:', daoConfig.toString())
  console.log('Treasury ATA:', treasury.toString())
  
  // Check if DAO is already initialized
  try {
    const existingConfig = await program.account.daoConfig.fetch(daoConfig)
    console.log(' DAO is already initialized!')
    console.log('Current config:', {
      authority: existingConfig.authority.toString(),
      totalProposals: existingConfig.totalProposals.toString(),
      votingDuration: existingConfig.votingDuration.toString() + ' seconds',
      executionDelay: existingConfig.executionDelay.toString() + ' seconds',
      quorumThreshold: existingConfig.quorumThreshold.toString(),
      proposalThreshold: existingConfig.proposalThreshold.toString()
    })
    return
  } catch (error) {
    console.log('DAO not initialized yet, proceeding with initialization...')
  }
  
  try {
    // Initialize DAO
    console.log(' Sending initialize transaction...')
    
    const tx = await program.methods
      .initializeDao(
        new anchor.BN(VOTING_DURATION),
        new anchor.BN(EXECUTION_DELAY),
        QUORUM_THRESHOLD,
        PROPOSAL_THRESHOLD
      )
      .accounts({
        authority: sponsorKeypair.publicKey,
        payer: sponsorKeypair.publicKey,
        tngMint: TNG_MINT,
      })
      .signers([sponsorKeypair])
      .rpc()
    
    console.log(' DAO initialized successfully!')
    console.log('Transaction signature:', tx)
    console.log('Explorer:', `https://explorer.solana.com/tx/${tx}?cluster=devnet`)
    
    // Verify initialization
    const daoConfigAccount = await program.account.daoConfig.fetch(daoConfig)
    console.log(' DAO Configuration:')
    console.log('  Authority:', daoConfigAccount.authority.toString())
    console.log('  Treasury:', daoConfigAccount.treasury.toString())
    console.log('  TNG Mint:', daoConfigAccount.tngMint.toString())
    console.log('  Voting Duration:', daoConfigAccount.votingDuration.toString(), 'seconds')
    console.log('  Execution Delay:', daoConfigAccount.executionDelay.toString(), 'seconds')
    console.log('  Quorum Threshold:', daoConfigAccount.quorumThreshold.toString(), 'TNG')
    console.log('  Proposal Threshold:', daoConfigAccount.proposalThreshold.toString(), 'TNG')
    console.log('  Total Proposals:', daoConfigAccount.totalProposals.toString())
    
    // Check treasury account
    try {
      const treasuryBalance = await connection.getBalance(treasury)
      console.log(' Treasury SOL Balance:', treasuryBalance / LAMPORTS_PER_SOL, 'SOL')
      
      // Check if treasury has TNG token account
      const treasuryTngAccount = await getAssociatedTokenAddress(TNG_MINT, treasury, true)
      try {
        const treasuryTngBalance = await connection.getTokenAccountBalance(treasuryTngAccount)
        console.log(' Treasury TNG Balance:', 
          (parseInt(treasuryTngBalance.value.amount) / 1_000_000_000).toFixed(2), 'TNG')
      } catch {
        console.log(' Treasury TNG Account: Not created yet (balance: 0 TNG)')
      }
    } catch (error) {
      console.log('Could not check treasury balance:', error)
    }
    
    console.log(' DAO initialization completed successfully!')
    
  } catch (error) {
    console.error(' Error initializing DAO:', error)
    process.exit(1)
  }
}

main().catch(console.error)
