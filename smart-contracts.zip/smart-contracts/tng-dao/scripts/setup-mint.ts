import { 
  PublicKey, 
  Keypair,
  Connection,
  clusterApiUrl
} from "@solana/web3.js";
import {
  TOKEN_PROGRAM_ID,
  setAuthority,
  AuthorityType
} from "@solana/spl-token";
import fs from 'fs';

// Load keypairs
const sponsorKeypair = Keypair.fromSecretKey(
  new Uint8Array(JSON.parse(fs.readFileSync('../../keys/mvp-sponsor-keypair.json', 'utf-8')))
);

// Token mint addresses
const TNG_MINT = new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs");
const STNG_MINT = new PublicKey("89Srwa82XbFZiNcbm5uY43BWLy4HKxp5EZdwtH3zbHex");
const PROGRAM_ID = new PublicKey("HQEY4xvroTrgEjwUcfGvqtcCdPN3zYTqHw83FiGWpBvH");

async function setupMint() {
  const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

  console.log(" Setting up sTNG mint authority...");
  console.log(" sTNG Mint:", STNG_MINT.toString());
  console.log(" Current Authority:", sponsorKeypair.publicKey.toString());

  // Find PDA for staking pool (this will be the new mint authority)
  const [stakingPoolPda, bump] = PublicKey.findProgramAddressSync(
    [Buffer.from("staking_pool"), TNG_MINT.toBuffer()],
    PROGRAM_ID
  );

  console.log(" Staking Pool PDA:", stakingPoolPda.toString());
  console.log(" Bump:", bump);

  try {
    // Set mint authority to staking pool PDA
    const tx = await setAuthority(
      connection,
      sponsorKeypair,
      STNG_MINT,
      sponsorKeypair.publicKey,
      AuthorityType.MintTokens,
      stakingPoolPda
    );

    console.log(" sTNG mint authority set to staking pool!");
    console.log(" Transaction signature:", tx);
    console.log(" Explorer:", `https://explorer.solana.com/tx/${tx}?cluster=devnet`);

    // Save setup info
    const setupInfo = {
      stngMint: STNG_MINT.toString(),
      oldAuthority: sponsorKeypair.publicKey.toString(),
      newAuthority: stakingPoolPda.toString(),
      stakingPoolPda: stakingPoolPda.toString(),
      bump,
      tx,
      explorerUrl: `https://explorer.solana.com/tx/${tx}?cluster=devnet`,
      setupAt: new Date().toISOString()
    };

    fs.writeFileSync('mint-setup-info.json', JSON.stringify(setupInfo, null, 2));
    console.log(" Setup info saved to mint-setup-info.json");

  } catch (error) {
    console.error(" Error setting up mint:", error);
    throw error;
  }
}

setupMint().catch(console.error);

