import * as anchor from "@coral-xyz/anchor";
import { Program, AnchorProvider, Wallet } from "@coral-xyz/anchor";
import { 
  PublicKey, 
  Keypair, 
  Connection,
  clusterApiUrl
} from "@solana/web3.js";
import fs from 'fs';

// Load keypairs
const sponsorKeypair = Keypair.fromSecretKey(
  new Uint8Array(JSON.parse(fs.readFileSync('../../keys/mvp-sponsor-keypair.json', 'utf-8')))
);

// Token mint addresses
const TNG_MINT = new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs");
const SOL_MINT = new PublicKey("So11111111111111111111111111111111111111112");

async function testConnection() {
  console.log(" Testing TNG Farming Contract Connection...");
  
  try {
    // Configure the client to use the devnet cluster
    const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
    const wallet = new Wallet(sponsorKeypair);
    const provider = new AnchorProvider(connection, wallet, {
      commitment: "confirmed",
    });
    anchor.setProvider(provider);

    // Load program
    const idl = JSON.parse(fs.readFileSync('./target/idl/tng_farming.json', 'utf-8'));
    const program = new Program(idl, provider);

    console.log(" Program ID:", program.programId.toString());
    console.log(" Authority:", sponsorKeypair.publicKey.toString());

    // Find PDA for farming pool (TNG/SOL pair)
    const [farmingPoolPda, bump] = PublicKey.findProgramAddressSync(
      [Buffer.from("farming_pool"), TNG_MINT.toBuffer(), SOL_MINT.toBuffer()],
      program.programId
    );

    console.log(" Farming Pool PDA:", farmingPoolPda.toString());
    console.log(" Bump:", bump);

    // Try to fetch pool data
    try {
      const poolData = await (program.account as any).farmingPool.fetch(farmingPoolPda);
      console.log(" Pool exists!");
      console.log("Pool data:", {
        authority: poolData.authority.toString(),
        tngReserve: poolData.tngReserve.toString(),
        otherReserve: poolData.otherReserve.toString(),
        isActive: poolData.isActive
      });
    } catch (error) {
      console.log(" Pool does not exist yet - needs initialization");
      console.log("Error:", error.message);
    }

    // Check program account exists
    const programAccount = await connection.getAccountInfo(program.programId);
    if (programAccount) {
      console.log(" Program deployed and accessible");
    } else {
      console.log(" Program not found");
    }

  } catch (error) {
    console.error(" Connection test failed:", error);
  }
}

testConnection().catch(console.error);
