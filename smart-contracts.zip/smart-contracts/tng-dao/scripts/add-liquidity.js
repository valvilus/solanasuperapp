/**
 * Add liquidity to TNG/SOL pool
 */

const anchor = require('@coral-xyz/anchor');
const { 
  Connection, 
  PublicKey, 
  Keypair,
  SystemProgram,
  LAMPORTS_PER_SOL 
} = require('@solana/web3.js');
const { 
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  getAssociatedTokenAddress,
  createAssociatedTokenAccountInstruction,
  createTransferInstruction,
  getOrCreateAssociatedTokenAccount
} = require('@solana/spl-token');
const fs = require('fs');

// Constants
const TNG_SWAP_PROGRAM_ID = new PublicKey('FWfcH4Zcp8HztJFqui3wX3AkG9XjV9PoKnNPCgsctSVV');
const TNG_MINT = new PublicKey('FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs');
const SOL_MINT = new PublicKey('So11111111111111111111111111111111111111112');

async function main() {
  console.log(' Adding liquidity to TNG/SOL pool...');
  
  // Setup connection
  const connection = new Connection('https://api.devnet.solana.com', 'confirmed');
  
  // Load sponsor keypair
  const sponsorKeypair = Keypair.fromSecretKey(
    Uint8Array.from(JSON.parse(fs.readFileSync('./keys/mvp-sponsor-keypair.json', 'utf8')))
  );
  console.log(' Sponsor:', sponsorKeypair.publicKey.toBase58());
  
  // Load program
  const idl = JSON.parse(fs.readFileSync('./target/idl/tng_swap.json', 'utf8'));
  const provider = new anchor.AnchorProvider(connection, new anchor.Wallet(sponsorKeypair), {});
  const program = new anchor.Program(idl, TNG_SWAP_PROGRAM_ID, provider);
  console.log(' Program loaded:', TNG_SWAP_PROGRAM_ID.toBase58());

  // Calculate pool PDA
  const [poolPDA] = PublicKey.findProgramAddressSync(
    [Buffer.from('swap_pool'), TNG_MINT.toBuffer(), SOL_MINT.toBuffer()],
    TNG_SWAP_PROGRAM_ID
  );
  console.log(' Pool PDA:', poolPDA.toBase58());

  // Get vault addresses
  const tngVault = await getAssociatedTokenAddress(TNG_MINT, poolPDA, true);
  const solVault = await getAssociatedTokenAddress(SOL_MINT, poolPDA, true);
  
  console.log(' Vault addresses:', {
    tngVault: tngVault.toBase58(),
    solVault: solVault.toBase58()
  });

  // Check vault balances
  try {
    const solVaultInfo = await connection.getAccountInfo(solVault);
    console.log(' SOL Vault balance:', solVaultInfo ? 'EXISTS' : 'NOT EXISTS');
    
    if (solVaultInfo) {
      const solVaultBalance = await connection.getBalance(solVault);
      console.log(' SOL Vault lamports:', solVaultBalance);
    }
  } catch (error) {
    console.log(' SOL Vault check failed:', error.message);
  }

  // Add liquidity: 10 SOL + 10000 TNG
  const solAmount = 10 * LAMPORTS_PER_SOL; // 10 SOL
  const tngAmount = 10000 * Math.pow(10, 9); // 10000 TNG

  console.log(' Adding liquidity:', {
    solAmount: `${solAmount / LAMPORTS_PER_SOL} SOL`,
    tngAmount: `${tngAmount / Math.pow(10, 9)} TNG`
  });

  try {
    const signature = await program.methods
      .addLiquidity(new anchor.BN(tngAmount), new anchor.BN(solAmount))
      .accounts({
        user: sponsorKeypair.publicKey,
        payer: sponsorKeypair.publicKey,
        swapPool: poolPDA,
        userTngAccount: await getAssociatedTokenAddress(TNG_MINT, sponsorKeypair.publicKey),
        userOtherAccount: sponsorKeypair.publicKey, // SOL account is the keypair itself
        tngMint: TNG_MINT,
        otherMint: SOL_MINT,
        tngVault: tngVault,
        otherVault: solVault,
        tokenProgram: TOKEN_PROGRAM_ID,
        associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      })
      .signers([sponsorKeypair])
      .rpc();

    console.log(' Liquidity added successfully!');
    console.log(' Transaction:', `https://explorer.solana.com/tx/${signature}?cluster=devnet`);
    
  } catch (error) {
    console.error(' Failed to add liquidity:', error);
    if (error.logs) {
      console.log(' Transaction logs:', error.logs);
    }
  }
}

main().catch(console.error);
