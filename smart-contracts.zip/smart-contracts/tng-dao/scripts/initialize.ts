import * as anchor from "@coral-xyz/anchor";
import { Program, AnchorProvider, Wallet } from "@coral-xyz/anchor";
import { 
  PublicKey, 
  Keypair, 
  SystemProgram,
  Connection,
  clusterApiUrl
} from "@solana/web3.js";
import {
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  getAssociatedTokenAddress,
  getOrCreateAssociatedTokenAccount,
  transfer,
  mintTo
} from "@solana/spl-token";
import fs from 'fs';

// Load keypairs
const sponsorKeypair = Keypair.fromSecretKey(
  new Uint8Array(JSON.parse(fs.readFileSync('../../keys/mvp-sponsor-keypair.json', 'utf-8')))
);

// Token mint addresses
const TNG_MINT = new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs");
const SOL_MINT = new PublicKey("So11111111111111111111111111111111111111112"); // Wrapped SOL

async function initialize() {
  // Configure the client to use the devnet cluster
  const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
  const wallet = new Wallet(sponsorKeypair);
  const provider = new AnchorProvider(connection, wallet, {
    commitment: "confirmed",
  });
  anchor.setProvider(provider);

  // Load program
  const idl = JSON.parse(fs.readFileSync('./target/idl/tng_farming.json', 'utf-8'));
  const program = new Program(idl, provider);

  console.log(" Initializing TNG Farming Pool...");
  console.log(" Program ID:", program.programId.toString());
  console.log(" Authority:", sponsorKeypair.publicKey.toString());
  console.log(" TNG Mint:", TNG_MINT.toString());
  console.log(" SOL Mint:", SOL_MINT.toString());

  // Find PDA for farming pool (TNG/SOL pair)
  const [farmingPoolPda, bump] = PublicKey.findProgramAddressSync(
    [Buffer.from("farming_pool"), TNG_MINT.toBuffer(), SOL_MINT.toBuffer()],
    program.programId
  );

  console.log(" Farming Pool PDA:", farmingPoolPda.toString());
  console.log(" Bump:", bump);

  // Get associated token addresses for vaults
  const tngVault = await getAssociatedTokenAddress(
    TNG_MINT,
    farmingPoolPda,
    true
  );

  const solVault = await getAssociatedTokenAddress(
    SOL_MINT,
    farmingPoolPda,
    true
  );

  // Create reward vault keypair (separate from tng_vault)
  const rewardVaultKeypair = Keypair.generate();
  console.log(" Reward Vault:", rewardVaultKeypair.publicKey.toString());

  console.log(" TNG Vault:", tngVault.toString());
  console.log(" SOL Vault:", solVault.toString());

  // Create LP mint (will be created by the program)
  const lpMintKeypair = Keypair.generate();
  console.log(" LP Mint:", lpMintKeypair.publicKey.toString());

  try {
    // Initialize the farming pool
    const initialTngAmount = 1000 * 1e9; // 1000 TNG
    const initialSolAmount = 1 * 1e9;    // 1 SOL  
    const rewardRate = 1000000; // 0.001 TNG per second (very low for testing)

    const tx = await program.methods
      .initializePool(
        new anchor.BN(initialTngAmount),
        new anchor.BN(initialSolAmount),
        new anchor.BN(rewardRate)
      )
      .accounts({
        authority: sponsorKeypair.publicKey,
        payer: sponsorKeypair.publicKey,
        farmingPool: farmingPoolPda,
        tngMint: TNG_MINT,
        otherMint: SOL_MINT,
        tngVault: tngVault,
        otherVault: solVault,
        rewardVault: rewardVaultKeypair.publicKey,
        rewardVaultKeypair: rewardVaultKeypair.publicKey,
        lpMint: lpMintKeypair.publicKey,
        lpMintKeypair: lpMintKeypair.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      })
      .signers([sponsorKeypair, rewardVaultKeypair, lpMintKeypair])
      .rpc();

    console.log(" Farming pool initialized!");
    console.log(" Transaction signature:", tx);
    console.log(" Explorer:", `https://explorer.solana.com/tx/${tx}?cluster=devnet`);

    // Fund reward vault with TNG tokens for farming rewards
    console.log(" Funding reward vault...");
    
    // Get or create sponsor TNG account
    const sponsorTngAccount = await getOrCreateAssociatedTokenAccount(
      connection,
      sponsorKeypair,
      TNG_MINT,
      sponsorKeypair.publicKey
    );

    // Transfer some TNG to reward vault for rewards
    const rewardFundAmount = 100000 * 1e9; // 100,000 TNG for rewards
    
    const fundTx = await transfer(
      connection,
      sponsorKeypair,
      sponsorTngAccount.address,
      rewardVaultKeypair.publicKey,
      sponsorKeypair.publicKey,
      rewardFundAmount
    );

    console.log(" Reward vault funded!");
    console.log(" Fund transaction:", fundTx);

    // Save deployment info
    const deploymentInfo = {
      programId: program.programId.toString(),
      farmingPoolPda: farmingPoolPda.toString(),
      bump,
      tngMint: TNG_MINT.toString(),
      otherMint: SOL_MINT.toString(),
      rewardMint: TNG_MINT.toString(),
      tngVault: tngVault.toString(),
      otherVault: solVault.toString(),
      rewardVault: rewardVaultKeypair.publicKey.toString(),
      lpMint: lpMintKeypair.publicKey.toString(),
      authority: sponsorKeypair.publicKey.toString(),
      network: "devnet",
      initTx: tx,
      fundTx: fundTx,
      explorerUrls: {
        init: `https://explorer.solana.com/tx/${tx}?cluster=devnet`,
        fund: `https://explorer.solana.com/tx/${fundTx}?cluster=devnet`,
        pool: `https://explorer.solana.com/address/${farmingPoolPda}?cluster=devnet`,
        program: `https://explorer.solana.com/address/${program.programId}?cluster=devnet`
      },
      deployedAt: new Date().toISOString()
    };

    fs.writeFileSync('deployment-info.json', JSON.stringify(deploymentInfo, null, 2));
    console.log(" Deployment info saved to deployment-info.json");

    console.log("\n TNG Farming Pool successfully deployed and initialized!");
    console.log(" Pool Stats:");
    console.log(`   • TNG Reserve: ${initialTngAmount / 1e9} TNG`);
    console.log(`   • SOL Reserve: ${initialSolAmount / 1e9} SOL`);
    console.log(`   • Reward Rate: ${rewardRate / 1e6} TNG/second`);
    console.log(`   • Reward Vault Funded: ${rewardFundAmount / 1e9} TNG`);

  } catch (error) {
    console.error(" Error initializing farming pool:", error);
    throw error;
  }
}

initialize().catch(console.error);