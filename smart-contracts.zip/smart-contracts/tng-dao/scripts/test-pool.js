/**
 * Test TNG Swap Pool
 * Check pool state and perform test swap
 */

const anchor = require('@coral-xyz/anchor')
const { Connection, PublicKey } = require('@solana/web3.js')
const fs = require('fs')
const path = require('path')

// Program ID and addresses from deployment-info.json
const TNG_SWAP_PROGRAM_ID = new PublicKey('FWfcH4Zcp8HztJFqui3wX3AkG9XjV9PoKnNPCgsctSVV')
const TNG_SOL_POOL_PDA = new PublicKey('6KBzJYcyh1DXduboH113HB8L6hLFQPw3xTT2vDpZjyA7')

async function main() {
  console.log(' Testing TNG Swap Pool...')

  // Setup connection
  const connection = new Connection('https://api.devnet.solana.com', 'confirmed')
  
  // Load sponsor keypair
  const sponsorKeypairPath = path.join(__dirname, '../keys/mvp-sponsor-keypair.json')
  const sponsorKeypair = anchor.web3.Keypair.fromSecretKey(
    new Uint8Array(JSON.parse(fs.readFileSync(sponsorKeypairPath, 'utf8')))
  )
  
  console.log(' Sponsor:', sponsorKeypair.publicKey.toBase58())

  // Setup provider
  const wallet = new anchor.Wallet(sponsorKeypair)
  const provider = new anchor.AnchorProvider(connection, wallet, {
    commitment: 'confirmed'
  })
  anchor.setProvider(provider)

  // Load program
  const idlPath = path.join(__dirname, '../target/idl/tng_swap.json')
  const idl = JSON.parse(fs.readFileSync(idlPath, 'utf8'))
  const program = new anchor.Program(idl, provider)

  console.log(' Program loaded:', program.programId.toBase58())

  // Check pool state
  try {
    console.log('\n Checking TNG/SOL pool state...')
    
    const poolAccount = await connection.getAccountInfo(TNG_SOL_POOL_PDA)
    if (!poolAccount) {
      console.log(' Pool account not found')
      return
    }
    
    console.log(' Pool account exists:', {
      address: TNG_SOL_POOL_PDA.toBase58(),
      owner: poolAccount.owner.toBase58(),
      dataLength: poolAccount.data.length,
      lamports: poolAccount.lamports / 1e9 + ' SOL'
    })

    // Try to fetch pool data using program
    try {
      const poolData = await program.account.swapPool.fetch(TNG_SOL_POOL_PDA)
      console.log(' Pool data:', {
        authority: poolData.authority.toBase58(),
        tngMint: poolData.tngMint.toBase58(),
        otherMint: poolData.otherMint.toBase58(),
        tngReserve: (poolData.tngReserve.toNumber() / 1e9).toFixed(2) + ' TNG',
        otherReserve: (poolData.otherReserve.toNumber() / 1e9).toFixed(4) + ' SOL',
        isActive: poolData.isActive
      })
      
      // Calculate current exchange rate
      const tngPerSol = poolData.tngReserve.toNumber() / poolData.otherReserve.toNumber()
      const solPerTng = poolData.otherReserve.toNumber() / poolData.tngReserve.toNumber()
      
      console.log(' Current rates:', {
        tngPerSol: tngPerSol.toFixed(2) + ' TNG per SOL',
        solPerTng: (solPerTng * 1e9).toFixed(9) + ' lamports per TNG'
      })

      console.log('\n TNG/SOL pool is ready for swaps!')
      
    } catch (error) {
      console.log(' Failed to fetch pool data:', error.message)
    }

  } catch (error) {
    console.error(' Error checking pool:', error)
  }
}

main().catch(console.error)
