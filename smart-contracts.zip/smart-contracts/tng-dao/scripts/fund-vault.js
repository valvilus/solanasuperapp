/**
 * Fund SOL vault directly
 */

const { 
  Connection, 
  PublicKey, 
  Keypair,
  SystemProgram,
  Transaction,
  LAMPORTS_PER_SOL 
} = require('@solana/web3.js');
const { 
  getAssociatedTokenAddress,
  createTransferInstruction,
  getOrCreateAssociatedTokenAccount
} = require('@solana/spl-token');
const fs = require('fs');

// Constants  
const TNG_SWAP_PROGRAM_ID = new PublicKey('FWfcH4Zcp8HztJFqui3wX3AkG9XjV9PoKnNPCgsctSVV');
const TNG_MINT = new PublicKey('FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs');
const SOL_MINT = new PublicKey('So11111111111111111111111111111111111111112');

async function main() {
  console.log(' Funding SOL vault directly...');
  
  // Setup connection
  const connection = new Connection('https://api.devnet.solana.com', 'confirmed');
  
  // Load sponsor keypair
  const sponsorKeypair = Keypair.fromSecretKey(
    Uint8Array.from(JSON.parse(fs.readFileSync('./keys/mvp-sponsor-keypair.json', 'utf8')))
  );
  console.log(' Sponsor:', sponsorKeypair.publicKey.toBase58());
  
  // Calculate pool PDA and SOL vault
  const [poolPDA] = PublicKey.findProgramAddressSync(
    [Buffer.from('swap_pool'), TNG_MINT.toBuffer(), SOL_MINT.toBuffer()],
    TNG_SWAP_PROGRAM_ID
  );
  
  const solVault = await getAssociatedTokenAddress(SOL_MINT, poolPDA, true);
  
  console.log(' Pool PDA:', poolPDA.toBase58());
  console.log(' SOL Vault:', solVault.toBase58());

  // Check current vault balance
  try {
    const vaultBalance = await connection.getBalance(solVault);
    console.log(' Current SOL Vault balance:', vaultBalance / LAMPORTS_PER_SOL, 'SOL');
  } catch (error) {
    console.log(' SOL Vault does not exist yet');
  }

  // Create/fund SOL vault with wrapped SOL
  try {
    const solVaultAccount = await getOrCreateAssociatedTokenAccount(
      connection,
      sponsorKeypair,
      SOL_MINT, // Wrapped SOL
      poolPDA,
      true // allowOwnerOffCurve
    );
    
    console.log(' SOL Vault account:', solVaultAccount.address.toBase58());
    
    // Transfer 5 SOL to vault
    const transferAmount = 5 * LAMPORTS_PER_SOL;
    
    const transferInstruction = createTransferInstruction(
      sponsorKeypair.publicKey, // from (sponsor's SOL)
      solVaultAccount.address,  // to (vault)
      sponsorKeypair.publicKey, // authority
      transferAmount
    );
    
    const transaction = new Transaction().add(transferInstruction);
    
    const signature = await connection.sendTransaction(transaction, [sponsorKeypair]);
    console.log(' SOL transferred to vault!');
    console.log(' Transaction:', `https://explorer.solana.com/tx/${signature}?cluster=devnet`);
    
    // Verify new balance
    const newBalance = await connection.getBalance(solVaultAccount.address);
    console.log(' New SOL Vault balance:', newBalance / LAMPORTS_PER_SOL, 'SOL');
    
  } catch (error) {
    console.error(' Failed to fund SOL vault:', error);
  }
}

main().catch(console.error);
