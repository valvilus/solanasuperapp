import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { TngDao } from "../target/types/tng_dao";
import { 
  PublicKey, 
  Keypair, 
  SystemProgram, 
  LAMPORTS_PER_SOL,
  Transaction,
} from "@solana/web3.js";
import { 
  TOKEN_PROGRAM_ID, 
  ASSOCIATED_TOKEN_PROGRAM_ID,
  createMint,
  createAccount,
  mintTo,
  getAccount,
} from "@solana/spl-token";
import { expect } from "chai";

describe("tng-dao", () => {
  // Configure the client to use the local cluster
  anchor.setProvider(anchor.AnchorProvider.env());

  const program = anchor.workspace.TngDao as Program<TngDao>;
  const provider = anchor.AnchorProvider.env();
  
  // Test accounts
  let authority: Keypair;
  let sponsor: Keypair;
  let creator: Keypair;
  let voter1: Keypair;
  let voter2: Keypair;
  
  // Token accounts
  let tngMint: PublicKey;
  let daoConfig: PublicKey;
  let treasury: PublicKey;
  
  // Test constants
  const VOTING_DURATION = 7 * 24 * 60 * 60; // 7 days
  const EXECUTION_DELAY = 24 * 60 * 60; // 24 hours
  const QUORUM_THRESHOLD = 1000 * 1_000_000_000; // 1000 TNG
  const PROPOSAL_THRESHOLD = 100 * 1_000_000_000; // 100 TNG

  before(async () => {
    // Initialize test accounts
    authority = Keypair.generate();
    sponsor = Keypair.generate();
    creator = Keypair.generate();
    voter1 = Keypair.generate();
    voter2 = Keypair.generate();

    // Airdrop SOL to test accounts
    await provider.connection.requestAirdrop(authority.publicKey, 2 * LAMPORTS_PER_SOL);
    await provider.connection.requestAirdrop(sponsor.publicKey, 2 * LAMPORTS_PER_SOL);
    await provider.connection.requestAirdrop(creator.publicKey, 2 * LAMPORTS_PER_SOL);
    await provider.connection.requestAirdrop(voter1.publicKey, 2 * LAMPORTS_PER_SOL);
    await provider.connection.requestAirdrop(voter2.publicKey, 2 * LAMPORTS_PER_SOL);

    // Create TNG mint
    tngMint = await createMint(
      provider.connection,
      authority,
      authority.publicKey,
      null,
      9 // 9 decimals
    );

    // Derive PDA addresses
    [daoConfig] = PublicKey.findProgramAddressSync(
      [Buffer.from("dao_config")],
      program.programId
    );

    [treasury] = PublicKey.findProgramAddressSync(
      [Buffer.from("treasury")],
      program.programId
    );

    console.log("Setup completed");
    console.log("TNG Mint:", tngMint.toString());
    console.log("DAO Config:", daoConfig.toString());
    console.log("Treasury:", treasury.toString());
  });

  it("Initializes DAO", async () => {
    try {
      const tx = await program.methods
        .initializeDao(
          new anchor.BN(VOTING_DURATION),
          new anchor.BN(EXECUTION_DELAY),
          new anchor.BN(QUORUM_THRESHOLD),
          new anchor.BN(PROPOSAL_THRESHOLD)
        )
        .accounts({
          authority: authority.publicKey,
          payer: sponsor.publicKey,
          daoConfig,
          treasury,
          tngMint,
          tokenProgram: TOKEN_PROGRAM_ID,
          systemProgram: SystemProgram.programId,
        })
        .signers([authority, sponsor])
        .rpc();

      console.log("DAO initialized. Transaction:", tx);

      // Verify DAO config
      const daoConfigAccount = await program.account.daoConfig.fetch(daoConfig);
      expect(daoConfigAccount.authority.toString()).to.equal(authority.publicKey.toString());
      expect(daoConfigAccount.tngMint.toString()).to.equal(tngMint.toString());
      expect(daoConfigAccount.votingDuration.toNumber()).to.equal(VOTING_DURATION);
      expect(daoConfigAccount.executionDelay.toNumber()).to.equal(EXECUTION_DELAY);
      expect(daoConfigAccount.quorumThreshold.toString()).to.equal(QUORUM_THRESHOLD.toString());
      expect(daoConfigAccount.proposalThreshold.toString()).to.equal(PROPOSAL_THRESHOLD.toString());
      expect(daoConfigAccount.totalProposals.toNumber()).to.equal(0);

    } catch (error) {
      console.error("Error initializing DAO:", error);
      throw error;
    }
  });

  it("Creates a proposal", async () => {
    try {
      // Create TNG token account for creator and mint tokens
      const creatorTngAccount = await createAccount(
        provider.connection,
        creator,
        tngMint,
        creator.publicKey
      );

      // Mint TNG tokens to creator (enough to create proposal)
      await mintTo(
        provider.connection,
        authority,
        tngMint,
        creatorTngAccount,
        authority,
        PROPOSAL_THRESHOLD * 2 // Mint 2x proposal threshold
      );

      // Define proposal actions
      const actions = [
        {
          updateStakingApy: { newApy: 1500 } // 15% APY
        }
      ];

      // Derive proposal PDA
      const [proposalPda] = PublicKey.findProgramAddressSync(
        [
          Buffer.from("proposal"),
          new anchor.BN(0).toArrayLike(Buffer, "le", 8) // proposal ID 0
        ],
        program.programId
      );

      const tx = await program.methods
        .createProposal(
          "Update Staking APY",
          "Proposal to increase staking APY to 15%",
          actions
        )
        .accounts({
          creator: creator.publicKey,
          payer: sponsor.publicKey,
          daoConfig,
          proposal: proposalPda,
          creatorTngAccount,
          systemProgram: SystemProgram.programId,
        })
        .signers([creator, sponsor])
        .rpc();

      console.log("Proposal created. Transaction:", tx);

      // Verify proposal
      const proposalAccount = await program.account.proposal.fetch(proposalPda);
      expect(proposalAccount.id.toNumber()).to.equal(0);
      expect(proposalAccount.creator.toString()).to.equal(creator.publicKey.toString());
      expect(proposalAccount.title).to.equal("Update Staking APY");
      expect(proposalAccount.description).to.equal("Proposal to increase staking APY to 15%");
      expect(proposalAccount.actions.length).to.equal(1);
      expect(proposalAccount.votesFor.toNumber()).to.equal(0);
      expect(proposalAccount.votesAgainst.toNumber()).to.equal(0);
      expect(proposalAccount.votesAbstain.toNumber()).to.equal(0);

      // Verify DAO config updated
      const daoConfigAccount = await program.account.daoConfig.fetch(daoConfig);
      expect(daoConfigAccount.totalProposals.toNumber()).to.equal(1);

    } catch (error) {
      console.error("Error creating proposal:", error);
      throw error;
    }
  });

  it("Casts votes on proposal", async () => {
    try {
      // Create TNG token accounts for voters and mint tokens
      const voter1TngAccount = await createAccount(
        provider.connection,
        voter1,
        tngMint,
        voter1.publicKey
      );

      const voter2TngAccount = await createAccount(
        provider.connection,
        voter2,
        tngMint,
        voter2.publicKey
      );

      // Mint voting power to voters
      const voter1Power = 500 * 1_000_000_000; // 500 TNG
      const voter2Power = 600 * 1_000_000_000; // 600 TNG

      await mintTo(
        provider.connection,
        authority,
        tngMint,
        voter1TngAccount,
        authority,
        voter1Power
      );

      await mintTo(
        provider.connection,
        authority,
        tngMint,
        voter2TngAccount,
        authority,
        voter2Power
      );

      // Derive PDAs
      const [proposalPda] = PublicKey.findProgramAddressSync(
        [
          Buffer.from("proposal"),
          new anchor.BN(0).toArrayLike(Buffer, "le", 8)
        ],
        program.programId
      );

      const [vote1Pda] = PublicKey.findProgramAddressSync(
        [
          Buffer.from("vote"),
          voter1.publicKey.toBuffer(),
          proposalPda.toBuffer()
        ],
        program.programId
      );

      const [vote2Pda] = PublicKey.findProgramAddressSync(
        [
          Buffer.from("vote"),
          voter2.publicKey.toBuffer(),
          proposalPda.toBuffer()
        ],
        program.programId
      );

      // Voter 1 votes FOR
      const tx1 = await program.methods
        .vote({ for: {} }, new anchor.BN(voter1Power))
        .accounts({
          voter: voter1.publicKey,
          proposal: proposalPda,
          voteRecord: vote1Pda,
          voterTngAccount: voter1TngAccount,
          daoConfig,
          systemProgram: SystemProgram.programId,
        })
        .signers([voter1])
        .rpc();

      console.log("Vote 1 cast. Transaction:", tx1);

      // Voter 2 votes AGAINST
      const tx2 = await program.methods
        .vote({ against: {} }, new anchor.BN(voter2Power))
        .accounts({
          voter: voter2.publicKey,
          proposal: proposalPda,
          voteRecord: vote2Pda,
          voterTngAccount: voter2TngAccount,
          daoConfig,
          systemProgram: SystemProgram.programId,
        })
        .signers([voter2])
        .rpc();

      console.log("Vote 2 cast. Transaction:", tx2);

      // Verify votes were recorded
      const proposalAccount = await program.account.proposal.fetch(proposalPda);
      expect(proposalAccount.votesFor.toString()).to.equal(voter1Power.toString());
      expect(proposalAccount.votesAgainst.toString()).to.equal(voter2Power.toString());
      expect(proposalAccount.votesAbstain.toNumber()).to.equal(0);

      // Verify vote records
      const vote1Record = await program.account.voteRecord.fetch(vote1Pda);
      expect(vote1Record.voter.toString()).to.equal(voter1.publicKey.toString());
      expect(vote1Record.weight.toString()).to.equal(voter1Power.toString());

      const vote2Record = await program.account.voteRecord.fetch(vote2Pda);
      expect(vote2Record.voter.toString()).to.equal(voter2.publicKey.toString());
      expect(vote2Record.weight.toString()).to.equal(voter2Power.toString());

    } catch (error) {
      console.error("Error casting votes:", error);
      throw error;
    }
  });

  it("Funds treasury", async () => {
    try {
      // Create TNG token account for funder
      const funderTngAccount = await createAccount(
        provider.connection,
        authority,
        tngMint,
        authority.publicKey
      );

      // Mint TNG tokens to funder
      const fundAmount = 10000 * 1_000_000_000; // 10,000 TNG
      await mintTo(
        provider.connection,
        authority,
        tngMint,
        funderTngAccount,
        authority,
        fundAmount
      );

      const tx = await program.methods
        .fundTreasury(new anchor.BN(fundAmount))
        .accounts({
          funder: authority.publicKey,
          treasury,
          funderTokenAccount: funderTngAccount,
          tokenProgram: TOKEN_PROGRAM_ID,
        })
        .signers([authority])
        .rpc();

      console.log("Treasury funded. Transaction:", tx);

      // Verify treasury balance
      const treasuryAccount = await getAccount(provider.connection, treasury);
      expect(treasuryAccount.amount.toString()).to.equal(fundAmount.toString());

    } catch (error) {
      console.error("Error funding treasury:", error);
      throw error;
    }
  });

  // Note: Testing finalize_proposal and execute_action would require 
  // waiting for voting period to end, which is not practical in unit tests.
  // These would be better tested in integration tests with shorter durations.
});










