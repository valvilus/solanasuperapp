use anchor_lang::prelude::*;
use anchor_spl::token::{Token, TokenAccount, Transfer};

declare_id!("6xgE4u61Hat3rLyn6VnTFq1KCQ9oWSgGXgEqaCN6LqLm");

const BASIS_POINTS: u64 = 10000;
const MAX_COVERAGE_RATIO: u64 = 8000; // 80%
const MIN_PREMIUM_RATE: u64 = 50; // 0.5%

#[program]
pub mod tng_insurance {
    use super::*;
    
    pub fn create_insurance_pool(
        ctx: Context<CreateInsurancePool>,
        protected_protocol: Pubkey,
        coverage_amount: u64,
        premium_rate: u64,
    ) -> Result<()> {
        require!(premium_rate >= MIN_PREMIUM_RATE, ErrorCode::PremiumRateTooLow);
        require!(coverage_amount > 0, ErrorCode::InvalidCoverageAmount);
        
        let pool = &mut ctx.accounts.insurance_pool;
        pool.pool_id = ctx.accounts.insurance_pool.key().to_bytes()[0..8].try_into().unwrap();
        pool.authority = ctx.accounts.authority.key();
        pool.protected_protocol = protected_protocol;
        pool.coverage_amount = coverage_amount;
        pool.premium_rate = premium_rate;
        pool.total_premiums = 0;
        pool.total_claims = 0;
        pool.total_deposits = 0;
        pool.is_active = true;
        pool.created_at = Clock::get()?.unix_timestamp;
        pool.bump = ctx.bumps.insurance_pool;
        
        Ok(())
    }
    
    pub fn purchase_policy(
        ctx: Context<PurchasePolicy>,
        pool_id: [u8; 8],
        coverage_amount: u64,
        duration: i64,
    ) -> Result<()> {
        let pool = &mut ctx.accounts.insurance_pool;
        let policy = &mut ctx.accounts.insurance_policy;
        
        require!(pool.is_active, ErrorCode::PoolInactive);
        require!(coverage_amount > 0, ErrorCode::InvalidCoverageAmount);
        require!(duration > 0, ErrorCode::InvalidDuration);
        require!(coverage_amount <= pool.coverage_amount, ErrorCode::ExcessiveCoverageRequest);
        
        let annual_premium = (coverage_amount as u128)
            .checked_mul(pool.premium_rate as u128)
            .ok_or(ErrorCode::MathOverflow)?
            .checked_div(BASIS_POINTS as u128)
            .ok_or(ErrorCode::MathOverflow)? as u64;
        
        let total_premium = (annual_premium as u128)
            .checked_mul(duration as u128)
            .ok_or(ErrorCode::MathOverflow)?
            .checked_div(31536000u128) // seconds per year
            .ok_or(ErrorCode::MathOverflow)? as u64;
        
        policy.policy_id = ctx.accounts.insurance_policy.key().to_bytes()[0..8].try_into().unwrap();
        policy.user = ctx.accounts.user.key();
        policy.pool_id = pool_id;
        policy.coverage_amount = coverage_amount;
        policy.premium_paid = total_premium;
        policy.start_time = Clock::get()?.unix_timestamp;
        policy.expiry_time = policy.start_time + duration;
        policy.is_active = true;
        policy.claims_count = 0;
        policy.bump = ctx.bumps.insurance_policy;
        
        pool.total_premiums = pool.total_premiums
            .checked_add(total_premium)
            .ok_or(ErrorCode::MathOverflow)?;
        
        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.user_token_account.to_account_info(),
                to: ctx.accounts.pool_vault.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_ctx, total_premium)?;
        
        Ok(())
    }
    
    pub fn file_claim(
        ctx: Context<FileClaim>,
        policy_id: [u8; 8],
        claim_amount: u64,
        evidence: Vec<u8>,
    ) -> Result<()> {
        let policy = &ctx.accounts.insurance_policy;
        let claim = &mut ctx.accounts.insurance_claim;
        
        require!(policy.is_active, ErrorCode::PolicyInactive);
        require!(claim_amount > 0, ErrorCode::InvalidClaimAmount);
        require!(claim_amount <= policy.coverage_amount, ErrorCode::ExcessiveClaimAmount);
        
        let current_time = Clock::get()?.unix_timestamp;
        require!(current_time >= policy.start_time, ErrorCode::PolicyNotStarted);
        require!(current_time <= policy.expiry_time, ErrorCode::PolicyExpired);
        
        claim.claim_id = ctx.accounts.insurance_claim.key().to_bytes()[0..8].try_into().unwrap();
        claim.policy_id = policy_id;
        claim.claimant = ctx.accounts.user.key();
        claim.claim_amount = claim_amount;
        claim.evidence_hash = if evidence.is_empty() { 
            [0u8; 32] 
        } else { 
            anchor_lang::solana_program::hash::hash(&evidence).to_bytes() 
        };
        claim.status = ClaimStatus::Pending;
        claim.payout_amount = 0;
        claim.filed_at = current_time;
        claim.processed_at = None;
        claim.bump = ctx.bumps.insurance_claim;
        
        Ok(())
    }
    
    pub fn process_claim(
        ctx: Context<ProcessClaim>,
        claim_id: [u8; 8],
        approved: bool,
        payout_amount: u64,
    ) -> Result<()> {
        let pool = &mut ctx.accounts.insurance_pool;
        let policy = &mut ctx.accounts.insurance_policy;
        let claim = &mut ctx.accounts.insurance_claim;
        
        require!(
            ctx.accounts.authority.key() == pool.authority,
            ErrorCode::Unauthorized
        );
        require!(claim.status == ClaimStatus::Pending, ErrorCode::ClaimAlreadyProcessed);
        
        if approved {
            require!(payout_amount > 0, ErrorCode::InvalidPayoutAmount);
            require!(payout_amount <= claim.claim_amount, ErrorCode::ExcessivePayoutAmount);
            require!(payout_amount <= pool.total_deposits, ErrorCode::InsufficientPoolFunds);
            
            claim.status = ClaimStatus::Approved;
            claim.payout_amount = payout_amount;
            
            pool.total_claims = pool.total_claims
                .checked_add(payout_amount)
                .ok_or(ErrorCode::MathOverflow)?;
            
            pool.total_deposits = pool.total_deposits
                .checked_sub(payout_amount)
                .ok_or(ErrorCode::MathOverflow)?;
            
            policy.claims_count = policy.claims_count
                .checked_add(1)
                .ok_or(ErrorCode::MathOverflow)?;
            
            let transfer_ctx = CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.pool_vault.to_account_info(),
                    to: ctx.accounts.claimant_token_account.to_account_info(),
                    authority: ctx.accounts.pool_authority.to_account_info(),
                },
            );
            anchor_spl::token::transfer(transfer_ctx, payout_amount)?;
            
        } else {
            claim.status = ClaimStatus::Rejected;
        }
        
        claim.processed_at = Some(Clock::get()?.unix_timestamp);
        
        Ok(())
    }
    
    pub fn deposit_to_pool(
        ctx: Context<DepositToPool>,
        amount: u64,
    ) -> Result<()> {
        let pool = &mut ctx.accounts.insurance_pool;
        
        require!(pool.is_active, ErrorCode::PoolInactive);
        require!(amount > 0, ErrorCode::InvalidDepositAmount);
        
        pool.total_deposits = pool.total_deposits
            .checked_add(amount)
            .ok_or(ErrorCode::MathOverflow)?;
        
        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.depositor_token_account.to_account_info(),
                to: ctx.accounts.pool_vault.to_account_info(),
                authority: ctx.accounts.depositor.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_ctx, amount)?;
        
        Ok(())
    }
    
    pub fn withdraw_from_pool(
        ctx: Context<WithdrawFromPool>,
        amount: u64,
    ) -> Result<()> {
        let pool = &mut ctx.accounts.insurance_pool;
        
        require!(
            ctx.accounts.authority.key() == pool.authority,
            ErrorCode::Unauthorized
        );
        require!(amount > 0, ErrorCode::InvalidWithdrawAmount);
        require!(amount <= pool.total_deposits, ErrorCode::InsufficientPoolFunds);
        
        let reserved_for_claims = pool.total_premiums
            .checked_mul(MAX_COVERAGE_RATIO)
            .ok_or(ErrorCode::MathOverflow)?
            .checked_div(BASIS_POINTS)
            .ok_or(ErrorCode::MathOverflow)?;
        
        let available_for_withdrawal = pool.total_deposits
            .checked_sub(reserved_for_claims)
            .ok_or(ErrorCode::InsufficientPoolFunds)?;
        
        require!(amount <= available_for_withdrawal, ErrorCode::ExcessiveWithdrawAmount);
        
        pool.total_deposits = pool.total_deposits
            .checked_sub(amount)
            .ok_or(ErrorCode::MathOverflow)?;
        
        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.pool_vault.to_account_info(),
                to: ctx.accounts.authority_token_account.to_account_info(),
                authority: ctx.accounts.pool_authority.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_ctx, amount)?;
        
        Ok(())
    }
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq)]
pub enum ClaimStatus {
    Pending,
    Approved,
    Rejected,
    Paid,
}

#[account]
pub struct InsurancePool {
    pub pool_id: [u8; 8],
    pub authority: Pubkey,
    pub protected_protocol: Pubkey,
    pub coverage_amount: u64,
    pub premium_rate: u64,
    pub total_premiums: u64,
    pub total_claims: u64,
    pub total_deposits: u64,
    pub is_active: bool,
    pub created_at: i64,
    pub bump: u8,
}

#[account]
pub struct InsurancePolicy {
    pub policy_id: [u8; 8],
    pub user: Pubkey,
    pub pool_id: [u8; 8],
    pub coverage_amount: u64,
    pub premium_paid: u64,
    pub start_time: i64,
    pub expiry_time: i64,
    pub is_active: bool,
    pub claims_count: u32,
    pub bump: u8,
}

#[account]
pub struct InsuranceClaim {
    pub claim_id: [u8; 8],
    pub policy_id: [u8; 8],
    pub claimant: Pubkey,
    pub claim_amount: u64,
    pub evidence_hash: [u8; 32],
    pub status: ClaimStatus,
    pub payout_amount: u64,
    pub filed_at: i64,
    pub processed_at: Option<i64>,
    pub bump: u8,
}

#[derive(Accounts)]
pub struct CreateInsurancePool<'info> {
    #[account(
        init,
        payer = authority,
        space = 8 + 8 + 32 + 32 + 8 + 8 + 8 + 8 + 8 + 1 + 8 + 1,
        seeds = [b"insurance_pool", authority.key().as_ref()],
        bump
    )]
    pub insurance_pool: Account<'info, InsurancePool>,
    
    #[account(mut)]
    pub authority: Signer<'info>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(pool_id: [u8; 8])]
pub struct PurchasePolicy<'info> {
    #[account(
        mut,
        seeds = [b"insurance_pool", insurance_pool.authority.as_ref()],
        bump = insurance_pool.bump
    )]
    pub insurance_pool: Account<'info, InsurancePool>,
    
    #[account(
        init,
        payer = user,
        space = 8 + 8 + 32 + 8 + 8 + 8 + 8 + 8 + 1 + 4 + 1,
        seeds = [b"insurance_policy", user.key().as_ref(), &pool_id],
        bump
    )]
    pub insurance_policy: Account<'info, InsurancePolicy>,
    
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub pool_vault: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(policy_id: [u8; 8])]
pub struct FileClaim<'info> {
    #[account(
        seeds = [b"insurance_policy", user.key().as_ref(), &policy_id],
        bump = insurance_policy.bump
    )]
    pub insurance_policy: Account<'info, InsurancePolicy>,
    
    #[account(
        init,
        payer = user,
        space = 8 + 8 + 8 + 32 + 8 + 32 + 1 + 8 + 8 + 9 + 1,
        seeds = [b"insurance_claim", user.key().as_ref(), &policy_id],
        bump
    )]
    pub insurance_claim: Account<'info, InsuranceClaim>,
    
    #[account(mut)]
    pub user: Signer<'info>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(claim_id: [u8; 8])]
pub struct ProcessClaim<'info> {
    #[account(
        mut,
        seeds = [b"insurance_pool", authority.key().as_ref()],
        bump = insurance_pool.bump
    )]
    pub insurance_pool: Account<'info, InsurancePool>,
    
    #[account(
        mut,
        seeds = [b"insurance_policy", insurance_claim.claimant.as_ref(), &insurance_claim.policy_id],
        bump = insurance_policy.bump
    )]
    pub insurance_policy: Account<'info, InsurancePolicy>,
    
    #[account(mut)]
    pub insurance_claim: Account<'info, InsuranceClaim>,
    
    pub authority: Signer<'info>,
    
    /// CHECK: Pool authority PDA
    pub pool_authority: AccountInfo<'info>,
    
    #[account(mut)]
    pub pool_vault: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub claimant_token_account: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct DepositToPool<'info> {
    #[account(mut)]
    pub insurance_pool: Account<'info, InsurancePool>,
    
    #[account(mut)]
    pub depositor: Signer<'info>,
    
    #[account(mut)]
    pub depositor_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub pool_vault: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct WithdrawFromPool<'info> {
    #[account(mut)]
    pub insurance_pool: Account<'info, InsurancePool>,
    
    pub authority: Signer<'info>,
    
    /// CHECK: Pool authority PDA
    pub pool_authority: AccountInfo<'info>,
    
    #[account(mut)]
    pub pool_vault: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub authority_token_account: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
}

#[error_code]
pub enum ErrorCode {
    #[msg("Premium rate too low")]
    PremiumRateTooLow,
    #[msg("Invalid coverage amount")]
    InvalidCoverageAmount,
    #[msg("Pool inactive")]
    PoolInactive,
    #[msg("Invalid duration")]
    InvalidDuration,
    #[msg("Excessive coverage request")]
    ExcessiveCoverageRequest,
    #[msg("Math overflow")]
    MathOverflow,
    #[msg("Policy inactive")]
    PolicyInactive,
    #[msg("Invalid claim amount")]
    InvalidClaimAmount,
    #[msg("Excessive claim amount")]
    ExcessiveClaimAmount,
    #[msg("Policy not started")]
    PolicyNotStarted,
    #[msg("Policy expired")]
    PolicyExpired,
    #[msg("Unauthorized")]
    Unauthorized,
    #[msg("Claim already processed")]
    ClaimAlreadyProcessed,
    #[msg("Invalid payout amount")]
    InvalidPayoutAmount,
    #[msg("Excessive payout amount")]
    ExcessivePayoutAmount,
    #[msg("Insufficient pool funds")]
    InsufficientPoolFunds,
    #[msg("Invalid deposit amount")]
    InvalidDepositAmount,
    #[msg("Invalid withdraw amount")]
    InvalidWithdrawAmount,
    #[msg("Excessive withdraw amount")]
    ExcessiveWithdrawAmount,
}

