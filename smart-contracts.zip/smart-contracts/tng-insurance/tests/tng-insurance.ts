import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { TngInsurance } from "../target/types/tng_insurance";

describe("tng-insurance", () => {
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  const program = anchor.workspace.TngInsurance as Program<TngInsurance>;

  it("Creates insurance pool!", async () => {
    const protectedProtocol = anchor.web3.Keypair.generate().publicKey;
    const coverageAmount = new anchor.BN(1000000);
    const premiumRate = 100; // 1%
    
    const tx = await program.methods
      .createInsurancePool(protectedProtocol, coverageAmount, premiumRate)
      .accounts({
        authority: provider.wallet.publicKey,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .rpc();

    console.log("Insurance pool created with signature:", tx);
  });
});

