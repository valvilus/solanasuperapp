import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { TngFarming } from "../target/types/tng_farming";

describe("tng-farming", () => {
  // Configure the client to use the local cluster.
  anchor.setProvider(anchor.AnchorProvider.env());

  const program = anchor.workspace.TngFarming as Program<TngFarming>;

  it("Is initialized!", async () => {
    // Add your test here.
    console.log("Your transaction signature", "test");
  });
});
