/**
 * TNG Farming - Liquidity Pool and Yield Farming
 * Supports: TNG/SOL, TNG/USDC LP Farming with Rewards
 * Solana SuperApp
 */

use anchor_lang::prelude::*;
use anchor_spl::{
    associated_token::AssociatedToken,
    token::{self, Mint, Token, TokenAccount, Transfer, MintTo, Burn},
};

declare_id!("12wefd8c4mZ1YzuYLAzVJWge5hZx2Ey96fdpVSxRTC9F");

#[program]
pub mod tng_farming {
    use super::*;

    /// Initialize the farming pool     
    pub fn initialize_pool(
        ctx: Context<InitializePool>,
        tng_reserve: u64,
        other_reserve: u64,
        reward_rate: u64,
    ) -> Result<()> {
        msg!("Initializing TNG farming pool");
        
        let pool = &mut ctx.accounts.farming_pool;
        pool.authority = ctx.accounts.authority.key();
        pool.tng_mint = ctx.accounts.tng_mint.key();
        pool.other_mint = ctx.accounts.other_mint.key();
        pool.tng_vault = ctx.accounts.tng_vault.key();
        pool.other_vault = ctx.accounts.other_vault.key();
        pool.lp_mint = ctx.accounts.lp_mint.key();
        pool.reward_vault = ctx.accounts.reward_vault.key();
        pool.tng_reserve = tng_reserve;
        pool.other_reserve = other_reserve;
        pool.lp_supply = 0;
        pool.total_staked = 0;
        pool.reward_rate = reward_rate;
        pool.last_reward_time = Clock::get()?.unix_timestamp;
        pool.accumulated_reward_per_share = 0;
        pool.bump = ctx.bumps.farming_pool;
        pool.is_active = true;

        msg!("Farming pool initialized successfully");
        msg!("TNG Reserve: {}", tng_reserve);
        msg!("Other Reserve: {}", other_reserve);
        msg!("Reward Rate: {} per second", reward_rate);
        msg!("Pool Authority: {}", pool.authority);

        Ok(())
    }

    /// Add liquidity to get LP tokens with proper ratio validation
    pub fn add_liquidity(
        ctx: Context<AddLiquidity>,
        tng_amount: u64,
        other_amount: u64,
        minimum_lp_tokens: u64,
    ) -> Result<()> {
        let pool = &mut ctx.accounts.farming_pool;
        
        msg!("Adding liquidity to farming pool");
        msg!("TNG Amount: {}", tng_amount);
        msg!("Other Amount: {}", other_amount);
        msg!("Minimum LP tokens: {}", minimum_lp_tokens);
        msg!("User: {}", ctx.accounts.user.key());
        msg!("Payer: {}", ctx.accounts.payer.key());

        require!(pool.is_active, FarmingError::PoolInactive);
        require!(tng_amount > 0 && other_amount > 0, FarmingError::InvalidAmount);

        // Calculate LP tokens to mint and validate ratios
        let lp_tokens = if pool.lp_supply == 0 {
            // Initial liquidity - use geometric mean
            let product = (tng_amount as u128)
                .checked_mul(other_amount as u128)
                .ok_or(FarmingError::MathOverflow)?;
            
            // Simple integer square root
            let mut lp = (product as f64).sqrt() as u64;
            
            // Minimum liquidity lock (like Uniswap)
            if lp > 1000 {
                lp = lp.checked_sub(1000).ok_or(FarmingError::MathOverflow)?;
            }
            
            require!(lp >= minimum_lp_tokens, FarmingError::SlippageExceeded);
            lp
        } else {
            // Subsequent liquidity - validate ratio and apply slippage protection
            let expected_other_amount = (tng_amount as u128)
                .checked_mul(pool.other_reserve as u128)
                .ok_or(FarmingError::MathOverflow)?
                .checked_div(pool.tng_reserve as u128)
                .ok_or(FarmingError::MathOverflow)? as u64;
            
            let expected_tng_amount = (other_amount as u128)
                .checked_mul(pool.tng_reserve as u128)
                .ok_or(FarmingError::MathOverflow)?
                .checked_div(pool.other_reserve as u128)
                .ok_or(FarmingError::MathOverflow)? as u64;

            // Check if the provided amounts are within slippage tolerance
            let tng_deviation = if tng_amount > expected_tng_amount {
                ((tng_amount - expected_tng_amount) as u128 * 10000) / expected_tng_amount as u128
            } else {
                ((expected_tng_amount - tng_amount) as u128 * 10000) / expected_tng_amount as u128
            };

            let other_deviation = if other_amount > expected_other_amount {
                ((other_amount - expected_other_amount) as u128 * 10000) / expected_other_amount as u128
            } else {
                ((expected_other_amount - other_amount) as u128 * 10000) / expected_other_amount as u128
            };

            require!(
                tng_deviation <= 500 && other_deviation <= 500, // 5% slippage tolerance
                FarmingError::RatioMismatch
            );
            
            // Calculate LP tokens based on both amounts and take the minimum
            let lp_from_tng = (tng_amount as u128)
                .checked_mul(pool.lp_supply as u128)
                .ok_or(FarmingError::MathOverflow)?
                .checked_div(pool.tng_reserve as u128)
                .ok_or(FarmingError::MathOverflow)? as u64;
                
            let lp_from_other = (other_amount as u128)
                .checked_mul(pool.lp_supply as u128)
                .ok_or(FarmingError::MathOverflow)?
                .checked_div(pool.other_reserve as u128)
                .ok_or(FarmingError::MathOverflow)? as u64;
                
            // Use the smaller amount to prevent manipulation
            let lp_tokens = lp_from_tng.min(lp_from_other);
            require!(lp_tokens >= minimum_lp_tokens, FarmingError::SlippageExceeded);
            
            msg!("Expected TNG: {}, Provided: {}", expected_tng_amount, tng_amount);
            msg!("Expected Other: {}, Provided: {}", expected_other_amount, other_amount);
            msg!("LP from TNG: {}, LP from Other: {}", lp_from_tng, lp_from_other);
            
            lp_tokens
        };

        // Transfer tokens from user to pool vaults
        let transfer_tng_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.user_tng_account.to_account_info(),
                to: ctx.accounts.tng_vault.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        token::transfer(transfer_tng_ctx, tng_amount)?;

        let transfer_other_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.user_other_account.to_account_info(),
                to: ctx.accounts.other_vault.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        token::transfer(transfer_other_ctx, other_amount)?;

        // Mint LP tokens to user
        let seeds = &[
            b"farming_pool",
            pool.tng_mint.as_ref(),
            pool.other_mint.as_ref(),
            &[pool.bump],
        ];
        let signer = &[&seeds[..]];

        let mint_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            MintTo {
                mint: ctx.accounts.lp_mint.to_account_info(),
                to: ctx.accounts.user_lp_account.to_account_info(),
                authority: pool.to_account_info(),
            },
            signer,
        );
        token::mint_to(mint_ctx, lp_tokens)?;

        // Update pool reserves
        pool.tng_reserve = pool.tng_reserve.checked_add(tng_amount)
            .ok_or(FarmingError::MathOverflow)?;
        pool.other_reserve = pool.other_reserve.checked_add(other_amount)
            .ok_or(FarmingError::MathOverflow)?;
        pool.lp_supply = pool.lp_supply.checked_add(lp_tokens)
            .ok_or(FarmingError::MathOverflow)?;

        msg!("Liquidity added successfully");
        msg!("LP Tokens minted: {}", lp_tokens);
        msg!("New TNG Reserve: {}", pool.tng_reserve);
        msg!("New Other Reserve: {}", pool.other_reserve);
        msg!("Total LP Supply: {}", pool.lp_supply);

        emit!(LiquidityAddedEvent {
            user: ctx.accounts.user.key(),
            tng_amount,
            other_amount,
            lp_tokens,
            timestamp: Clock::get()?.unix_timestamp,
        });

        Ok(())
    }

    /// Remove liquidity from the pool
    pub fn remove_liquidity(
        ctx: Context<RemoveLiquidity>,
        lp_tokens: u64,
        min_tng_amount: u64,
        min_other_amount: u64,
    ) -> Result<()> {
        let pool = &mut ctx.accounts.farming_pool;
        
        msg!("Removing liquidity from farming pool");
        msg!("LP Tokens: {}", lp_tokens);
        msg!("User: {}", ctx.accounts.user.key());

        require!(lp_tokens > 0, FarmingError::InvalidAmount);
        require!(pool.lp_supply >= lp_tokens, FarmingError::InsufficientLiquidity);

        // Calculate tokens to return
        let tng_amount = (lp_tokens as u128)
            .checked_mul(pool.tng_reserve as u128)
            .ok_or(FarmingError::MathOverflow)?
            .checked_div(pool.lp_supply as u128)
            .ok_or(FarmingError::MathOverflow)? as u64;
            
        let other_amount = (lp_tokens as u128)
            .checked_mul(pool.other_reserve as u128)
            .ok_or(FarmingError::MathOverflow)?
            .checked_div(pool.lp_supply as u128)
            .ok_or(FarmingError::MathOverflow)? as u64;

        require!(tng_amount >= min_tng_amount, FarmingError::SlippageExceeded);
        require!(other_amount >= min_other_amount, FarmingError::SlippageExceeded);

        // Burn LP tokens
        let burn_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Burn {
                mint: ctx.accounts.lp_mint.to_account_info(),
                from: ctx.accounts.user_lp_account.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        token::burn(burn_ctx, lp_tokens)?;

        // Transfer tokens back to user
        let seeds = &[
            b"farming_pool",
            pool.tng_mint.as_ref(),
            pool.other_mint.as_ref(),
            &[pool.bump],
        ];
        let signer = &[&seeds[..]];

        let transfer_tng_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.tng_vault.to_account_info(),
                to: ctx.accounts.user_tng_account.to_account_info(),
                authority: pool.to_account_info(),
            },
            signer,
        );
        token::transfer(transfer_tng_ctx, tng_amount)?;

        let transfer_other_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.other_vault.to_account_info(),
                to: ctx.accounts.user_other_account.to_account_info(),
                authority: pool.to_account_info(),
            },
            signer,
        );
        token::transfer(transfer_other_ctx, other_amount)?;

        // Update pool reserves
        pool.tng_reserve = pool.tng_reserve.checked_sub(tng_amount)
            .ok_or(FarmingError::InsufficientLiquidity)?;
        pool.other_reserve = pool.other_reserve.checked_sub(other_amount)
            .ok_or(FarmingError::InsufficientLiquidity)?;
        pool.lp_supply = pool.lp_supply.checked_sub(lp_tokens)
            .ok_or(FarmingError::InsufficientLiquidity)?;

        msg!("Liquidity removed successfully");
        msg!("TNG returned: {}", tng_amount);
        msg!("Other returned: {}", other_amount);

        emit!(LiquidityRemovedEvent {
            user: ctx.accounts.user.key(),
            tng_amount,
            other_amount,
            lp_tokens,
            timestamp: Clock::get()?.unix_timestamp,
        });

        Ok(())
    }

    /// Stake LP tokens for farming rewards
    pub fn stake_lp_tokens(
        ctx: Context<StakeLpTokens>,
        lp_amount: u64,
    ) -> Result<()> {
        let current_time = Clock::get()?.unix_timestamp;
        let user_key = ctx.accounts.user.key();
        let payer_key = ctx.accounts.payer.key();
        let farming_pool_key = ctx.accounts.farming_pool.key();

        msg!("Staking LP tokens for farming");
        msg!("LP Amount: {}", lp_amount);
        msg!("User: {}", user_key);
        msg!("Payer: {}", payer_key);

        require!(lp_amount > 0, FarmingError::InvalidAmount);

        let pool = &mut ctx.accounts.farming_pool;
        require!(pool.is_active, FarmingError::PoolInactive);

        // Update pool rewards first
        update_pool_rewards(pool, current_time)?;

        let user_farm = &mut ctx.accounts.user_farm;
        
        // Update user pending rewards before changing stake
        if user_farm.lp_staked > 0 {
            let pending_rewards = calculate_pending_rewards(user_farm, pool)?;
            user_farm.pending_rewards = user_farm.pending_rewards.checked_add(pending_rewards)
                .ok_or(FarmingError::MathOverflow)?;
        }

        // Transfer LP tokens from user to farming vault
        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.user_lp_account.to_account_info(),
                to: ctx.accounts.lp_vault.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        token::transfer(transfer_ctx, lp_amount)?;

        // Initialize or update user farm position
        if user_farm.user == Pubkey::default() {
            // Initialize new farm position
            let accumulated_reward_per_share = pool.accumulated_reward_per_share;
            
            user_farm.user = user_key;
            user_farm.farming_pool = farming_pool_key;
            user_farm.lp_staked = lp_amount;
            user_farm.pending_rewards = 0;
            user_farm.reward_debt = (lp_amount as u128)
                .checked_mul(accumulated_reward_per_share as u128)
                .ok_or(FarmingError::MathOverflow)?
                .checked_div(1e12 as u128)
                .ok_or(FarmingError::MathOverflow)? as u64;
            user_farm.last_stake_time = current_time;
        } else {
            // Update existing position
            user_farm.lp_staked = user_farm.lp_staked.checked_add(lp_amount)
                .ok_or(FarmingError::MathOverflow)?;
            user_farm.reward_debt = (user_farm.lp_staked as u128)
                .checked_mul(pool.accumulated_reward_per_share as u128)
                .ok_or(FarmingError::MathOverflow)?
                .checked_div(1e12 as u128)
                .ok_or(FarmingError::MathOverflow)? as u64;
        }

        // Update pool total staked
        pool.total_staked = pool.total_staked.checked_add(lp_amount)
            .ok_or(FarmingError::MathOverflow)?;

        msg!("LP tokens staked successfully");
        msg!("Total staked by user: {}", user_farm.lp_staked);
        msg!("Pool total staked: {}", pool.total_staked);

        emit!(LpStakedEvent {
            user: ctx.accounts.user.key(),
            amount: lp_amount,
            total_staked: user_farm.lp_staked,
            timestamp: current_time,
        });

        Ok(())
    }

    /// Unstake LP tokens
    pub fn unstake_lp_tokens(
        ctx: Context<UnstakeLpTokens>,
        lp_amount: u64,
    ) -> Result<()> {
        let pool = &mut ctx.accounts.farming_pool;
        let user_farm = &mut ctx.accounts.user_farm;
        let current_time = Clock::get()?.unix_timestamp;

        msg!("Unstaking LP tokens");
        msg!("LP Amount: {}", lp_amount);
        msg!("User: {}", ctx.accounts.user.key());

        require!(lp_amount > 0, FarmingError::InvalidAmount);
        require!(user_farm.lp_staked >= lp_amount, FarmingError::InsufficientStaked);

        // Update pool rewards
        update_pool_rewards(pool, current_time)?;

        // Calculate and update pending rewards
        let pending_rewards = calculate_pending_rewards(user_farm, pool)?;
        user_farm.pending_rewards = user_farm.pending_rewards.checked_add(pending_rewards)
            .ok_or(FarmingError::MathOverflow)?;

        // Transfer LP tokens back to user
        let seeds = &[
            b"farming_pool",
            pool.tng_mint.as_ref(),
            pool.other_mint.as_ref(),
            &[pool.bump],
        ];
        let signer = &[&seeds[..]];

        let transfer_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.lp_vault.to_account_info(),
                to: ctx.accounts.user_lp_account.to_account_info(),
                authority: pool.to_account_info(),
            },
            signer,
        );
        token::transfer(transfer_ctx, lp_amount)?;

        // Update user farm position
        user_farm.lp_staked = user_farm.lp_staked.checked_sub(lp_amount)
            .ok_or(FarmingError::InsufficientStaked)?;
        user_farm.reward_debt = (user_farm.lp_staked as u128)
            .checked_mul(pool.accumulated_reward_per_share as u128)
            .ok_or(FarmingError::MathOverflow)?
            .checked_div(1e12 as u128)
            .ok_or(FarmingError::MathOverflow)? as u64;

        // Update pool total staked
        pool.total_staked = pool.total_staked.checked_sub(lp_amount)
            .ok_or(FarmingError::InsufficientStaked)?;

        msg!("LP tokens unstaked successfully");
        msg!("Remaining staked: {}", user_farm.lp_staked);

        emit!(LpUnstakedEvent {
            user: ctx.accounts.user.key(),
            amount: lp_amount,
            remaining_staked: user_farm.lp_staked,
            timestamp: current_time,
        });

        Ok(())
    }

    /// Claim farming rewards
    pub fn claim_rewards(ctx: Context<ClaimRewards>) -> Result<()> {
        let pool = &mut ctx.accounts.farming_pool;
        let user_farm = &mut ctx.accounts.user_farm;
        let current_time = Clock::get()?.unix_timestamp;

        msg!("Claiming farming rewards");
        msg!("User: {}", ctx.accounts.user.key());

        // Update pool rewards
        update_pool_rewards(pool, current_time)?;

        // Calculate total rewards to claim
        let pending_rewards = calculate_pending_rewards(user_farm, pool)?;
        let total_rewards = user_farm.pending_rewards.checked_add(pending_rewards)
            .ok_or(FarmingError::MathOverflow)?;

        require!(total_rewards > 0, FarmingError::NoRewardsToClaim);

        // Transfer rewards to user
        let seeds = &[
            b"farming_pool",
            pool.tng_mint.as_ref(),
            pool.other_mint.as_ref(),
            &[pool.bump],
        ];
        let signer = &[&seeds[..]];

        let transfer_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.reward_vault.to_account_info(),
                to: ctx.accounts.user_reward_account.to_account_info(),
                authority: pool.to_account_info(),
            },
            signer,
        );
        token::transfer(transfer_ctx, total_rewards)?;

        // Update user farm position
        user_farm.pending_rewards = 0;
        user_farm.reward_debt = (user_farm.lp_staked as u128)
            .checked_mul(pool.accumulated_reward_per_share as u128)
            .ok_or(FarmingError::MathOverflow)?
            .checked_div(1e12 as u128)
            .ok_or(FarmingError::MathOverflow)? as u64;

        msg!("Rewards claimed successfully: {}", total_rewards);

        emit!(RewardsClaimedEvent {
            user: ctx.accounts.user.key(),
            amount: total_rewards,
            timestamp: current_time,
        });

        Ok(())
    }

    /// Update pool status (admin only)
    pub fn set_pool_status(ctx: Context<SetPoolStatus>, is_active: bool) -> Result<()> {
        let pool = &mut ctx.accounts.farming_pool;
        pool.is_active = is_active;

        msg!("Pool status set to: {}", if is_active { "active" } else { "paused" });
        Ok(())
    }

    /// Update reward rate (admin only)
    pub fn update_reward_rate(ctx: Context<UpdateRewardRate>, new_reward_rate: u64) -> Result<()> {
        let pool = &mut ctx.accounts.farming_pool;
        let current_time = Clock::get()?.unix_timestamp;

        // Update rewards with old rate first
        update_pool_rewards(pool, current_time)?;

        // Set new rate
        pool.reward_rate = new_reward_rate;

        msg!("Reward rate updated to: {} per second", new_reward_rate);
        Ok(())
    }
}

// Helper functions
fn update_pool_rewards(pool: &mut FarmingPool, current_time: i64) -> Result<()> {
    if pool.total_staked == 0 {
        pool.last_reward_time = current_time;
        return Ok(());
    }

    let time_elapsed = current_time - pool.last_reward_time;
    if time_elapsed <= 0 {
        return Ok(());
    }

    let reward_amount = (time_elapsed as u64)
        .checked_mul(pool.reward_rate)
        .ok_or(FarmingError::MathOverflow)?;

    let reward_per_share = (reward_amount as u128)
        .checked_mul(1e12 as u128)
        .ok_or(FarmingError::MathOverflow)?
        .checked_div(pool.total_staked as u128)
        .ok_or(FarmingError::MathOverflow)? as u64;

    pool.accumulated_reward_per_share = pool.accumulated_reward_per_share
        .checked_add(reward_per_share)
        .ok_or(FarmingError::MathOverflow)?;

    pool.last_reward_time = current_time;

    Ok(())
}

fn calculate_pending_rewards(user_farm: &UserFarm, pool: &FarmingPool) -> Result<u64> {
    let pending = (user_farm.lp_staked as u128)
        .checked_mul(pool.accumulated_reward_per_share as u128)
        .ok_or(FarmingError::MathOverflow)?
        .checked_div(1e12 as u128)
        .ok_or(FarmingError::MathOverflow)?
        .checked_sub(user_farm.reward_debt as u128)
        .ok_or(FarmingError::MathOverflow)? as u64;

    Ok(pending)
}

// ============================================================================
// Account Structures
// ============================================================================

#[account]
#[derive(InitSpace)]
pub struct FarmingPool {
    pub authority: Pubkey,              // Pool authority
    pub tng_mint: Pubkey,               // TNG token mint
    pub other_mint: Pubkey,             // Other token mint (SOL or USDC)
    pub tng_vault: Pubkey,              // TNG token vault
    pub other_vault: Pubkey,            // Other token vault
    pub lp_mint: Pubkey,                // LP token mint
    pub reward_vault: Pubkey,           // Reward vault (TNG rewards)
    pub tng_reserve: u64,               // TNG reserve amount
    pub other_reserve: u64,             // Other token reserve amount
    pub lp_supply: u64,                 // Total LP token supply
    pub total_staked: u64,              // Total LP tokens staked for farming
    pub reward_rate: u64,               // Rewards per second
    pub last_reward_time: i64,          // Last reward update time
    pub accumulated_reward_per_share: u64, // Accumulated rewards per share (scaled by 1e12)
    pub bump: u8,                       // PDA bump seed
    pub is_active: bool,                // Pool status
}

#[account]
#[derive(InitSpace)]
pub struct UserFarm {
    pub user: Pubkey,                   // User's public key
    pub farming_pool: Pubkey,           // Reference to farming pool
    pub lp_staked: u64,                 // LP tokens staked by user
    pub pending_rewards: u64,           // Pending rewards not yet claimed
    pub reward_debt: u64,               // Reward debt for calculation
    pub last_stake_time: i64,           // Last stake timestamp
}

// ============================================================================
// Account Contexts
// ============================================================================

#[derive(Accounts)]
pub struct InitializePool<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,

    #[account(mut)]
    pub payer: Signer<'info>, // payer = sponsor

    #[account(
        init,
        payer = payer, // payer = sponsor
        space = 8 + FarmingPool::INIT_SPACE,
        seeds = [b"farming_pool", tng_mint.key().as_ref(), other_mint.key().as_ref()],
        bump
    )]
    pub farming_pool: Account<'info, FarmingPool>,

    pub tng_mint: Account<'info, Mint>,
    pub other_mint: Account<'info, Mint>,

    #[account(
        init,
        payer = payer, // payer = sponsor
        associated_token::mint = tng_mint,
        associated_token::authority = farming_pool,
    )]
    pub tng_vault: Account<'info, TokenAccount>,

    #[account(
        init,
        payer = payer, // payer = sponsor
        associated_token::mint = other_mint,
        associated_token::authority = farming_pool,
    )]
    pub other_vault: Account<'info, TokenAccount>,

    #[account(
        init,
        payer = payer, // payer = sponsor
        token::mint = tng_mint, // TNG rewards
        token::authority = farming_pool,
    )]
    pub reward_vault: Account<'info, TokenAccount>,
    
    pub reward_vault_keypair: Signer<'info>, // Keypair for reward vault

    #[account(
        init,
        payer = payer, // payer = sponsor
        mint::decimals = 9,
        mint::authority = farming_pool,
    )]
    pub lp_mint: Account<'info, Mint>,
    
    pub lp_mint_keypair: Signer<'info>, // Keypair for LP mint
    
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct AddLiquidity<'info> {
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(mut)]
    pub payer: Signer<'info>,

    #[account(
        mut,
        seeds = [b"farming_pool", tng_mint.key().as_ref(), other_mint.key().as_ref()],
        bump = farming_pool.bump
    )]
    pub farming_pool: Account<'info, FarmingPool>,

    #[account(mut)]
    pub user_tng_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub user_other_account: Account<'info, TokenAccount>,

    #[account(
        init_if_needed,
        payer = payer,
        associated_token::mint = lp_mint,
        associated_token::authority = user,
    )]
    pub user_lp_account: Account<'info, TokenAccount>,

    #[account(mut, address = farming_pool.lp_mint)]
    pub lp_mint: Account<'info, Mint>,

    #[account(address = farming_pool.tng_mint)]
    pub tng_mint: Account<'info, Mint>,

    #[account(address = farming_pool.other_mint)]
    pub other_mint: Account<'info, Mint>,

    #[account(mut)]
    pub tng_vault: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub other_vault: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct RemoveLiquidity<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(
        mut,
        seeds = [b"farming_pool", farming_pool.tng_mint.as_ref(), farming_pool.other_mint.as_ref()],
        bump = farming_pool.bump
    )]
    pub farming_pool: Account<'info, FarmingPool>,
    
    #[account(
        mut,
        associated_token::mint = tng_mint,
        associated_token::authority = user,
    )]
    pub user_tng_account: Account<'info, TokenAccount>,

    #[account(
        mut,
        associated_token::mint = other_mint,
        associated_token::authority = user,
    )]
    pub user_other_account: Account<'info, TokenAccount>,
    
    #[account(
        mut,
        associated_token::mint = lp_mint,
        associated_token::authority = user,
    )]
    pub user_lp_account: Account<'info, TokenAccount>,

    #[account(address = farming_pool.tng_mint)]
    pub tng_mint: Account<'info, Mint>,

    #[account(address = farming_pool.other_mint)]
    pub other_mint: Account<'info, Mint>,

    #[account(address = farming_pool.lp_mint)]
    pub lp_mint: Account<'info, Mint>,

    #[account(
        mut,
        address = farming_pool.tng_vault
    )]
    pub tng_vault: Account<'info, TokenAccount>,
    
    #[account(
        mut,
        address = farming_pool.other_vault
    )]
    pub other_vault: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct StakeLpTokens<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(mut)]
    pub payer: Signer<'info>, // payer = sponsor
    
    #[account(
        mut,
        seeds = [b"farming_pool", farming_pool.tng_mint.as_ref(), farming_pool.other_mint.as_ref()],
        bump = farming_pool.bump,
        constraint = farming_pool.is_active @ FarmingError::PoolInactive
    )]
    pub farming_pool: Account<'info, FarmingPool>,

    #[account(
        init_if_needed,
        payer = payer, // payer = sponsor
        space = 8 + UserFarm::INIT_SPACE,
        seeds = [b"user_farm", user.key().as_ref(), farming_pool.key().as_ref()],
        bump
    )]
    pub user_farm: Account<'info, UserFarm>,
    
    #[account(
        mut,
        associated_token::mint = lp_mint,
        associated_token::authority = user,
    )]
    pub user_lp_account: Account<'info, TokenAccount>,

    #[account(
        init_if_needed,
        payer = payer, // payer = sponsor
        associated_token::mint = lp_mint,
        associated_token::authority = farming_pool,
    )]
    pub lp_vault: Account<'info, TokenAccount>,

    #[account(address = farming_pool.lp_mint)]
    pub lp_mint: Account<'info, Mint>,
    
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

#[derive(Accounts)]
pub struct UnstakeLpTokens<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(
        mut,
        seeds = [b"farming_pool", farming_pool.tng_mint.as_ref(), farming_pool.other_mint.as_ref()],
        bump = farming_pool.bump
    )]
    pub farming_pool: Account<'info, FarmingPool>,

    #[account(
        mut,
        seeds = [b"user_farm", user.key().as_ref(), farming_pool.key().as_ref()],
        bump,
        has_one = user,
        has_one = farming_pool
    )]
    pub user_farm: Account<'info, UserFarm>,

    #[account(
        mut,
        associated_token::mint = lp_mint,
        associated_token::authority = user,
    )]
    pub user_lp_account: Account<'info, TokenAccount>,

    #[account(
        mut,
        associated_token::mint = lp_mint,
        associated_token::authority = farming_pool,
    )]
    pub lp_vault: Account<'info, TokenAccount>,

    #[account(address = farming_pool.lp_mint)]
    pub lp_mint: Account<'info, Mint>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct ClaimRewards<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(
        mut,
        seeds = [b"farming_pool", farming_pool.tng_mint.as_ref(), farming_pool.other_mint.as_ref()],
        bump = farming_pool.bump
    )]
    pub farming_pool: Account<'info, FarmingPool>,

    #[account(
        mut,
        seeds = [b"user_farm", user.key().as_ref(), farming_pool.key().as_ref()],
        bump,
        has_one = user,
        has_one = farming_pool
    )]
    pub user_farm: Account<'info, UserFarm>,

    #[account(
        init_if_needed,
        payer = user,
        associated_token::mint = tng_mint, // TNG rewards
        associated_token::authority = user,
    )]
    pub user_reward_account: Account<'info, TokenAccount>,

    #[account(address = farming_pool.tng_mint)]
    pub tng_mint: Account<'info, Mint>,
    
    #[account(
        mut,
        address = farming_pool.reward_vault
    )]
    pub reward_vault: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct SetPoolStatus<'info> {
    #[account(
        mut,
        seeds = [b"farming_pool", farming_pool.tng_mint.as_ref(), farming_pool.other_mint.as_ref()],
        bump = farming_pool.bump,
        has_one = authority
    )]
    pub farming_pool: Account<'info, FarmingPool>,
    
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct UpdateRewardRate<'info> {
    #[account(
        mut,
        seeds = [b"farming_pool", farming_pool.tng_mint.as_ref(), farming_pool.other_mint.as_ref()],
        bump = farming_pool.bump,
        has_one = authority
    )]
    pub farming_pool: Account<'info, FarmingPool>,
    
    pub authority: Signer<'info>,
}

// ============================================================================
// Events
// ============================================================================

#[event]
pub struct LiquidityAddedEvent {
    pub user: Pubkey,
    pub tng_amount: u64,
    pub other_amount: u64,
    pub lp_tokens: u64,
    pub timestamp: i64,
}

#[event]
pub struct LiquidityRemovedEvent {
    pub user: Pubkey,
    pub tng_amount: u64,
    pub other_amount: u64,
    pub lp_tokens: u64,
    pub timestamp: i64,
}

#[event]
pub struct LpStakedEvent {
    pub user: Pubkey,
    pub amount: u64,
    pub total_staked: u64,
    pub timestamp: i64,
}

#[event]
pub struct LpUnstakedEvent {
    pub user: Pubkey,
    pub amount: u64,
    pub remaining_staked: u64,
    pub timestamp: i64,
}

#[event]
pub struct RewardsClaimedEvent {
    pub user: Pubkey,
    pub amount: u64,
    pub timestamp: i64,
}

// ============================================================================
// Error Codes
// ============================================================================

#[error_code]
pub enum FarmingError {
    #[msg("Invalid amount: must be greater than 0")]
    InvalidAmount,
    
    #[msg("Pool is currently inactive")]
    PoolInactive,
    
    #[msg("Insufficient liquidity in pool")]
    InsufficientLiquidity,
    
    #[msg("Slippage tolerance exceeded")]
    SlippageExceeded,
    
    #[msg("Mathematical overflow occurred")]
    MathOverflow,
    
    #[msg("Insufficient staked amount")]
    InsufficientStaked,
    
    #[msg("No rewards to claim")]
    NoRewardsToClaim,
    
    #[msg("Token ratio does not match pool reserves within slippage tolerance")]
    RatioMismatch,
    
    #[msg("Invalid slippage: must be between 0 and 2000 basis points (20%)")]
    InvalidSlippage,
}