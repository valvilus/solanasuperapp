import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { TngYieldOptimizer } from "../target/types/tng_yield_optimizer";

describe("tng-yield-optimizer", () => {
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  const program = anchor.workspace.TngYieldOptimizer as Program<TngYieldOptimizer>;

  it("Creates yield strategy!", async () => {
    const name = "Test Strategy";
    const targetProtocols = [anchor.web3.Keypair.generate().publicKey];
    const allocationWeights = [10000]; // 100%
    const rebalanceThreshold = 500; // 5%
    const autoCompound = true;
    
    const tx = await program.methods
      .createStrategy(name, targetProtocols, allocationWeights, rebalanceThreshold, autoCompound)
      .accounts({
        creator: provider.wallet.publicKey,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .rpc();

    console.log("Yield strategy created with signature:", tx);
  });
});
