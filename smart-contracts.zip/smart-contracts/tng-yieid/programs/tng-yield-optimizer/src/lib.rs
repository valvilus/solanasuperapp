use anchor_lang::prelude::*;
use anchor_spl::token::{Token, TokenAccount, Transfer, Mint};

declare_id!("7xgF5u61Hat3rLyn6VnTFq1KCQ9oWSgGXgEqaCN6LqLm");

const BASIS_POINTS: u64 = 10000;
const MAX_PROTOCOLS: usize = 10;
const MAX_STRATEGIES: u64 = 1000;
const MIN_REBALANCE_THRESHOLD: u64 = 100; // 1%

#[program]
pub mod tng_yield_optimizer {
    use super::*;
    
    pub fn create_strategy(
        ctx: Context<CreateStrategy>,
        name: String,
        target_protocols: Vec<Pubkey>,
        allocation_weights: Vec<u64>,
        rebalance_threshold: u64,
        auto_compound: bool,
    ) -> Result<()> {
        require!(target_protocols.len() <= MAX_PROTOCOLS, ErrorCode::TooManyProtocols);
        require!(target_protocols.len() == allocation_weights.len(), ErrorCode::MismatchedArrays);
        require!(rebalance_threshold >= MIN_REBALANCE_THRESHOLD, ErrorCode::RebalanceThresholdTooLow);
        require!(!name.is_empty() && name.len() <= 50, ErrorCode::InvalidStrategyName);

        let total_weight: u64 = allocation_weights.iter().sum();
        require!(total_weight == BASIS_POINTS, ErrorCode::InvalidTotalWeight);

        let strategy = &mut ctx.accounts.yield_strategy;
        strategy.strategy_id = Clock::get()?.unix_timestamp as u64;
        strategy.name = name;
        strategy.creator = ctx.accounts.creator.key();
        strategy.target_protocols = target_protocols;
        strategy.allocation_weights = allocation_weights;
        strategy.total_deposited = 0;
        strategy.total_shares = 0;
        strategy.last_rebalance = Clock::get()?.unix_timestamp;
        strategy.rebalance_threshold = rebalance_threshold;
        strategy.auto_compound = auto_compound;
        strategy.performance_fee = 200; // 2%
        strategy.management_fee = 100;  // 1% annually
        strategy.total_fees_collected = 0;
        strategy.is_active = true;
        strategy.created_at = Clock::get()?.unix_timestamp;
        strategy.bump = ctx.bumps.yield_strategy;

        Ok(())
    }
    
    pub fn deposit_to_strategy(
        ctx: Context<DepositToStrategy>,
        strategy_id: u64,
        amount: u64,
    ) -> Result<()> {
        let strategy = &mut ctx.accounts.yield_strategy;
        let user_position = &mut ctx.accounts.user_position;
        
        require!(strategy.is_active, ErrorCode::StrategyInactive);
        require!(strategy.strategy_id == strategy_id, ErrorCode::InvalidStrategyId);
        require!(amount > 0, ErrorCode::InvalidDepositAmount);

        let shares_to_mint = if strategy.total_shares == 0 {
            amount
        } else {
            (amount as u128)
                .checked_mul(strategy.total_shares as u128)
                .ok_or(ErrorCode::MathOverflow)?
                .checked_div(strategy.total_deposited as u128)
                .ok_or(ErrorCode::MathOverflow)? as u64
        };

        strategy.total_deposited = strategy.total_deposited
            .checked_add(amount)
            .ok_or(ErrorCode::MathOverflow)?;
        
        strategy.total_shares = strategy.total_shares
            .checked_add(shares_to_mint)
            .ok_or(ErrorCode::MathOverflow)?;

        if user_position.user == Pubkey::default() {
            user_position.user = ctx.accounts.user.key();
            user_position.strategy_id = strategy_id;
            user_position.shares = shares_to_mint;
            user_position.deposited_amount = amount;
            user_position.last_compound = Clock::get()?.unix_timestamp;
            user_position.entry_time = Clock::get()?.unix_timestamp;
            user_position.bump = ctx.bumps.user_position;
        } else {
            user_position.shares = user_position.shares
                .checked_add(shares_to_mint)
                .ok_or(ErrorCode::MathOverflow)?;
            
            user_position.deposited_amount = user_position.deposited_amount
                .checked_add(amount)
                .ok_or(ErrorCode::MathOverflow)?;
        }

        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.user_token_account.to_account_info(),
                to: ctx.accounts.strategy_vault.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_ctx, amount)?;

        Ok(())
    }
    
    pub fn withdraw_from_strategy(
        ctx: Context<WithdrawFromStrategy>,
        strategy_id: u64,
        shares_to_burn: u64,
    ) -> Result<()> {
        let strategy = &mut ctx.accounts.yield_strategy;
        let user_position = &mut ctx.accounts.user_position;
        
        require!(strategy.strategy_id == strategy_id, ErrorCode::InvalidStrategyId);
        require!(shares_to_burn > 0, ErrorCode::InvalidWithdrawAmount);
        require!(shares_to_burn <= user_position.shares, ErrorCode::InsufficientShares);

        let withdrawal_amount = (shares_to_burn as u128)
            .checked_mul(strategy.total_deposited as u128)
            .ok_or(ErrorCode::MathOverflow)?
            .checked_div(strategy.total_shares as u128)
            .ok_or(ErrorCode::MathOverflow)? as u64;

        let current_time = Clock::get()?.unix_timestamp;
        let time_held = current_time - user_position.entry_time;
        
        let early_withdrawal_fee = if time_held < 86400 * 7 { // 7 days
            (withdrawal_amount as u128)
                .checked_mul(50u128) // 0.5%
                .ok_or(ErrorCode::MathOverflow)?
                .checked_div(BASIS_POINTS as u128)
                .ok_or(ErrorCode::MathOverflow)? as u64
        } else {
            0
        };

        let net_withdrawal = withdrawal_amount
            .checked_sub(early_withdrawal_fee)
            .ok_or(ErrorCode::MathOverflow)?;

        strategy.total_deposited = strategy.total_deposited
            .checked_sub(withdrawal_amount)
            .ok_or(ErrorCode::MathOverflow)?;
        
        strategy.total_shares = strategy.total_shares
            .checked_sub(shares_to_burn)
            .ok_or(ErrorCode::MathOverflow)?;

        strategy.total_fees_collected = strategy.total_fees_collected
            .checked_add(early_withdrawal_fee)
            .ok_or(ErrorCode::MathOverflow)?;

        user_position.shares = user_position.shares
            .checked_sub(shares_to_burn)
            .ok_or(ErrorCode::MathOverflow)?;

        let proportional_deposit_reduction = (user_position.deposited_amount as u128)
            .checked_mul(shares_to_burn as u128)
            .ok_or(ErrorCode::MathOverflow)?
            .checked_div((user_position.shares + shares_to_burn) as u128)
            .ok_or(ErrorCode::MathOverflow)? as u64;

        user_position.deposited_amount = user_position.deposited_amount
            .checked_sub(proportional_deposit_reduction)
            .ok_or(ErrorCode::MathOverflow)?;

        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.strategy_vault.to_account_info(),
                to: ctx.accounts.user_token_account.to_account_info(),
                authority: ctx.accounts.vault_authority.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_ctx, net_withdrawal)?;

        Ok(())
    }
    
    pub fn rebalance_strategy(
        ctx: Context<RebalanceStrategy>,
        strategy_id: u64,
        new_allocation_weights: Vec<u64>,
    ) -> Result<()> {
        let strategy = &mut ctx.accounts.yield_strategy;
        
        require!(strategy.strategy_id == strategy_id, ErrorCode::InvalidStrategyId);
        require!(strategy.is_active, ErrorCode::StrategyInactive);
        require!(new_allocation_weights.len() == strategy.target_protocols.len(), ErrorCode::MismatchedArrays);

        let total_weight: u64 = new_allocation_weights.iter().sum();
        require!(total_weight == BASIS_POINTS, ErrorCode::InvalidTotalWeight);

        let current_time = Clock::get()?.unix_timestamp;
        let time_since_last_rebalance = current_time - strategy.last_rebalance;
        require!(time_since_last_rebalance >= 3600, ErrorCode::RebalanceTooFrequent); // 1 hour minimum

        let mut deviation_detected = false;
        for (i, &new_weight) in new_allocation_weights.iter().enumerate() {
            if let Some(current_weight) = strategy.allocation_weights.get(i) {
                let deviation = if new_weight > *current_weight {
                    new_weight - current_weight
                } else {
                    current_weight - new_weight
                };
                
                if deviation >= strategy.rebalance_threshold {
                    deviation_detected = true;
                    break;
                }
            }
        }
        
        require!(deviation_detected, ErrorCode::RebalanceNotNeeded);

        strategy.allocation_weights = new_allocation_weights;
        strategy.last_rebalance = current_time;

        Ok(())
    }
    
    pub fn compound_rewards(
        ctx: Context<CompoundRewards>,
        strategy_id: u64,
    ) -> Result<()> {
        let strategy = &mut ctx.accounts.yield_strategy;
        
        require!(strategy.strategy_id == strategy_id, ErrorCode::InvalidStrategyId);
        require!(strategy.auto_compound, ErrorCode::AutoCompoundDisabled);
        require!(strategy.is_active, ErrorCode::StrategyInactive);

        let current_time = Clock::get()?.unix_timestamp;
        let time_since_last_compound = current_time - strategy.last_rebalance;
        require!(time_since_last_compound >= 86400, ErrorCode::CompoundTooFrequent); // 24 hours minimum

        let mock_rewards = strategy.total_deposited
            .checked_mul(5) // 0.05% daily yield
            .ok_or(ErrorCode::MathOverflow)?
            .checked_div(BASIS_POINTS)
            .ok_or(ErrorCode::MathOverflow)?;

        let performance_fee = mock_rewards
            .checked_mul(strategy.performance_fee)
            .ok_or(ErrorCode::MathOverflow)?
            .checked_div(BASIS_POINTS)
            .ok_or(ErrorCode::MathOverflow)?;

        let net_rewards = mock_rewards
            .checked_sub(performance_fee)
            .ok_or(ErrorCode::MathOverflow)?;

        strategy.total_deposited = strategy.total_deposited
            .checked_add(net_rewards)
            .ok_or(ErrorCode::MathOverflow)?;

        strategy.total_fees_collected = strategy.total_fees_collected
            .checked_add(performance_fee)
            .ok_or(ErrorCode::MathOverflow)?;

        strategy.last_rebalance = current_time;

        Ok(())
    }

    pub fn update_strategy_status(
        ctx: Context<UpdateStrategyStatus>,
        strategy_id: u64,
        is_active: bool,
    ) -> Result<()> {
        let strategy = &mut ctx.accounts.yield_strategy;
        
        require!(strategy.strategy_id == strategy_id, ErrorCode::InvalidStrategyId);
        require!(
            ctx.accounts.authority.key() == strategy.creator,
            ErrorCode::Unauthorized
        );

        strategy.is_active = is_active;

        Ok(())
    }

    pub fn collect_fees(
        ctx: Context<CollectFees>,
        strategy_id: u64,
        amount: u64,
    ) -> Result<()> {
        let strategy = &mut ctx.accounts.yield_strategy;
        
        require!(strategy.strategy_id == strategy_id, ErrorCode::InvalidStrategyId);
        require!(
            ctx.accounts.authority.key() == strategy.creator,
            ErrorCode::Unauthorized
        );
        require!(amount <= strategy.total_fees_collected, ErrorCode::InsufficientFees);

        strategy.total_fees_collected = strategy.total_fees_collected
            .checked_sub(amount)
            .ok_or(ErrorCode::MathOverflow)?;

        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.strategy_vault.to_account_info(),
                to: ctx.accounts.authority_token_account.to_account_info(),
                authority: ctx.accounts.vault_authority.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_ctx, amount)?;

        Ok(())
    }
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub enum ProtocolType {
    Raydium,
    Orca,
    Solend,
    MangoMarkets,
    Tulip,
    Custom,
}

#[account]
pub struct YieldStrategy {
    pub strategy_id: u64,
    pub name: String,
    pub creator: Pubkey,
    pub target_protocols: Vec<Pubkey>,
    pub allocation_weights: Vec<u64>,
    pub total_deposited: u64,
    pub total_shares: u64,
    pub last_rebalance: i64,
    pub rebalance_threshold: u64,
    pub auto_compound: bool,
    pub performance_fee: u64,
    pub management_fee: u64,
    pub total_fees_collected: u64,
    pub is_active: bool,
    pub created_at: i64,
    pub bump: u8,
}

#[account]
pub struct UserStrategyPosition {
    pub user: Pubkey,
    pub strategy_id: u64,
    pub shares: u64,
    pub deposited_amount: u64,
    pub last_compound: i64,
    pub entry_time: i64,
    pub bump: u8,
}

#[derive(Accounts)]
pub struct CreateStrategy<'info> {
    #[account(
        init,
        payer = creator,
        space = 8 + 8 + 64 + 32 + 4 + 10*32 + 4 + 10*8 + 8 + 8 + 8 + 8 + 1 + 8 + 8 + 8 + 1 + 8 + 1,
        seeds = [b"yield_strategy", creator.key().as_ref()],
        bump
    )]
    pub yield_strategy: Account<'info, YieldStrategy>,
    
    #[account(mut)]
    pub creator: Signer<'info>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(strategy_id: u64)]
pub struct DepositToStrategy<'info> {
    #[account(
        mut,
        seeds = [b"yield_strategy", yield_strategy.creator.as_ref()],
        bump = yield_strategy.bump
    )]
    pub yield_strategy: Account<'info, YieldStrategy>,
    
    #[account(
        init_if_needed,
        payer = user,
        space = 8 + 32 + 8 + 8 + 8 + 8 + 8 + 1,
        seeds = [b"user_position", user.key().as_ref(), &strategy_id.to_le_bytes()],
        bump
    )]
    pub user_position: Account<'info, UserStrategyPosition>,
    
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub strategy_vault: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(strategy_id: u64)]
pub struct WithdrawFromStrategy<'info> {
    #[account(
        mut,
        seeds = [b"yield_strategy", yield_strategy.creator.as_ref()],
        bump = yield_strategy.bump
    )]
    pub yield_strategy: Account<'info, YieldStrategy>,
    
    #[account(
        mut,
        seeds = [b"user_position", user.key().as_ref(), &strategy_id.to_le_bytes()],
        bump = user_position.bump
    )]
    pub user_position: Account<'info, UserStrategyPosition>,
    
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub strategy_vault: Account<'info, TokenAccount>,
    
    /// CHECK: Vault authority PDA
    pub vault_authority: AccountInfo<'info>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
#[instruction(strategy_id: u64)]
pub struct RebalanceStrategy<'info> {
    #[account(
        mut,
        seeds = [b"yield_strategy", yield_strategy.creator.as_ref()],
        bump = yield_strategy.bump
    )]
    pub yield_strategy: Account<'info, YieldStrategy>,
    
    pub rebalancer: Signer<'info>,
}

#[derive(Accounts)]
#[instruction(strategy_id: u64)]
pub struct CompoundRewards<'info> {
    #[account(
        mut,
        seeds = [b"yield_strategy", yield_strategy.creator.as_ref()],
        bump = yield_strategy.bump
    )]
    pub yield_strategy: Account<'info, YieldStrategy>,
    
    pub compounder: Signer<'info>,
}

#[derive(Accounts)]
#[instruction(strategy_id: u64)]
pub struct UpdateStrategyStatus<'info> {
    #[account(
        mut,
        seeds = [b"yield_strategy", yield_strategy.creator.as_ref()],
        bump = yield_strategy.bump
    )]
    pub yield_strategy: Account<'info, YieldStrategy>,
    
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
#[instruction(strategy_id: u64)]
pub struct CollectFees<'info> {
    #[account(
        mut,
        seeds = [b"yield_strategy", yield_strategy.creator.as_ref()],
        bump = yield_strategy.bump
    )]
    pub yield_strategy: Account<'info, YieldStrategy>,
    
    pub authority: Signer<'info>,
    
    #[account(mut)]
    pub strategy_vault: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub authority_token_account: Account<'info, TokenAccount>,
    
    /// CHECK: Vault authority PDA
    pub vault_authority: AccountInfo<'info>,
    
    pub token_program: Program<'info, Token>,
}

#[error_code]
pub enum ErrorCode {
    #[msg("Too many protocols")]
    TooManyProtocols,
    #[msg("Mismatched arrays")]
    MismatchedArrays,
    #[msg("Rebalance threshold too low")]
    RebalanceThresholdTooLow,
    #[msg("Invalid strategy name")]
    InvalidStrategyName,
    #[msg("Invalid total weight")]
    InvalidTotalWeight,
    #[msg("Strategy inactive")]
    StrategyInactive,
    #[msg("Invalid strategy ID")]
    InvalidStrategyId,
    #[msg("Invalid deposit amount")]
    InvalidDepositAmount,
    #[msg("Math overflow")]
    MathOverflow,
    #[msg("Invalid withdraw amount")]
    InvalidWithdrawAmount,
    #[msg("Insufficient shares")]
    InsufficientShares,
    #[msg("Rebalance too frequent")]
    RebalanceTooFrequent,
    #[msg("Rebalance not needed")]
    RebalanceNotNeeded,
    #[msg("Auto compound disabled")]
    AutoCompoundDisabled,
    #[msg("Compound too frequent")]
    CompoundTooFrequent,
    #[msg("Unauthorized")]
    Unauthorized,
    #[msg("Insufficient fees")]
    InsufficientFees,
}
