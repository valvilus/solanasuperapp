use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};

declare_id!("4xgC3u61Hat3rLyn6VnTFq1KCQ9oWSgGXgEqaCN6LqLm");

#[program]
pub mod tng_orderbook {
    use super::*;
    
    pub fn initialize_market(
        ctx: Context<InitializeMarket>,
        base_mint: Pubkey,
        quote_mint: Pubkey,
        tick_size: u64,
        min_order_size: u64,
    ) -> Result<()> {
        let market = &mut ctx.accounts.market;
        market.authority = ctx.accounts.authority.key();
        market.base_mint = base_mint;
        market.quote_mint = quote_mint;
        market.tick_size = tick_size;
        market.min_order_size = min_order_size;
        market.next_order_id = 1;
        market.total_orders = 0;
        market.is_active = true;
        market.created_at = Clock::get()?.unix_timestamp;
        Ok(())
    }
    
    pub fn place_order(
        ctx: Context<PlaceOrder>,
        side: OrderSide,
        price: u64,
        quantity: u64,
        order_type: OrderType,
    ) -> Result<()> {
        let market = &mut ctx.accounts.market;
        let order = &mut ctx.accounts.order;
        
        require!(quantity >= market.min_order_size, ErrorCode::OrderTooSmall);
        require!(price % market.tick_size == 0, ErrorCode::InvalidPrice);
        require!(market.is_active, ErrorCode::MarketInactive);
        
        order.order_id = market.next_order_id;
        order.user = ctx.accounts.user.key();
        order.market = ctx.accounts.market.key();
        order.side = side;
        order.price = price;
        order.quantity = quantity;
        order.filled_quantity = 0;
        order.order_type = order_type;
        order.status = OrderStatus::Open;
        order.created_at = Clock::get()?.unix_timestamp;
        
        let total_amount = match side {
            OrderSide::Buy => price.checked_mul(quantity).ok_or(ErrorCode::MathOverflow)?,
            OrderSide::Sell => quantity,
        };
        
        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.user_token_account.to_account_info(),
                to: ctx.accounts.escrow_token_account.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        token::transfer(transfer_ctx, total_amount)?;
        
        market.next_order_id += 1;
        market.total_orders += 1;
        
        Ok(())
    }
    
    pub fn cancel_order(
        ctx: Context<CancelOrder>,
        order_id: u64,
    ) -> Result<()> {
        let order = &mut ctx.accounts.order;
        
        require!(order.order_id == order_id, ErrorCode::InvalidOrderId);
        require!(order.user == ctx.accounts.user.key(), ErrorCode::Unauthorized);
        require!(order.status == OrderStatus::Open, ErrorCode::OrderNotOpen);
        
        order.status = OrderStatus::Cancelled;
        order.cancelled_at = Some(Clock::get()?.unix_timestamp);
        
        let remaining_quantity = order.quantity - order.filled_quantity;
        if remaining_quantity > 0 {
            let refund_amount = match order.side {
                OrderSide::Buy => order.price.checked_mul(remaining_quantity).ok_or(ErrorCode::MathOverflow)?,
                OrderSide::Sell => remaining_quantity,
            };
            
            let transfer_ctx = CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                Transfer {
                    from: ctx.accounts.escrow_token_account.to_account_info(),
                    to: ctx.accounts.user_token_account.to_account_info(),
                    authority: ctx.accounts.market.to_account_info(),
                },
            );
            token::transfer(transfer_ctx, refund_amount)?;
        }
        
        Ok(())
    }
    
    pub fn match_orders(
        ctx: Context<MatchOrders>,
        buy_order_id: u64,
        sell_order_id: u64,
        match_quantity: u64,
    ) -> Result<()> {
        let buy_order = &mut ctx.accounts.buy_order;
        let sell_order = &mut ctx.accounts.sell_order;
        
        require!(buy_order.order_id == buy_order_id, ErrorCode::InvalidOrderId);
        require!(sell_order.order_id == sell_order_id, ErrorCode::InvalidOrderId);
        require!(buy_order.side == OrderSide::Buy, ErrorCode::InvalidOrderSide);
        require!(sell_order.side == OrderSide::Sell, ErrorCode::InvalidOrderSide);
        require!(buy_order.price >= sell_order.price, ErrorCode::PriceMismatch);
        require!(buy_order.status == OrderStatus::Open, ErrorCode::OrderNotOpen);
        require!(sell_order.status == OrderStatus::Open, ErrorCode::OrderNotOpen);
        
        let buy_remaining = buy_order.quantity - buy_order.filled_quantity;
        let sell_remaining = sell_order.quantity - sell_order.filled_quantity;
        let max_match = buy_remaining.min(sell_remaining);
        
        require!(match_quantity <= max_match, ErrorCode::InvalidMatchQuantity);
        
        buy_order.filled_quantity += match_quantity;
        sell_order.filled_quantity += match_quantity;
        
        if buy_order.filled_quantity == buy_order.quantity {
            buy_order.status = OrderStatus::Filled;
        }
        if sell_order.filled_quantity == sell_order.quantity {
            sell_order.status = OrderStatus::Filled;
        }
        
        let trade_value = sell_order.price.checked_mul(match_quantity).ok_or(ErrorCode::MathOverflow)?;
        
        let sell_to_buy_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.sell_escrow.to_account_info(),
                to: ctx.accounts.buy_user_base.to_account_info(),
                authority: ctx.accounts.market.to_account_info(),
            },
        );
        token::transfer(sell_to_buy_ctx, match_quantity)?;
        
        let buy_to_sell_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.buy_escrow.to_account_info(),
                to: ctx.accounts.sell_user_quote.to_account_info(),
                authority: ctx.accounts.market.to_account_info(),
            },
        );
        token::transfer(buy_to_sell_ctx, trade_value)?;
        
        Ok(())
    }
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq)]
pub enum OrderSide {
    Buy,
    Sell,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq)]
pub enum OrderType {
    Limit,
    Market,
    StopLoss,
    TakeProfit,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq)]
pub enum OrderStatus {
    Open,
    PartiallyFilled,
    Filled,
    Cancelled,
}

#[account]
pub struct Market {
    pub authority: Pubkey,
    pub base_mint: Pubkey,
    pub quote_mint: Pubkey,
    pub tick_size: u64,
    pub min_order_size: u64,
    pub next_order_id: u64,
    pub total_orders: u64,
    pub is_active: bool,
    pub created_at: i64,
}

#[account]
pub struct Order {
    pub order_id: u64,
    pub user: Pubkey,
    pub market: Pubkey,
    pub side: OrderSide,
    pub price: u64,
    pub quantity: u64,
    pub filled_quantity: u64,
    pub order_type: OrderType,
    pub status: OrderStatus,
    pub created_at: i64,
    pub cancelled_at: Option<i64>,
}

#[derive(Accounts)]
pub struct InitializeMarket<'info> {
    #[account(init, payer = authority, space = 8 + 32 + 32 + 32 + 8 + 8 + 8 + 8 + 1 + 8)]
    pub market: Account<'info, Market>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct PlaceOrder<'info> {
    #[account(init, payer = user, space = 8 + 8 + 32 + 32 + 1 + 8 + 8 + 8 + 1 + 1 + 8 + 9)]
    pub order: Account<'info, Order>,
    #[account(mut)]
    pub market: Account<'info, Market>,
    #[account(mut)]
    pub user: Signer<'info>,
    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,
    #[account(mut)]
    pub escrow_token_account: Account<'info, TokenAccount>,
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct CancelOrder<'info> {
    #[account(mut)]
    pub order: Account<'info, Order>,
    #[account(mut)]
    pub user: Signer<'info>,
    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,
    #[account(mut)]
    pub escrow_token_account: Account<'info, TokenAccount>,
    pub market: Account<'info, Market>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct MatchOrders<'info> {
    #[account(mut)]
    pub buy_order: Account<'info, Order>,
    #[account(mut)]
    pub sell_order: Account<'info, Order>,
    pub market: Account<'info, Market>,
    #[account(mut)]
    pub buy_escrow: Account<'info, TokenAccount>,
    #[account(mut)]
    pub sell_escrow: Account<'info, TokenAccount>,
    #[account(mut)]
    pub buy_user_base: Account<'info, TokenAccount>,
    #[account(mut)]
    pub buy_user_quote: Account<'info, TokenAccount>,
    #[account(mut)]
    pub sell_user_base: Account<'info, TokenAccount>,
    #[account(mut)]
    pub sell_user_quote: Account<'info, TokenAccount>,
    pub token_program: Program<'info, Token>,
}

#[error_code]
pub enum ErrorCode {
    #[msg("Order size is too small")]
    OrderTooSmall,
    #[msg("Invalid price - must be multiple of tick size")]
    InvalidPrice,
    #[msg("Market is not active")]
    MarketInactive,
    #[msg("Math overflow")]
    MathOverflow,
    #[msg("Invalid order ID")]
    InvalidOrderId,
    #[msg("Unauthorized")]
    Unauthorized,
    #[msg("Order is not open")]
    OrderNotOpen,
    #[msg("Invalid order side")]
    InvalidOrderSide,
    #[msg("Price mismatch")]
    PriceMismatch,
    #[msg("Invalid match quantity")]
    InvalidMatchQuantity,
}