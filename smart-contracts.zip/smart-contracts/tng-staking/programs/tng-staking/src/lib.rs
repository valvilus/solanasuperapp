use anchor_lang::prelude::*;
use anchor_spl::token::{self, Mint, Token, TokenAccount, Transfer, MintTo, Burn};
use anchor_spl::associated_token::AssociatedToken;

use std::mem::size_of;

declare_id!("ArBvk3DQtxKES6EbdhequHQKKKYjhMFp7S8ob8Q5inHg");

// TNG Token Mint Address (from your keys/tng-mint-info.json)
pub const TNG_MINT: &str = "FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs";

#[program]
pub mod tng_staking {
    use super::*;

    /// Initialize the staking program
    pub fn initialize(ctx: Context<Initialize>, bump: u8) -> Result<()> {
        let staking_pool = &mut ctx.accounts.staking_pool;
        staking_pool.authority = ctx.accounts.authority.key();
        staking_pool.tng_mint = ctx.accounts.tng_mint.key();
        staking_pool.stng_mint = ctx.accounts.stng_mint.key();
        staking_pool.vault = ctx.accounts.vault.key();
        staking_pool.total_staked = 0;
        staking_pool.total_stng_supply = 0;
        staking_pool.apy_basis_points = 850; // 8.5% APY
        staking_pool.bump = bump;
        staking_pool.is_active = true;
        staking_pool.created_at = Clock::get()?.unix_timestamp;

        msg!("TNG Staking Pool initialized with APY: {}%", 8.5);
        Ok(())
    }

    /// Stake TNG tokens and receive sTNG (staked TNG) tokens
    pub fn stake(ctx: Context<Stake>, amount: u64) -> Result<()> {
        require!(amount > 0, StakingError::InvalidAmount);
        require!(amount >= 100_000_000_000, StakingError::BelowMinimumStake); // 100 TNG minimum

        require!(ctx.accounts.staking_pool.is_active, StakingError::PoolInactive);

        // Log payer info for debugging
        msg!("Stake operation - Payer: {}, User: {}, Amount: {}", 
             ctx.accounts.payer.key(), 
             ctx.accounts.user.key(), 
             amount);
        
        // Check payer has enough SOL (for debugging)
        let payer_lamports = ctx.accounts.payer.lamports();
        msg!("Payer SOL balance: {} lamports", payer_lamports);

        // Calculate sTNG amount to mint (1:1 ratio for simplicity)
        let stng_amount = amount;

        // Transfer TNG from user to vault
        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.user_tng_account.to_account_info(),
                to: ctx.accounts.vault.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        token::transfer(transfer_ctx, amount)?;

        // Mint sTNG tokens to user
        let tng_mint = ctx.accounts.staking_pool.tng_mint;
        let bump = ctx.accounts.staking_pool.bump;
        
        let seeds = &[
            b"staking_pool",
            tng_mint.as_ref(),
            &[bump],
        ];
        let signer = &[&seeds[..]];

        let mint_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            MintTo {
                mint: ctx.accounts.stng_mint.to_account_info(),
                to: ctx.accounts.user_stng_account.to_account_info(),
                authority: ctx.accounts.staking_pool.to_account_info(),
            },
            signer,
        );
        token::mint_to(mint_ctx, stng_amount)?;

        // Update or create user stake position
        let user_stake = &mut ctx.accounts.user_stake;
        let current_time = Clock::get()?.unix_timestamp;
        
        // If this is a new stake position, initialize it
        if user_stake.user == Pubkey::default() {
            user_stake.user = ctx.accounts.user.key();
            user_stake.staking_pool = ctx.accounts.staking_pool.key();
            user_stake.staked_amount = amount;
            user_stake.stng_amount = stng_amount;
            user_stake.total_rewards_claimed = 0;
            user_stake.stake_timestamp = current_time;
            user_stake.last_claim_timestamp = current_time;
        } else {
            // Update existing stake position
            user_stake.staked_amount = user_stake.staked_amount.checked_add(amount).unwrap();
            user_stake.stng_amount = user_stake.stng_amount.checked_add(stng_amount).unwrap();
            // Keep original stake timestamp, update last claim timestamp
            user_stake.last_claim_timestamp = current_time;
        }

        // Update pool totals
        let staking_pool = &mut ctx.accounts.staking_pool;
        staking_pool.total_staked = staking_pool.total_staked.checked_add(amount).unwrap();
        staking_pool.total_stng_supply = staking_pool.total_stng_supply.checked_add(stng_amount).unwrap();

        emit!(StakeEvent {
            user: ctx.accounts.user.key(),
            amount,
            stng_amount,
            timestamp: Clock::get()?.unix_timestamp,
        });

        msg!("Staked {} TNG, received {} sTNG", amount as f64 / 1_000_000_000.0, stng_amount as f64 / 1_000_000_000.0);
        Ok(())
    }

    /// Unstake sTNG tokens and receive TNG tokens + rewards
    pub fn unstake(ctx: Context<Unstake>, stng_amount: u64) -> Result<()> {
        require!(stng_amount > 0, StakingError::InvalidAmount);

        // Log unstake info for debugging
        msg!("Unstake operation - Payer: {}, User: {}, sTNG Amount: {}", 
             ctx.accounts.payer.key(), 
             ctx.accounts.user.key(), 
             stng_amount);
        
        // Check payer has enough SOL (for debugging)
        let payer_lamports = ctx.accounts.payer.lamports();
        msg!("Payer SOL balance: {} lamports", payer_lamports);

        let user_stake = &mut ctx.accounts.user_stake;
        require!(user_stake.stng_amount >= stng_amount, StakingError::InsufficientStakedAmount);

        // Calculate rewards based on time staked and APY
        let current_time = Clock::get()?.unix_timestamp;
        let time_staked = current_time - user_stake.last_claim_timestamp;
        let seconds_per_year = 365 * 24 * 60 * 60;
        
        // Calculate proportional TNG amount to return
        let tng_amount = stng_amount; // 1:1 ratio for simplicity
        
        // Calculate rewards (APY-based)
        let apy_basis_points = ctx.accounts.staking_pool.apy_basis_points;
        let bump = ctx.accounts.staking_pool.bump;
        let tng_mint = ctx.accounts.staking_pool.tng_mint;
        
        let rewards = (tng_amount as u128)
            .checked_mul(apy_basis_points as u128)
            .unwrap()
            .checked_mul(time_staked as u128)
            .unwrap()
            .checked_div(10000 as u128) // basis points
            .unwrap()
            .checked_div(seconds_per_year as u128)
            .unwrap() as u64;

        let total_return = tng_amount.checked_add(rewards).unwrap();

        // Burn sTNG tokens
        let burn_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Burn {
                mint: ctx.accounts.stng_mint.to_account_info(),
                from: ctx.accounts.user_stng_account.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        token::burn(burn_ctx, stng_amount)?;

        // Transfer TNG + rewards from vault to user
        let seeds = &[
            b"staking_pool",
            tng_mint.as_ref(),
            &[bump],
        ];
        let signer = &[&seeds[..]];

        let transfer_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.vault.to_account_info(),
                to: ctx.accounts.user_tng_account.to_account_info(),
                authority: ctx.accounts.staking_pool.to_account_info(),
            },
            signer,
        );
        token::transfer(transfer_ctx, total_return)?;

        // Update user stake position
        user_stake.staked_amount = user_stake.staked_amount.checked_sub(tng_amount).unwrap();
        user_stake.stng_amount = user_stake.stng_amount.checked_sub(stng_amount).unwrap();
        user_stake.total_rewards_claimed = user_stake.total_rewards_claimed.checked_add(rewards).unwrap();
        user_stake.last_claim_timestamp = current_time;

        // Update pool totals
        let staking_pool = &mut ctx.accounts.staking_pool;
        staking_pool.total_staked = staking_pool.total_staked.checked_sub(tng_amount).unwrap();
        staking_pool.total_stng_supply = staking_pool.total_stng_supply.checked_sub(stng_amount).unwrap();

        emit!(UnstakeEvent {
            user: ctx.accounts.user.key(),
            stng_amount,
            tng_amount,
            rewards,
            timestamp: current_time,
        });

        msg!("Unstaked {} sTNG, received {} TNG + {} rewards", 
             stng_amount as f64 / 1_000_000_000.0, 
             tng_amount as f64 / 1_000_000_000.0, 
             rewards as f64 / 1_000_000_000.0);
        Ok(())
    }

    /// Claim accumulated rewards without unstaking
    pub fn claim_rewards(ctx: Context<ClaimRewards>) -> Result<()> {
        let user_stake = &mut ctx.accounts.user_stake;
        let staking_pool = &ctx.accounts.staking_pool;
        
        // Calculate rewards since last claim
        let current_time = Clock::get()?.unix_timestamp;
        let time_since_last_claim = current_time - user_stake.last_claim_timestamp;
        let seconds_per_year = 365 * 24 * 60 * 60;
        
        let rewards = (user_stake.staked_amount as u128)
            .checked_mul(staking_pool.apy_basis_points as u128)
            .unwrap()
            .checked_mul(time_since_last_claim as u128)
            .unwrap()
            .checked_div(10000 as u128)
            .unwrap()
            .checked_div(seconds_per_year as u128)
            .unwrap() as u64;

        require!(rewards > 0, StakingError::NoRewardsToClaim);

        // Transfer rewards from vault to user
        let seeds = &[
            b"staking_pool",
            staking_pool.tng_mint.as_ref(),
            &[staking_pool.bump],
        ];
        let signer = &[&seeds[..]];

        let transfer_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.vault.to_account_info(),
                to: ctx.accounts.user_tng_account.to_account_info(),
                authority: ctx.accounts.staking_pool.to_account_info(),
            },
            signer,
        );
        token::transfer(transfer_ctx, rewards)?;

        // Update user stake position
        user_stake.total_rewards_claimed = user_stake.total_rewards_claimed.checked_add(rewards).unwrap();
        user_stake.last_claim_timestamp = current_time;

        emit!(ClaimRewardsEvent {
            user: ctx.accounts.user.key(),
            rewards,
            timestamp: current_time,
        });

        msg!("Claimed {} TNG rewards", rewards as f64 / 1_000_000_000.0);
        Ok(())
    }

    /// Update APY (only authority can call)
    pub fn update_apy(ctx: Context<UpdateApy>, new_apy_basis_points: u16) -> Result<()> {
        require!(new_apy_basis_points <= 10000, StakingError::InvalidAPY); // Max 100% APY
        
        let staking_pool = &mut ctx.accounts.staking_pool;
        staking_pool.apy_basis_points = new_apy_basis_points;

        msg!("APY updated to {}%", new_apy_basis_points as f64 / 100.0);
        Ok(())
    }

    /// Emergency pause/unpause (only authority)
    pub fn set_pool_status(ctx: Context<SetPoolStatus>, is_active: bool) -> Result<()> {
        let staking_pool = &mut ctx.accounts.staking_pool;
        staking_pool.is_active = is_active;

        msg!("Pool status set to: {}", if is_active { "active" } else { "paused" });
        Ok(())
    }

    /// Update sTNG mint address (only authority can call) - Emergency function
    pub fn update_stng_mint(ctx: Context<UpdateStngMint>, new_stng_mint: Pubkey) -> Result<()> {
        let staking_pool = &mut ctx.accounts.staking_pool;
        let old_stng_mint = staking_pool.stng_mint;
        
        staking_pool.stng_mint = new_stng_mint;
        
        msg!("sTNG mint updated from {} to {}", old_stng_mint, new_stng_mint);
        Ok(())
    }

    /// Transfer vault authority to staking pool (one-time setup after initialization)
    pub fn transfer_vault_authority(ctx: Context<TransferVaultAuthority>) -> Result<()> {
        // This function just validates that the vault authority transfer was done externally
        // The actual authority transfer must be done via SPL Token SetAuthority instruction
        msg!("Vault authority transfer validated");
        Ok(())
    }
}

// Account structures
#[account]
pub struct StakingPool {
    pub authority: Pubkey,        // Pool authority (admin)
    pub tng_mint: Pubkey,         // TNG token mint
    pub stng_mint: Pubkey,        // sTNG (staked TNG) token mint
    pub vault: Pubkey,            // Token vault holding staked TNG
    pub total_staked: u64,        // Total TNG tokens staked
    pub total_stng_supply: u64,   // Total sTNG tokens minted
    pub apy_basis_points: u16,    // APY in basis points (850 = 8.5%)
    pub bump: u8,                 // PDA bump
    pub is_active: bool,          // Pool status
    pub created_at: i64,          // Unix timestamp
}

#[account]
pub struct UserStake {
    pub user: Pubkey,                    // User's public key
    pub staking_pool: Pubkey,            // Reference to staking pool
    pub staked_amount: u64,              // TNG tokens staked by user
    pub stng_amount: u64,                // sTNG tokens owned by user
    pub total_rewards_claimed: u64,      // Total rewards claimed by user
    pub stake_timestamp: i64,            // When user first staked
    pub last_claim_timestamp: i64,       // Last time rewards were claimed
}

// Context structures
#[derive(Accounts)]
#[instruction(bump: u8)]
pub struct Initialize<'info> {
    #[account(
        init,
        payer = authority, // payer = sponsor (authority pays for pool creation)
        space = 8 + size_of::<StakingPool>(),
        seeds = [b"staking_pool", tng_mint.key().as_ref()],
        bump
    )]
    pub staking_pool: Account<'info, StakingPool>,
    
    /// Authority/Sponsor who pays for pool creation
    #[account(mut)]
    pub authority: Signer<'info>,
    
    /// TNG token mint
    pub tng_mint: Account<'info, Mint>,
    
    /// sTNG token mint (to be created)
    #[account(mut)]
    pub stng_mint: Account<'info, Mint>,
    
    /// Vault to hold staked TNG tokens (ATA for staking pool)
    #[account(
        init,
        payer = authority,
        associated_token::mint = tng_mint,
        associated_token::authority = staking_pool
    )]
    pub vault: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

#[derive(Accounts)]
pub struct Stake<'info> {
    #[account(
        mut,
        seeds = [b"staking_pool", staking_pool.tng_mint.as_ref()],
        bump = staking_pool.bump
    )]
    pub staking_pool: Account<'info, StakingPool>,
    
    #[account(
        init_if_needed,
        payer = payer, // payer = sponsor (who pays for PDA creation)
        space = 8 + size_of::<UserStake>(),
        seeds = [b"user_stake", user.key().as_ref(), staking_pool.key().as_ref()],
        bump
    )]
    pub user_stake: Account<'info, UserStake>,
    
    /// Sponsor/FeePayer who pays for all transaction costs and PDA creation
    #[account(mut)]
    pub payer: Signer<'info>,
    
    /// User who owns the stake (signer for authorization)
    #[account(mut)]
    pub user: Signer<'info>,
    
    /// User's TNG token account
    #[account(
        mut,
        token::mint = staking_pool.tng_mint,
        token::authority = user
    )]
    pub user_tng_account: Account<'info, TokenAccount>,
    
    /// User's sTNG token account (must exist)
    #[account(
        mut,
        token::mint = staking_pool.stng_mint,
        token::authority = user
    )]
    pub user_stng_account: Account<'info, TokenAccount>,
    
    /// Vault holding staked TNG
    #[account(
        mut,
        token::mint = staking_pool.tng_mint
    )]
    pub vault: Account<'info, TokenAccount>,
    
    /// sTNG mint
    #[account(mut)]
    pub stng_mint: Account<'info, Mint>,
    
    pub token_program: Program<'info, Token>,

    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

#[derive(Accounts)]
pub struct Unstake<'info> {
    #[account(
        mut,
        seeds = [b"staking_pool", staking_pool.tng_mint.as_ref()],
        bump = staking_pool.bump
    )]
    pub staking_pool: Account<'info, StakingPool>,
    
    #[account(
        mut,
        seeds = [b"user_stake", user.key().as_ref(), staking_pool.key().as_ref()],
        bump,
        has_one = user,
        has_one = staking_pool
    )]
    pub user_stake: Account<'info, UserStake>,
    
    /// Sponsor/FeePayer who pays for all transaction costs
    #[account(mut)]
    pub payer: Signer<'info>,
    
    /// User who owns the stake (signer for authorization)
    #[account(mut)]
    pub user: Signer<'info>,
    
    /// User's TNG token account
    #[account(
        mut,
        token::mint = staking_pool.tng_mint,
        token::authority = user
    )]
    pub user_tng_account: Account<'info, TokenAccount>,
    
    /// User's sTNG token account
    #[account(
        mut,
        token::mint = staking_pool.stng_mint,
        token::authority = user
    )]
    pub user_stng_account: Account<'info, TokenAccount>,
    
    /// Vault holding staked TNG
    #[account(
        mut,
        token::mint = staking_pool.tng_mint
    )]
    pub vault: Account<'info, TokenAccount>,
    
    /// sTNG mint
    #[account(mut)]
    pub stng_mint: Account<'info, Mint>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct ClaimRewards<'info> {
    #[account(
        seeds = [b"staking_pool", staking_pool.tng_mint.as_ref()],
        bump = staking_pool.bump
    )]
    pub staking_pool: Account<'info, StakingPool>,
    
    #[account(
        mut,
        seeds = [b"user_stake", user.key().as_ref(), staking_pool.key().as_ref()],
        bump,
        has_one = user,
        has_one = staking_pool
    )]
    pub user_stake: Account<'info, UserStake>,
    
    #[account(mut)]
    pub user: Signer<'info>,
    
    /// User's TNG token account for rewards
    #[account(
        mut,
        token::mint = staking_pool.tng_mint,
        token::authority = user
    )]
    pub user_tng_account: Account<'info, TokenAccount>,
    
    /// Vault holding TNG for rewards
    #[account(
        mut,
        token::mint = staking_pool.tng_mint
    )]
    pub vault: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct UpdateApy<'info> {
    #[account(
        mut,
        seeds = [b"staking_pool", staking_pool.tng_mint.as_ref()],
        bump = staking_pool.bump,
        has_one = authority
    )]
    pub staking_pool: Account<'info, StakingPool>,
    
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct SetPoolStatus<'info> {
    #[account(
        mut,
        seeds = [b"staking_pool", staking_pool.tng_mint.as_ref()],
        bump = staking_pool.bump,
        has_one = authority
    )]
    pub staking_pool: Account<'info, StakingPool>,
    
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct UpdateStngMint<'info> {
    #[account(
        mut,
        seeds = [b"staking_pool", staking_pool.tng_mint.as_ref()],
        bump = staking_pool.bump,
        has_one = authority
    )]
    pub staking_pool: Account<'info, StakingPool>,
    
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct TransferVaultAuthority<'info> {
    #[account(
        seeds = [b"staking_pool", staking_pool.tng_mint.as_ref()],
        bump = staking_pool.bump,
        has_one = authority
    )]
    pub staking_pool: Account<'info, StakingPool>,
    
    #[account(
        mut,
        token::mint = staking_pool.tng_mint,
        token::authority = staking_pool
    )]
    pub vault: Account<'info, TokenAccount>,
    
    pub authority: Signer<'info>,
}

// Events
#[event]
pub struct StakeEvent {
    pub user: Pubkey,
    pub amount: u64,
    pub stng_amount: u64,
    pub timestamp: i64,
}

#[event]
pub struct UnstakeEvent {
    pub user: Pubkey,
    pub stng_amount: u64,
    pub tng_amount: u64,
    pub rewards: u64,
    pub timestamp: i64,
}

#[event]
pub struct ClaimRewardsEvent {
    pub user: Pubkey,
    pub rewards: u64,
    pub timestamp: i64,
}

// Error codes
#[error_code]
pub enum StakingError {
    #[msg("Invalid amount: must be greater than 0")]
    InvalidAmount,
    
    #[msg("Below minimum stake: must stake at least 100 TNG")]
    BelowMinimumStake,
    
    #[msg("Pool is currently inactive")]
    PoolInactive,
    
    #[msg("Insufficient staked amount")]
    InsufficientStakedAmount,
    
    #[msg("No rewards to claim")]
    NoRewardsToClaim,
    
    #[msg("Invalid APY: must be between 0-100%")]
    InvalidAPY,
}
