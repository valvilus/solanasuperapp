const { Connection, PublicKey, clusterApiUrl } = require('@solana/web3.js');

async function checkStakingPoolRaw() {
  const connection = new Connection(clusterApiUrl('devnet'), 'confirmed');
  const stakingPoolPda = new PublicKey('9qorAZnqV5VtutPif3NWP8W9Wz3o7KWmjw7NpHPChf8D');
  
  try {
    console.log(' Checking staking pool raw data...');
    
    const accountInfo = await connection.getAccountInfo(stakingPoolPda);
    if (!accountInfo) {
      console.log(' Staking pool account not found');
      return;
    }
    
    console.log(' Staking pool account exists');
    console.log(' Owner:', accountInfo.owner.toBase58());
    console.log(' Data Length:', accountInfo.data.length);
    
    // Raw data inspection
    const data = accountInfo.data;
    console.log('');
    console.log(' Raw Data Analysis:');
    
    // Convert hex to base58 for sTNG mint (bytes 72-104)
    const stngMintBytes = data.slice(72, 104);
    const stngMintPubkey = new PublicKey(stngMintBytes);
    console.log('');
    console.log(' sTNG Mint from staking pool:', stngMintPubkey.toBase58());
    console.log(' Expected sTNG Mint:        2R6DUNNim4DoaArB4qdjaz9UcsndKjv9YLmkyWGcsvsk');
    console.log(' Match:', stngMintPubkey.toBase58() === '2R6DUNNim4DoaArB4qdjaz9UcsndKjv9YLmkyWGcsvsk' ? ' YES' : ' NO');
    
    // Also check TNG mint for verification
    const tngMintBytes = data.slice(40, 72);
    const tngMintPubkey = new PublicKey(tngMintBytes);
    console.log('');
    console.log(' TNG Mint from staking pool:', tngMintPubkey.toBase58());
    console.log(' Expected TNG Mint:        FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs');
    console.log(' Match:', tngMintPubkey.toBase58() === 'FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs' ? ' YES' : ' NO');
    
  } catch (error) {
    console.error(' Error:', error.message);
  }
}

checkStakingPoolRaw();



