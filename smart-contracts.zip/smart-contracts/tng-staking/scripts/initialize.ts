import * as anchor from "@coral-xyz/anchor";
import { Program, AnchorProvider, Wallet } from "@coral-xyz/anchor";
import { 
  PublicKey, 
  Keypair, 
  SystemProgram,
  SYSVAR_RENT_PUBKEY,
  Connection,
  clusterApiUrl
} from "@solana/web3.js";
import {
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  getAssociatedTokenAddress
} from "@solana/spl-token";
import fs from 'fs';

// Load keypairs
const sponsorKeypair = Keypair.fromSecretKey(
  new Uint8Array(JSON.parse(fs.readFileSync('../../keys/mvp-sponsor-keypair.json', 'utf-8')))
);

// Token mint addresses
const TNG_MINT = new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs");
const STNG_MINT = new PublicKey("2R6DUNNim4DoaArB4qdjaz9UcsndKjv9YLmkyWGcsvsk");

async function initialize() {
  // Configure the client to use the devnet cluster
  const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
  const wallet = new Wallet(sponsorKeypair);
  const provider = new AnchorProvider(connection, wallet, {
    commitment: "confirmed",
  });
  anchor.setProvider(provider);

  // Load program
  const idl = JSON.parse(fs.readFileSync('./target/idl/tng_staking.json', 'utf-8'));
  const program = new Program(idl, provider);

  console.log(" Initializing TNG Staking Pool...");
  console.log(" Program ID:", program.programId.toString());
  console.log(" Authority:", sponsorKeypair.publicKey.toString());
  console.log(" TNG Mint:", TNG_MINT.toString());
  console.log(" sTNG Mint:", STNG_MINT.toString());

  // Find PDA for staking pool
  const [stakingPoolPda, bump] = PublicKey.findProgramAddressSync(
    [Buffer.from("staking_pool"), TNG_MINT.toBuffer()],
    program.programId
  );

  console.log(" Staking Pool PDA:", stakingPoolPda.toString());
  console.log(" Bump:", bump);

  // Find vault PDA
  const vaultAta = await getAssociatedTokenAddress(
    TNG_MINT,
    stakingPoolPda,
    true
  );

  console.log(" Vault ATA:", vaultAta.toString());

  try {
    // Initialize the staking pool
    const tx = await program.methods
      .initialize(bump)
      .accounts({
        stakingPool: stakingPoolPda,
        authority: sponsorKeypair.publicKey,
        tngMint: TNG_MINT,
        stngMint: STNG_MINT,
        vault: vaultAta,
        tokenProgram: TOKEN_PROGRAM_ID,
        associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
        rent: SYSVAR_RENT_PUBKEY,
      })
      .signers([sponsorKeypair])
      .rpc();

    console.log(" Staking pool initialized!");
    console.log(" Transaction signature:", tx);
    console.log(" Explorer:", `https://explorer.solana.com/tx/${tx}?cluster=devnet`);

    // Save deployment info
    const deploymentInfo = {
      programId: program.programId.toString(),
      stakingPoolPda: stakingPoolPda.toString(),
      bump,
      vault: vaultAta.toString(),
      tngMint: TNG_MINT.toString(),
      stngMint: STNG_MINT.toString(),
      authority: sponsorKeypair.publicKey.toString(),
      network: "devnet",
      initTx: tx,
      explorerUrl: `https://explorer.solana.com/tx/${tx}?cluster=devnet`,
      deployedAt: new Date().toISOString()
    };

    fs.writeFileSync('deployment-info.json', JSON.stringify(deploymentInfo, null, 2));
    console.log(" Deployment info saved to deployment-info.json");

  } catch (error) {
    console.error(" Error initializing staking pool:", error);
    throw error;
  }
}

initialize().catch(console.error);
