import * as anchor from "@coral-xyz/anchor";
import { Program, AnchorProvider, Wallet } from "@coral-xyz/anchor";
import { 
  PublicKey, 
  Keypair, 
  SystemProgram,
  SYSVAR_RENT_PUBKEY,
  Connection,
  clusterApiUrl,
  Transaction,
  sendAndConfirmTransaction
} from "@solana/web3.js";
import {
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  getAssociatedTokenAddress
} from "@solana/spl-token";
import fs from 'fs';

// Load keypairs
const sponsorKeypair = Keypair.fromSecretKey(
  new Uint8Array(JSON.parse(fs.readFileSync('../../keys/mvp-sponsor-keypair.json', 'utf-8')))
);

// Token mint addresses
const TNG_MINT = new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs");
const NEW_STNG_MINT = new PublicKey("2R6DUNNim4DoaArB4qdjaz9UcsndKjv9YLmkyWGcsvsk");

async function reinitializeStakingPool() {
  // Configure the client to use the devnet cluster
  const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
  const wallet = new Wallet(sponsorKeypair);
  const provider = new AnchorProvider(connection, wallet, {
    commitment: "confirmed",
  });
  anchor.setProvider(provider);

  // Load program
  const idl = JSON.parse(fs.readFileSync('./target/idl/tng_staking.json', 'utf-8'));
  const program = new Program(idl, provider);

  console.log(" Reinitializing TNG Staking Pool...");
  console.log(" Program ID:", program.programId.toString());
  console.log(" Authority:", sponsorKeypair.publicKey.toString());
  console.log(" TNG Mint:", TNG_MINT.toString());
  console.log(" NEW sTNG Mint:", NEW_STNG_MINT.toString());

  // Find PDA for staking pool
  const [stakingPoolPda, bump] = PublicKey.findProgramAddressSync(
    [Buffer.from("staking_pool"), TNG_MINT.toBuffer()],
    program.programId
  );

  console.log(" Staking Pool PDA:", stakingPoolPda.toString());
  console.log(" Bump:", bump);

  try {
    // Check if staking pool already exists
    const existingAccount = await connection.getAccountInfo(stakingPoolPda);
    if (existingAccount) {
      console.log(" Staking pool already exists. This will fail.");
      console.log(" Cannot reinitialize existing account with Anchor");
      console.log("");
      console.log(" ALTERNATIVE SOLUTIONS:");
      console.log("1. Create a completely new staking program");
      console.log("2. Add an 'update_stng_mint' instruction to the program");
      console.log("3. Close the existing account and recreate (requires draining funds first)");
      console.log("");
      console.log(" RECOMMENDED: Create new staking program with new sTNG mint");
      return;
    }

    // Find vault PDA
    const vaultAta = await getAssociatedTokenAddress(
      TNG_MINT,
      stakingPoolPda,
      true
    );

    console.log(" Vault ATA:", vaultAta.toString());

    // Initialize the staking pool with NEW sTNG mint
    const tx = await program.methods
      .initialize(bump)
      .accounts({
        stakingPool: stakingPoolPda,
        authority: sponsorKeypair.publicKey,
        tngMint: TNG_MINT,
        stngMint: NEW_STNG_MINT,  // Use NEW sTNG mint
        vault: vaultAta,
        tokenProgram: TOKEN_PROGRAM_ID,
        associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
        rent: SYSVAR_RENT_PUBKEY,
      })
      .signers([sponsorKeypair])
      .rpc();

    console.log(" Staking pool reinitialized successfully!");
    console.log(" Transaction signature:", tx);
    console.log(" Explorer:", `https://explorer.solana.com/tx/${tx}?cluster=devnet`);

    // Update deployment info
    const deploymentInfo = {
      programId: program.programId.toString(),
      stakingPoolPda: stakingPoolPda.toString(),
      bump: bump,
      vault: vaultAta.toString(),
      tngMint: TNG_MINT.toString(),
      stngMint: NEW_STNG_MINT.toString(),
      authority: sponsorKeypair.publicKey.toString(),
      network: "devnet",
      initTx: tx,
      explorerUrl: `https://explorer.solana.com/tx/${tx}?cluster=devnet`,
      deployedAt: new Date().toISOString()
    };

    fs.writeFileSync('./deployment-info.json', JSON.stringify(deploymentInfo, null, 2));
    console.log(" Deployment info updated");

  } catch (error) {
    console.error(' Error reinitializing staking pool:', error);
    
    if (error.message.includes('already in use')) {
      console.log("");
      console.log(" Account already exists. Need to use different approach.");
    }
  }
}

// Run if called directly
if (require.main === module) {
  reinitializeStakingPool().catch(console.error);
}



