import * as anchor from "@coral-xyz/anchor";
import { Program, AnchorProvider, Wallet } from "@coral-xyz/anchor";
import { 
  PublicKey, 
  Keypair, 
  Connection,
  clusterApiUrl,
  Transaction
} from "@solana/web3.js";
import {
  TOKEN_PROGRAM_ID,
  setAuthority,
  AuthorityType
} from "@solana/spl-token";
import fs from 'fs';

// Load keypairs
const sponsorKeypair = Keypair.fromSecretKey(
  new Uint8Array(JSON.parse(fs.readFileSync('../../keys/mvp-sponsor-keypair.json', 'utf-8')))
);

// Token mint addresses
const TNG_MINT = new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs");
const STNG_MINT = new PublicKey("89Srwa82XbFZiNcbm5uY43BWLy4HKxp5EZdwtH3zbHex");

// Program IDs
const OLD_PROGRAM_ID = new PublicKey("HQEY4xvroTrgEjwUcfGvqtcCdPN3zYTqHw83FiGWpBvH");
const NEW_PROGRAM_ID = new PublicKey("ArBvk3DQtxKES6EbdhequHQKKKYjhMFp7S8ob8Q5inHg");

async function transferMintAuthority() {
  const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
  
  console.log(" Transferring sTNG Mint Authority...");
  console.log(" sTNG Mint:", STNG_MINT.toString());
  console.log(" Sponsor:", sponsorKeypair.publicKey.toString());
  
  // Calculate old and new staking pool PDAs
  const [oldStakingPoolPda] = PublicKey.findProgramAddressSync(
    [Buffer.from("staking_pool"), TNG_MINT.toBuffer()],
    OLD_PROGRAM_ID
  );
  
  const [newStakingPoolPda] = PublicKey.findProgramAddressSync(
    [Buffer.from("staking_pool"), TNG_MINT.toBuffer()],
    NEW_PROGRAM_ID
  );
  
  console.log(" Old Staking Pool PDA:", oldStakingPoolPda.toString());
  console.log(" New Staking Pool PDA:", newStakingPoolPda.toString());
  
  try {
    // Load old program
    const oldIdl = JSON.parse(fs.readFileSync('./target/idl/tng_staking.json', 'utf-8'));
    const wallet = new Wallet(sponsorKeypair);
    const provider = new AnchorProvider(connection, wallet, {
      commitment: "confirmed",
    });
    anchor.setProvider(provider);
    
    // Create program instance for old program
    const oldProgram = new Program(oldIdl, OLD_PROGRAM_ID, provider);
    
    console.log(" Checking current mint authority...");
    
    // Get current mint info
    const { getMint } = await import('@solana/spl-token');
    const mintInfo = await getMint(connection, STNG_MINT);
    
    console.log(" Current Mint Authority:", mintInfo.mintAuthority?.toString());
    
    if (!mintInfo.mintAuthority?.equals(oldStakingPoolPda)) {
      console.log(" Current mint authority is not the old staking pool!");
      console.log("   Expected:", oldStakingPoolPda.toString());
      console.log("   Actual:", mintInfo.mintAuthority?.toString());
      return;
    }
    
    console.log(" Mint authority matches old staking pool");
    
    // Create transaction to transfer mint authority
    console.log(" Creating authority transfer transaction...");
    
    const transaction = new Transaction();
    
    // Set new mint authority to the new staking pool PDA
    const setAuthorityInstruction = setAuthority(
      connection,                   // connection
      sponsorKeypair,               // payer
      STNG_MINT,                    // mint
      oldStakingPoolPda,            // current authority (old staking pool)
      AuthorityType.MintTokens,     // authority type
      newStakingPoolPda             // new authority (new staking pool)
    );
    
    // This will return a transaction, not an instruction
    console.log(" This operation requires the old staking pool PDA to sign");
    console.log(" Cannot proceed automatically - requires manual intervention");
    
    // We need to use the old program to sign this transaction
    // because the current authority is the old staking pool PDA
    
    console.log(" This operation requires the old staking pool PDA to sign");
    console.log(" Cannot proceed automatically - requires manual intervention");
    console.log("");
    console.log("  MANUAL STEPS REQUIRED:");
    console.log("1. Deploy a temporary script in the OLD program that can transfer mint authority");
    console.log("2. Or use Solana CLI with the old program's authority");
    console.log("");
    console.log(" Alternative: Create new sTNG mint and update all references");
    
  } catch (error) {
    console.error(' Error:', error);
  }
}

// Run if called directly
if (require.main === module) {
  transferMintAuthority().catch(console.error);
}
