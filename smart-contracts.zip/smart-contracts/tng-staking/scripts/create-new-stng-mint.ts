import { 
  PublicKey, 
  Keypair,
  Connection,
  clusterApiUrl
} from "@solana/web3.js";
import {
  TOKEN_PROGRAM_ID,
  createMint
} from "@solana/spl-token";
import fs from 'fs';
import path from 'path';

// Load keypairs
const sponsorKeypair = Keypair.fromSecretKey(
  new Uint8Array(JSON.parse(fs.readFileSync('../../keys/mvp-sponsor-keypair.json', 'utf-8')))
);

// Token mint addresses
const TNG_MINT = new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs");
const NEW_PROGRAM_ID = new PublicKey("ArBvk3DQtxKES6EbdhequHQKKKYjhMFp7S8ob8Q5inHg");

async function createNewStngMint() {
  const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
  
  console.log(" Creating new sTNG mint...");
  console.log(" Sponsor:", sponsorKeypair.publicKey.toString());
  console.log(" TNG Mint:", TNG_MINT.toString());
  
  // Calculate new staking pool PDA (this will be the mint authority)
  const [newStakingPoolPda] = PublicKey.findProgramAddressSync(
    [Buffer.from("staking_pool"), TNG_MINT.toBuffer()],
    NEW_PROGRAM_ID
  );
  
  console.log(" New Staking Pool PDA (will be mint authority):", newStakingPoolPda.toString());
  
  try {
    // Create new sTNG mint with the new staking pool as authority
    console.log(" Creating sTNG mint...");
    
    const newStngMint = await createMint(
      connection,                    // connection
      sponsorKeypair,               // payer (sponsor pays for mint creation)
      newStakingPoolPda,            // mint authority (new staking pool PDA)
      null,                         // freeze authority (null = no freeze authority)
      9,                            // decimals
      undefined,                    // keypair (undefined = generate new)
      undefined,                    // confirmOptions
      TOKEN_PROGRAM_ID              // program ID
    );
    
    console.log(" New sTNG mint created successfully!");
    console.log(" New sTNG Mint Address:", newStngMint.toBase58());
    console.log(" Mint Authority:", newStakingPoolPda.toBase58());
    console.log(" Freeze Authority: null");
    console.log(" Decimals: 9");
    console.log(" Network: devnet");
    console.log(" Explorer:", `https://explorer.solana.com/address/${newStngMint.toBase58()}?cluster=devnet`);
    
    // Save mint info to JSON file
    const mintInfo = {
      mintAddress: newStngMint.toBase58(),
      symbol: "sTNG",
      name: "Staked TNG",
      decimals: 9,
      network: "devnet",
      description: "Represents staked TNG tokens in the staking pool",
      mintAuthority: newStakingPoolPda.toBase58(),
      freezeAuthority: null,
      createdAt: new Date().toISOString(),
      explorerUrl: `https://explorer.solana.com/address/${newStngMint.toBase58()}?cluster=devnet`
    };
    
    // Save to keys directory
    const keysDir = path.join(__dirname, '../../keys');
    const mintInfoPath = path.join(keysDir, 'new-stng-mint-info.json');
    fs.writeFileSync(mintInfoPath, JSON.stringify(mintInfo, null, 2));
    console.log(" New sTNG mint info saved to:", mintInfoPath);
    
    console.log("");
    console.log(" NEXT STEPS:");
    console.log("1. Update TypeScript code with new sTNG mint address");
    console.log("2. Update deployment-info.json files");
    console.log("3. Update any other references to old sTNG mint");
    console.log("");
    console.log(" New sTNG Mint Address to use:");
    console.log(newStngMint.toBase58());
    
    return newStngMint;
    
  } catch (error) {
    console.error(' Error creating sTNG mint:', error);
    throw error;
  }
}

// Run if called directly
if (require.main === module) {
  createNewStngMint().catch(console.error);
}

export { createNewStngMint };



