import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { TngOracle } from "../target/types/tng_oracle";

describe("tng-oracle", () => {
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  const program = anchor.workspace.TngOracle as Program<TngOracle>;

  it("Is initialized!", async () => {
    const oracle = anchor.web3.Keypair.generate();
    
    const tx = await program.methods
      .initializeOracle(provider.wallet.publicKey)
      .accounts({
        oracle: oracle.publicKey,
        authority: provider.wallet.publicKey,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .signers([oracle])
      .rpc();

    console.log("Oracle initialized with signature:", tx);
  });
});

