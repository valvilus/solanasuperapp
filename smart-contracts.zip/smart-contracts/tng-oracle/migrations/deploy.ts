const anchor = require('@coral-xyz/anchor');

module.exports = async function (provider) {
  anchor.setProvider(provider);
  console.log('Running deploy script for TNG Oracle...');
};

