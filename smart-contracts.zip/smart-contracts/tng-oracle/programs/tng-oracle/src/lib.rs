use anchor_lang::prelude::*;
use anchor_spl::token::{Token, TokenAccount};
use pyth_solana_receiver_sdk::price_update::{get_feed_id_from_hex, PriceUpdateV2};

declare_id!("5xgD3u61Hat3rLyn6VnTFq1KCQ9oWSgGXgEqaCN6LqLm");

#[program]
pub mod tng_oracle {
    use super::*;
    
    pub fn initialize_oracle(
        ctx: Context<InitializeOracle>,
        update_authority: Pubkey,
    ) -> Result<()> {
        let oracle = &mut ctx.accounts.oracle;
        oracle.authority = ctx.accounts.authority.key();
        oracle.update_authority = update_authority;
        oracle.is_initialized = true;
        oracle.created_at = Clock::get()?.unix_timestamp;
        Ok(())
    }
    
    pub fn update_price_feed(
        ctx: Context<UpdatePriceFeed>,
        asset_mint: Pubkey,
        price: u64,
        confidence: u64,
        source: PriceSource,
    ) -> Result<()> {
        require!(ctx.accounts.oracle.is_initialized, ErrorCode::OracleNotInitialized);
        require!(
            ctx.accounts.authority.key() == ctx.accounts.oracle.update_authority,
            ErrorCode::Unauthorized
        );

        let price_feed = &mut ctx.accounts.price_feed;
        price_feed.oracle = ctx.accounts.oracle.key();
        price_feed.asset_mint = asset_mint;
        price_feed.price = price;
        price_feed.confidence = confidence;
        price_feed.source = source;
        price_feed.last_updated = Clock::get()?.unix_timestamp;
        price_feed.is_active = true;

        Ok(())
    }
    
    pub fn get_price(
        ctx: Context<GetPrice>,
        asset_mint: Pubkey,
    ) -> Result<PriceData> {
        let price_feed = &ctx.accounts.price_feed;
        
        require!(price_feed.asset_mint == asset_mint, ErrorCode::InvalidAsset);
        require!(price_feed.is_active, ErrorCode::PriceFeedInactive);
        
        let current_time = Clock::get()?.unix_timestamp;
        let age = current_time - price_feed.last_updated;
        
        require!(age < 300, ErrorCode::PriceStale);
        
        Ok(PriceData {
            price: price_feed.price,
            confidence: price_feed.confidence,
            last_updated: price_feed.last_updated,
            source: price_feed.source.clone(),
        })
    }

    pub fn add_price_source(
        ctx: Context<AddPriceSource>,
        asset_mint: Pubkey,
        source: PriceSource,
        weight: u64,
    ) -> Result<()> {
        require!(
            ctx.accounts.authority.key() == ctx.accounts.oracle.authority,
            ErrorCode::Unauthorized
        );

        let price_source = &mut ctx.accounts.price_source;
        price_source.oracle = ctx.accounts.oracle.key();
        price_source.asset_mint = asset_mint;
        price_source.source = source;
        price_source.weight = weight;
        price_source.is_active = true;
        price_source.created_at = Clock::get()?.unix_timestamp;

        Ok(())
    }

    pub fn aggregate_prices(
        ctx: Context<AggregatePrices>,
        asset_mint: Pubkey,
    ) -> Result<u64> {
        let mut total_weighted_price = 0u128;
        let mut total_weight = 0u64;

        for price_source in &ctx.remaining_accounts {
            if price_source.owner == &ID {
                let data = price_source.try_borrow_data()?;
                if data.len() >= 8 + 32 + 32 + 1 + 8 + 8 + 1 + 8 {
                    let discriminator = &data[0..8];
                    if discriminator == &[0u8; 8] {
                        continue;
                    }
                    
                    let source_asset_mint = Pubkey::new_from_array(
                        data[40..72].try_into().unwrap()
                    );
                    
                    if source_asset_mint == asset_mint {
                        let price = u64::from_le_bytes(data[73..81].try_into().unwrap());
                        let weight = u64::from_le_bytes(data[81..89].try_into().unwrap());
                        let is_active = data[89] == 1;
                        
                        if is_active {
                            total_weighted_price += (price as u128) * (weight as u128);
                            total_weight += weight;
                        }
                    }
                }
            }
        }

        require!(total_weight > 0, ErrorCode::NoActiveSources);
        
        let aggregated_price = (total_weighted_price / total_weight as u128) as u64;
        
        Ok(aggregated_price)
    }

    pub fn update_from_pyth(
        ctx: Context<UpdateFromPyth>,
        price_update: PriceUpdateV2,
        feed_id: [u8; 32],
        asset_mint: Pubkey,
    ) -> Result<()> {
        require!(ctx.accounts.oracle.is_initialized, ErrorCode::OracleNotInitialized);
        
        let price_data = price_update.get_price_no_older_than(
            &Clock::get()?,
            60, // 60 seconds max age
            &feed_id,
        ).map_err(|_| ErrorCode::PythPriceError)?;
        
        let price_feed = &mut ctx.accounts.price_feed;
        price_feed.oracle = ctx.accounts.oracle.key();
        price_feed.asset_mint = asset_mint;
        price_feed.price = price_data.price as u64;
        price_feed.confidence = price_data.conf as u64;
        price_feed.source = PriceSource::Pyth;
        price_feed.last_updated = Clock::get()?.unix_timestamp;
        price_feed.is_active = true;
        
        Ok(())
    }
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub enum PriceSource {
    Pyth,
    Switchboard,
    Manual,
    ChainlinkSolana,
    Jupiter,
    Orca,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct PriceData {
    pub price: u64,
    pub confidence: u64,
    pub last_updated: i64,
    pub source: PriceSource,
}

#[account]
pub struct Oracle {
    pub authority: Pubkey,
    pub update_authority: Pubkey,
    pub is_initialized: bool,
    pub created_at: i64,
}

#[account]
pub struct PriceFeed {
    pub oracle: Pubkey,
    pub asset_mint: Pubkey,
    pub price: u64,
    pub confidence: u64,
    pub source: PriceSource,
    pub last_updated: i64,
    pub is_active: bool,
}

#[account]
pub struct PriceSourceAccount {
    pub oracle: Pubkey,
    pub asset_mint: Pubkey,
    pub source: PriceSource,
    pub weight: u64,
    pub is_active: bool,
    pub created_at: i64,
}

#[derive(Accounts)]
pub struct InitializeOracle<'info> {
    #[account(init, payer = authority, space = 8 + 32 + 32 + 1 + 8)]
    pub oracle: Account<'info, Oracle>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct UpdatePriceFeed<'info> {
    #[account(init_if_needed, payer = authority, space = 8 + 32 + 32 + 8 + 8 + 1 + 8 + 1)]
    pub price_feed: Account<'info, PriceFeed>,
    pub oracle: Account<'info, Oracle>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct GetPrice<'info> {
    pub price_feed: Account<'info, PriceFeed>,
}

#[derive(Accounts)]
pub struct AddPriceSource<'info> {
    #[account(init, payer = authority, space = 8 + 32 + 32 + 1 + 8 + 1 + 8)]
    pub price_source: Account<'info, PriceSourceAccount>,
    pub oracle: Account<'info, Oracle>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct AggregatePrices<'info> {
    pub oracle: Account<'info, Oracle>,
}

#[derive(Accounts)]
pub struct UpdateFromPyth<'info> {
    #[account(init_if_needed, payer = authority, space = 8 + 32 + 32 + 8 + 8 + 1 + 8 + 1)]
    pub price_feed: Account<'info, PriceFeed>,
    pub oracle: Account<'info, Oracle>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[error_code]
pub enum ErrorCode {
    #[msg("Oracle not initialized")]
    OracleNotInitialized,
    #[msg("Unauthorized")]
    Unauthorized,
    #[msg("Invalid asset")]
    InvalidAsset,
    #[msg("Price feed inactive")]
    PriceFeedInactive,
    #[msg("Price data is stale")]
    PriceStale,
    #[msg("No active price sources")]
    NoActiveSources,
    #[msg("Pyth price error")]
    PythPriceError,
}

