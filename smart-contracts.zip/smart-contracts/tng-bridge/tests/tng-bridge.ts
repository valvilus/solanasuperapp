import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { TngBridge } from "../target/types/tng_bridge";

describe("tng-bridge", () => {
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  const program = anchor.workspace.TngBridge as Program<TngBridge>;

  it("Initializes bridge!", async () => {
    const supportedChains = [1, 56, 137]; // Ethereum, BSC, Polygon
    const validatorSet = [
      anchor.web3.Keypair.generate().publicKey,
      anchor.web3.Keypair.generate().publicKey,
      anchor.web3.Keypair.generate().publicKey
    ];
    const threshold = 2;
    
    const tx = await program.methods
      .initializeBridge(supportedChains, validatorSet, threshold)
      .accounts({
        authority: provider.wallet.publicKey,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .rpc();

    console.log("Bridge initialized with signature:", tx);
  });
});
