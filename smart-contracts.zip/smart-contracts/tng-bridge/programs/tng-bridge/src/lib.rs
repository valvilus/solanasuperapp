use anchor_lang::prelude::*;
use anchor_spl::token::{Token, TokenAccount, Transfer, Mint};

declare_id!("8xgG6u61Hat3rLyn6VnTFq1KCQ9oWSgGXgEqaCN6LqLm");

const MAX_VALIDATORS: usize = 21;
const MIN_THRESHOLD: u8 = 2;
const BRIDGE_FEE_BASIS_POINTS: u64 = 25; // 0.25%
const BASIS_POINTS: u64 = 10000;

#[program]
pub mod tng_bridge {
    use super::*;
    
    pub fn initialize_bridge(
        ctx: Context<InitializeBridge>,
        supported_chains: Vec<ChainId>,
        validator_set: Vec<Pubkey>,
        threshold: u8,
    ) -> Result<()> {
        require!(validator_set.len() <= MAX_VALIDATORS, ErrorCode::TooManyValidators);
        require!(threshold >= MIN_THRESHOLD, ErrorCode::ThresholdTooLow);
        require!(threshold <= validator_set.len() as u8, ErrorCode::ThresholdTooHigh);
        require!(!supported_chains.is_empty(), ErrorCode::NoChainsSupported);

        let bridge_config = &mut ctx.accounts.bridge_config;
        bridge_config.authority = ctx.accounts.authority.key();
        bridge_config.supported_chains = supported_chains;
        bridge_config.validators = validator_set;
        bridge_config.threshold = threshold;
        bridge_config.total_locked = 0;
        bridge_config.total_unlocked = 0;
        bridge_config.is_active = true;
        bridge_config.created_at = Clock::get()?.unix_timestamp;
        bridge_config.bump = ctx.bumps.bridge_config;

        Ok(())
    }
    
    pub fn lock_tokens(
        ctx: Context<LockTokens>,
        target_chain: ChainId,
        recipient: String,
        amount: u64,
        token_mint: Pubkey,
    ) -> Result<()> {
        let bridge_config = &ctx.accounts.bridge_config;
        let bridge_transaction = &mut ctx.accounts.bridge_transaction;
        
        require!(bridge_config.is_active, ErrorCode::BridgeInactive);
        require!(amount > 0, ErrorCode::InvalidAmount);
        require!(!recipient.is_empty() && recipient.len() <= 100, ErrorCode::InvalidRecipient);
        require!(
            bridge_config.supported_chains.contains(&target_chain),
            ErrorCode::ChainNotSupported
        );

        let bridge_fee = amount
            .checked_mul(BRIDGE_FEE_BASIS_POINTS)
            .ok_or(ErrorCode::MathOverflow)?
            .checked_div(BASIS_POINTS)
            .ok_or(ErrorCode::MathOverflow)?;

        let net_amount = amount
            .checked_sub(bridge_fee)
            .ok_or(ErrorCode::MathOverflow)?;

        let current_time = Clock::get()?.unix_timestamp;
        let tx_id = (current_time as u64)
            .checked_mul(1000000)
            .ok_or(ErrorCode::MathOverflow)?
            .checked_add(ctx.accounts.user.key().to_bytes()[0] as u64)
            .ok_or(ErrorCode::MathOverflow)?;

        bridge_transaction.tx_id = tx_id;
        bridge_transaction.source_chain = ChainId::Solana;
        bridge_transaction.target_chain = target_chain;
        bridge_transaction.sender = ctx.accounts.user.key().to_string();
        bridge_transaction.recipient = recipient;
        bridge_transaction.amount = net_amount;
        bridge_transaction.fee_amount = bridge_fee;
        bridge_transaction.token_mint = token_mint;
        bridge_transaction.status = BridgeStatus::Pending;
        bridge_transaction.validator_confirmations = vec![false; bridge_config.validators.len()];
        bridge_transaction.created_at = current_time;
        bridge_transaction.completed_at = None;
        bridge_transaction.bump = ctx.bumps.bridge_transaction;

        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.user_token_account.to_account_info(),
                to: ctx.accounts.bridge_vault.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_ctx, amount)?;

        Ok(())
    }
    
    pub fn unlock_tokens(
        ctx: Context<UnlockTokens>,
        source_chain: ChainId,
        transaction_hash: String,
        recipient: Pubkey,
        amount: u64,
        token_mint: Pubkey,
        validator_signatures: Vec<[u8; 64]>,
    ) -> Result<()> {
        let bridge_config = &ctx.accounts.bridge_config;
        let bridge_transaction = &mut ctx.accounts.bridge_transaction;
        
        require!(bridge_config.is_active, ErrorCode::BridgeInactive);
        require!(amount > 0, ErrorCode::InvalidAmount);
        require!(!transaction_hash.is_empty(), ErrorCode::InvalidTransactionHash);
        require!(
            bridge_config.supported_chains.contains(&source_chain),
            ErrorCode::ChainNotSupported
        );
        require!(
            validator_signatures.len() >= bridge_config.threshold as usize,
            ErrorCode::InsufficientSignatures
        );

        bridge_transaction.status = BridgeStatus::Confirmed;
        bridge_transaction.completed_at = Some(Clock::get()?.unix_timestamp);

        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.bridge_vault.to_account_info(),
                to: ctx.accounts.recipient_token_account.to_account_info(),
                authority: ctx.accounts.vault_authority.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_ctx, amount)?;

        Ok(())
    }
    
    pub fn add_validator(
        ctx: Context<AddValidator>,
        validator: Pubkey,
    ) -> Result<()> {
        let bridge_config = &mut ctx.accounts.bridge_config;
        
        require!(
            ctx.accounts.authority.key() == bridge_config.authority,
            ErrorCode::Unauthorized
        );
        require!(
            !bridge_config.validators.contains(&validator),
            ErrorCode::ValidatorAlreadyExists
        );
        require!(
            bridge_config.validators.len() < MAX_VALIDATORS,
            ErrorCode::TooManyValidators
        );

        bridge_config.validators.push(validator);

        Ok(())
    }

    pub fn remove_validator(
        ctx: Context<RemoveValidator>,
        validator: Pubkey,
    ) -> Result<()> {
        let bridge_config = &mut ctx.accounts.bridge_config;
        
        require!(
            ctx.accounts.authority.key() == bridge_config.authority,
            ErrorCode::Unauthorized
        );
        
        if let Some(pos) = bridge_config.validators.iter().position(|&x| x == validator) {
            bridge_config.validators.remove(pos);
        } else {
            return Err(ErrorCode::ValidatorNotFound.into());
        }

        require!(
            bridge_config.validators.len() >= bridge_config.threshold as usize,
            ErrorCode::NotEnoughValidators
        );

        Ok(())
    }

    pub fn update_threshold(
        ctx: Context<UpdateThreshold>,
        new_threshold: u8,
    ) -> Result<()> {
        let bridge_config = &mut ctx.accounts.bridge_config;
        
        require!(
            ctx.accounts.authority.key() == bridge_config.authority,
            ErrorCode::Unauthorized
        );
        require!(new_threshold >= MIN_THRESHOLD, ErrorCode::ThresholdTooLow);
        require!(
            new_threshold <= bridge_config.validators.len() as u8,
            ErrorCode::ThresholdTooHigh
        );

        bridge_config.threshold = new_threshold;

        Ok(())
    }

    pub fn toggle_bridge_status(
        ctx: Context<ToggleBridgeStatus>,
        is_active: bool,
    ) -> Result<()> {
        let bridge_config = &mut ctx.accounts.bridge_config;
        
        require!(
            ctx.accounts.authority.key() == bridge_config.authority,
            ErrorCode::Unauthorized
        );

        bridge_config.is_active = is_active;

        Ok(())
    }

    pub fn cross_chain_swap(
        ctx: Context<CrossChainSwap>,
        source_chain: ChainId,
        target_chain: ChainId,
        input_token: Pubkey,
        output_token: Pubkey,
        amount_in: u64,
        minimum_amount_out: u64,
        recipient: String,
    ) -> Result<()> {
        let bridge_config = &ctx.accounts.bridge_config;
        let swap_transaction = &mut ctx.accounts.swap_transaction;
        
        require!(bridge_config.is_active, ErrorCode::BridgeInactive);
        require!(amount_in > 0, ErrorCode::InvalidAmount);
        require!(minimum_amount_out > 0, ErrorCode::InvalidMinimumAmount);
        require!(!recipient.is_empty(), ErrorCode::InvalidRecipient);

        let current_time = Clock::get()?.unix_timestamp;
        let tx_id = (current_time as u64)
            .checked_mul(2000000)
            .ok_or(ErrorCode::MathOverflow)?
            .checked_add(ctx.accounts.user.key().to_bytes()[1] as u64)
            .ok_or(ErrorCode::MathOverflow)?;

        swap_transaction.tx_id = tx_id;
        swap_transaction.user = ctx.accounts.user.key();
        swap_transaction.source_chain = source_chain;
        swap_transaction.target_chain = target_chain;
        swap_transaction.input_token = input_token;
        swap_transaction.output_token = output_token;
        swap_transaction.amount_in = amount_in;
        swap_transaction.minimum_amount_out = minimum_amount_out;
        swap_transaction.recipient = recipient;
        swap_transaction.status = SwapStatus::Pending;
        swap_transaction.created_at = current_time;
        swap_transaction.bump = ctx.bumps.swap_transaction;

        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.user_token_account.to_account_info(),
                to: ctx.accounts.bridge_vault.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_ctx, amount_in)?;

        Ok(())
    }

    pub fn cross_chain_liquidity_provision(
        ctx: Context<CrossChainLP>,
        target_chain: ChainId,
        token_a: Pubkey,
        token_b: Pubkey,
        amount_a: u64,
        amount_b: u64,
        recipient: String,
    ) -> Result<()> {
        let bridge_config = &ctx.accounts.bridge_config;
        let lp_transaction = &mut ctx.accounts.lp_transaction;
        
        require!(bridge_config.is_active, ErrorCode::BridgeInactive);
        require!(amount_a > 0 && amount_b > 0, ErrorCode::InvalidAmount);
        require!(!recipient.is_empty(), ErrorCode::InvalidRecipient);
        require!(
            bridge_config.supported_chains.contains(&target_chain),
            ErrorCode::ChainNotSupported
        );

        let current_time = Clock::get()?.unix_timestamp;
        let tx_id = (current_time as u64)
            .checked_mul(3000000)
            .ok_or(ErrorCode::MathOverflow)?
            .checked_add(ctx.accounts.user.key().to_bytes()[2] as u64)
            .ok_or(ErrorCode::MathOverflow)?;

        lp_transaction.tx_id = tx_id;
        lp_transaction.user = ctx.accounts.user.key();
        lp_transaction.target_chain = target_chain;
        lp_transaction.token_a = token_a;
        lp_transaction.token_b = token_b;
        lp_transaction.amount_a = amount_a;
        lp_transaction.amount_b = amount_b;
        lp_transaction.recipient = recipient;
        lp_transaction.status = LPStatus::Pending;
        lp_transaction.created_at = current_time;
        lp_transaction.bump = ctx.bumps.lp_transaction;

        // Transfer token A
        let transfer_a_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.user_token_a_account.to_account_info(),
                to: ctx.accounts.bridge_vault_a.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_a_ctx, amount_a)?;

        // Transfer token B
        let transfer_b_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.user_token_b_account.to_account_info(),
                to: ctx.accounts.bridge_vault_b.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        anchor_spl::token::transfer(transfer_b_ctx, amount_b)?;

        Ok(())
    }
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, PartialEq)]
pub enum ChainId {
    Solana = 0,
    Ethereum = 1,
    BSC = 56,
    Polygon = 137,
    Avalanche = 43114,
    Arbitrum = 42161,
    Optimism = 10,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq)]
pub enum BridgeStatus {
    Pending,
    Confirmed,
    Completed,
    Failed,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq)]
pub enum SwapStatus {
    Pending,
    Processing,
    Completed,
    Failed,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq)]
pub enum LPStatus {
    Pending,
    Processing,
    Completed,
    Failed,
}

#[account]
pub struct BridgeConfig {
    pub authority: Pubkey,
    pub supported_chains: Vec<ChainId>,
    pub validators: Vec<Pubkey>,
    pub threshold: u8,
    pub total_locked: u64,
    pub total_unlocked: u64,
    pub is_active: bool,
    pub created_at: i64,
    pub bump: u8,
}

#[account]
pub struct BridgeTransaction {
    pub tx_id: u64,
    pub source_chain: ChainId,
    pub target_chain: ChainId,
    pub sender: String,
    pub recipient: String,
    pub amount: u64,
    pub fee_amount: u64,
    pub token_mint: Pubkey,
    pub status: BridgeStatus,
    pub validator_confirmations: Vec<bool>,
    pub created_at: i64,
    pub completed_at: Option<i64>,
    pub bump: u8,
}

#[account]
pub struct CrossChainSwapTransaction {
    pub tx_id: u64,
    pub user: Pubkey,
    pub source_chain: ChainId,
    pub target_chain: ChainId,
    pub input_token: Pubkey,
    pub output_token: Pubkey,
    pub amount_in: u64,
    pub minimum_amount_out: u64,
    pub recipient: String,
    pub status: SwapStatus,
    pub created_at: i64,
    pub bump: u8,
}

#[account]
pub struct CrossChainLPTransaction {
    pub tx_id: u64,
    pub user: Pubkey,
    pub target_chain: ChainId,
    pub token_a: Pubkey,
    pub token_b: Pubkey,
    pub amount_a: u64,
    pub amount_b: u64,
    pub recipient: String,
    pub status: LPStatus,
    pub created_at: i64,
    pub bump: u8,
}

#[derive(Accounts)]
pub struct InitializeBridge<'info> {
    #[account(
        init,
        payer = authority,
        space = 8 + 32 + 4 + 10*1 + 4 + 21*32 + 1 + 8 + 8 + 1 + 8 + 1,
        seeds = [b"bridge_config"],
        bump
    )]
    pub bridge_config: Account<'info, BridgeConfig>,
    
    #[account(mut)]
    pub authority: Signer<'info>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct LockTokens<'info> {
    #[account(
        seeds = [b"bridge_config"],
        bump = bridge_config.bump
    )]
    pub bridge_config: Account<'info, BridgeConfig>,
    
    #[account(
        init,
        payer = user,
        space = 8 + 8 + 1 + 1 + 64 + 100 + 8 + 8 + 32 + 1 + 4 + 21*1 + 8 + 9 + 1,
        seeds = [b"bridge_tx", user.key().as_ref()],
        bump
    )]
    pub bridge_transaction: Account<'info, BridgeTransaction>,
    
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub bridge_vault: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct UnlockTokens<'info> {
    #[account(
        seeds = [b"bridge_config"],
        bump = bridge_config.bump
    )]
    pub bridge_config: Account<'info, BridgeConfig>,
    
    #[account(mut)]
    pub bridge_transaction: Account<'info, BridgeTransaction>,
    
    #[account(mut)]
    pub bridge_vault: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub recipient_token_account: Account<'info, TokenAccount>,
    
    /// CHECK: Vault authority PDA
    pub vault_authority: AccountInfo<'info>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct AddValidator<'info> {
    #[account(
        mut,
        seeds = [b"bridge_config"],
        bump = bridge_config.bump
    )]
    pub bridge_config: Account<'info, BridgeConfig>,
    
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct RemoveValidator<'info> {
    #[account(
        mut,
        seeds = [b"bridge_config"],
        bump = bridge_config.bump
    )]
    pub bridge_config: Account<'info, BridgeConfig>,
    
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct UpdateThreshold<'info> {
    #[account(
        mut,
        seeds = [b"bridge_config"],
        bump = bridge_config.bump
    )]
    pub bridge_config: Account<'info, BridgeConfig>,
    
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct ToggleBridgeStatus<'info> {
    #[account(
        mut,
        seeds = [b"bridge_config"],
        bump = bridge_config.bump
    )]
    pub bridge_config: Account<'info, BridgeConfig>,
    
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct CrossChainSwap<'info> {
    #[account(
        seeds = [b"bridge_config"],
        bump = bridge_config.bump
    )]
    pub bridge_config: Account<'info, BridgeConfig>,
    
    #[account(
        init,
        payer = user,
        space = 8 + 8 + 32 + 1 + 1 + 32 + 32 + 8 + 8 + 100 + 1 + 8 + 1,
        seeds = [b"swap_tx", user.key().as_ref()],
        bump
    )]
    pub swap_transaction: Account<'info, CrossChainSwapTransaction>,
    
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub bridge_vault: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct CrossChainLP<'info> {
    #[account(
        seeds = [b"bridge_config"],
        bump = bridge_config.bump
    )]
    pub bridge_config: Account<'info, BridgeConfig>,
    
    #[account(
        init,
        payer = user,
        space = 8 + 8 + 32 + 1 + 32 + 32 + 8 + 8 + 100 + 1 + 8 + 1,
        seeds = [b"lp_tx", user.key().as_ref()],
        bump
    )]
    pub lp_transaction: Account<'info, CrossChainLPTransaction>,
    
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(mut)]
    pub user_token_a_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub user_token_b_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub bridge_vault_a: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub bridge_vault_b: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[error_code]
pub enum ErrorCode {
    #[msg("Too many validators")]
    TooManyValidators,
    #[msg("Threshold too low")]
    ThresholdTooLow,
    #[msg("Threshold too high")]
    ThresholdTooHigh,
    #[msg("No chains supported")]
    NoChainsSupported,
    #[msg("Bridge inactive")]
    BridgeInactive,
    #[msg("Invalid amount")]
    InvalidAmount,
    #[msg("Invalid recipient")]
    InvalidRecipient,
    #[msg("Chain not supported")]
    ChainNotSupported,
    #[msg("Math overflow")]
    MathOverflow,
    #[msg("Invalid transaction hash")]
    InvalidTransactionHash,
    #[msg("Insufficient signatures")]
    InsufficientSignatures,
    #[msg("Unauthorized")]
    Unauthorized,
    #[msg("Validator already exists")]
    ValidatorAlreadyExists,
    #[msg("Validator not found")]
    ValidatorNotFound,
    #[msg("Not enough validators")]
    NotEnoughValidators,
    #[msg("Invalid minimum amount")]
    InvalidMinimumAmount,
}
