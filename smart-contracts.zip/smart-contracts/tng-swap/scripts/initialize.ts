import * as anchor from "@coral-xyz/anchor";
import { Program, AnchorProvider, Wallet } from "@coral-xyz/anchor";
import { 
  PublicKey, 
  Keypair, 
  SystemProgram,
  Connection,
  clusterApiUrl
} from "@solana/web3.js";
import {
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  getAssociatedTokenAddress,
  getOrCreateAssociatedTokenAccount,
  transfer,
} from "@solana/spl-token";
import fs from 'fs';

// Load keypairs
const sponsorKeypair = Keypair.fromSecretKey(
  new Uint8Array(JSON.parse(fs.readFileSync('../../keys/mvp-sponsor-keypair.json', 'utf-8')))
);

// Token mint addresses
const TNG_MINT = new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs");
const SOL_MINT = new PublicKey("So11111111111111111111111111111111111111112"); // Wrapped SOL

async function initialize() {
  // Configure the client to use the devnet cluster
  const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
  const wallet = new Wallet(sponsorKeypair);
  const provider = new AnchorProvider(connection, wallet, {
    commitment: "confirmed",
  });
  anchor.setProvider(provider);

  // Load program
  const idl = JSON.parse(fs.readFileSync('./target/idl/tng_swap.json', 'utf-8'));
  const program = new Program(idl, provider);

  console.log(" Initializing TNG Swap Pool...");
  console.log(" Program ID:", program.programId.toString());
  console.log(" Authority:", sponsorKeypair.publicKey.toString());
  console.log(" TNG Mint:", TNG_MINT.toString());
  console.log(" SOL Mint:", SOL_MINT.toString());

  // Find PDA for swap pool (TNG/SOL pair)
  const [swapPoolPda, bump] = PublicKey.findProgramAddressSync(
    [Buffer.from("swap_pool"), TNG_MINT.toBuffer(), SOL_MINT.toBuffer()],
    program.programId
  );

  console.log(" Swap Pool PDA:", swapPoolPda.toString());
  console.log(" Bump:", bump);

  // Find vault PDAs
  const tngVault = await getAssociatedTokenAddress(
    TNG_MINT,
    swapPoolPda,
    true
  );

  const solVault = await getAssociatedTokenAddress(
    SOL_MINT,
    swapPoolPda,
    true
  );

  console.log(" TNG Vault:", tngVault.toString());
  console.log(" SOL Vault:", solVault.toString());

  // Create LP mint keypair
  const lpMintKeypair = Keypair.generate();
  console.log(" LP Mint:", lpMintKeypair.publicKey.toString());

  try {
    // Initialize the swap pool
    const initialTngAmount = 1000 * 1e9; // 1000 TNG
    const initialSolAmount = 1 * 1e9;    // 1 SOL

    const tx = await program.methods
      .initializePool(
        new anchor.BN(initialTngAmount),
        new anchor.BN(initialSolAmount)
      )
      .accounts({
        authority: sponsorKeypair.publicKey,
        payer: sponsorKeypair.publicKey,
        swapPool: swapPoolPda,
        tngMint: TNG_MINT,
        otherMint: SOL_MINT,
        tngVault: tngVault,
        otherVault: solVault,
        lpMint: lpMintKeypair.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      })
      .signers([sponsorKeypair, lpMintKeypair])
      .rpc();

    console.log(" Swap pool initialized!");
    console.log(" Transaction signature:", tx);
    console.log(" Explorer:", `https://explorer.solana.com/tx/${tx}?cluster=devnet`);

    // Save deployment info
    const deploymentInfo = {
      network: "devnet",
      programId: program.programId.toString(),
      swapPool: swapPoolPda.toString(),
      tngVault: tngVault.toString(),
      solVault: solVault.toString(),
      lpMint: lpMintKeypair.publicKey.toString(),
      bump: bump,
      timestamp: new Date().toISOString(),
      txSignature: tx
    };

    fs.writeFileSync('./deployment-info.json', JSON.stringify(deploymentInfo, null, 2));
    console.log(" Deployment info saved to deployment-info.json");

  } catch (error) {
    console.error(" Error initializing swap pool:", error);
    throw error;
  }
}

initialize()
  .then(() => {
    console.log(" TNG Swap initialization completed!");
    process.exit(0);
  })
  .catch((error) => {
    console.error(" Initialization failed:", error);
    process.exit(1);
  });