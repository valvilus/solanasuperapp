/**
 * TNG Swap - Automated Market Maker for TNG Token
 * Supports: TNG  SOL, TNG  USDC
 * Solana SuperApp
 */

use anchor_lang::prelude::*;
use anchor_spl::{
    associated_token::AssociatedToken,
    token::{self, Mint, Token, TokenAccount, Transfer},
};

declare_id!("FWfcH4Zcp8HztJFqui3wX3AkG9XjV9PoKnNPCgsctSVV");

#[program]
pub mod tng_swap {
    use super::*;

    /// Initialize the swap pool
    pub fn initialize_pool(
        ctx: Context<InitializePool>,
        tng_reserve: u64,
        other_reserve: u64,
    ) -> Result<()> {
        msg!("Initializing TNG swap pool");
        
        let pool = &mut ctx.accounts.swap_pool;
        pool.authority = ctx.accounts.authority.key();
        pool.tng_mint = ctx.accounts.tng_mint.key();
        pool.other_mint = ctx.accounts.other_mint.key();
        pool.tng_vault = ctx.accounts.tng_vault.key();
        pool.other_vault = ctx.accounts.other_vault.key();
        pool.tng_reserve = tng_reserve;
        pool.other_reserve = other_reserve;
        pool.lp_mint = ctx.accounts.lp_mint.key();
        pool.bump = ctx.bumps.swap_pool;
        pool.is_active = true;

        msg!("Pool initialized successfully");
        msg!("TNG Reserve: {}", tng_reserve);
        msg!("Other Reserve: {}", other_reserve);
        msg!("Pool Authority: {}", pool.authority);

        Ok(())
    }

    /// Swap TNG for other token (SOL or USDC)
    pub fn swap_tng_for_other(
        ctx: Context<SwapTngForOther>,
        tng_amount: u64,
        other_amount_out: u64, // Точная сумма, не minimum
    ) -> Result<()> {
        let pool = &mut ctx.accounts.swap_pool;
        
        msg!("Swapping TNG for other token");
        msg!("TNG Amount: {}", tng_amount);
        msg!("Other Amount Out: {}", other_amount_out);
        msg!("User: {}", ctx.accounts.user.key());
        msg!("Payer: {}", ctx.accounts.payer.key());

        // ПРЯМОЙ ОБМЕН - используем переданную точную сумму (рассчитанную по реальным курсам)
        
        msg!("Direct swap calculation (no AMM overflow):");
        msg!("TNG input: {}", tng_amount);
        msg!("Other output: {}", other_amount_out);

        // Проверяем что в пуле достаточно токенов для вывода
        require!(
            pool.other_reserve >= other_amount_out,
            ErrorCode::InsufficientLiquidity
        );

        // Transfer TNG from user to pool vault
        let transfer_tng_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.user_tng_account.to_account_info(),
                to: ctx.accounts.tng_vault.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        token::transfer(transfer_tng_ctx, tng_amount)?;

        // Transfer other token from pool vault to user
        let seeds = &[
            b"swap_pool",
            pool.tng_mint.as_ref(),
            pool.other_mint.as_ref(),
            &[pool.bump],
        ];
        let signer = &[&seeds[..]];

        let transfer_other_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.other_vault.to_account_info(),
                to: ctx.accounts.user_other_account.to_account_info(),
                authority: pool.to_account_info(),
            },
            signer,
        );
        token::transfer(transfer_other_ctx, other_amount_out)?;

        // Update pool reserves (прямое обновление)
        pool.tng_reserve = pool.tng_reserve.checked_add(tng_amount)
            .ok_or(ErrorCode::MathOverflow)?;
        pool.other_reserve = pool.other_reserve.checked_sub(other_amount_out)
            .ok_or(ErrorCode::InsufficientLiquidity)?;

        msg!("Swap completed successfully");
        msg!("TNG In: {}", tng_amount);
        msg!("Other Out: {}", other_amount_out);
        msg!("New TNG Reserve: {}", pool.tng_reserve);
        msg!("New Other Reserve: {}", pool.other_reserve);

        Ok(())
    }

    /// Swap other token (SOL or USDC) for TNG
    pub fn swap_other_for_tng(
        ctx: Context<SwapOtherForTng>,
        other_amount: u64,
        tng_amount_out: u64, // Точная сумма, не minimum
    ) -> Result<()> {
        let pool = &mut ctx.accounts.swap_pool;
        
        msg!("Swapping other token for TNG");
        msg!("Other Amount: {}", other_amount);
        msg!("TNG Amount Out: {}", tng_amount_out);
        msg!("User: {}", ctx.accounts.user.key());
        msg!("Payer: {}", ctx.accounts.payer.key());

        // ПРЯМОЙ ОБМЕН - используем переданную точную сумму (рассчитанную по реальным курсам)
        
        msg!("Direct swap calculation (no AMM overflow):");
        msg!("Other input: {}", other_amount);
        msg!("TNG output: {}", tng_amount_out);

        // Проверяем что в пуле достаточно TNG для вывода
        require!(
            pool.tng_reserve >= tng_amount_out,
            ErrorCode::InsufficientLiquidity
        );

        // Transfer other token from user to pool vault
        let transfer_other_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.user_other_account.to_account_info(),
                to: ctx.accounts.other_vault.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        token::transfer(transfer_other_ctx, other_amount)?;

        // Transfer TNG from pool vault to user
        let seeds = &[
            b"swap_pool",
            pool.tng_mint.as_ref(),
            pool.other_mint.as_ref(),
            &[pool.bump],
        ];
        let signer = &[&seeds[..]];

        let transfer_tng_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.tng_vault.to_account_info(),
                to: ctx.accounts.user_tng_account.to_account_info(),
                authority: pool.to_account_info(),
            },
            signer,
        );
        token::transfer(transfer_tng_ctx, tng_amount_out)?;

        // Update pool reserves (прямое обновление)
        pool.tng_reserve = pool.tng_reserve.checked_sub(tng_amount_out)
            .ok_or(ErrorCode::InsufficientLiquidity)?;
        pool.other_reserve = pool.other_reserve.checked_add(other_amount)
            .ok_or(ErrorCode::MathOverflow)?;

        msg!("Swap completed successfully");
        msg!("Other In: {}", other_amount);
        msg!("TNG Out: {}", tng_amount_out);
        msg!("New TNG Reserve: {}", pool.tng_reserve);
        msg!("New Other Reserve: {}", pool.other_reserve);

        Ok(())
    }

    /// Add liquidity to the pool
    pub fn add_liquidity(
        ctx: Context<AddLiquidity>,
        tng_amount: u64,
        other_amount: u64,
        minimum_lp_tokens: u64,
    ) -> Result<()> {
        let pool = &mut ctx.accounts.swap_pool;
        
        msg!("Adding liquidity to pool");
        msg!("TNG Amount: {}", tng_amount);
        msg!("Other Amount: {}", other_amount);
        msg!("User: {}", ctx.accounts.user.key());

        // Calculate LP tokens to mint (proportional to pool share)
        let lp_tokens = if pool.tng_reserve == 0 {
            // Initial liquidity
            (tng_amount.checked_mul(other_amount))
                .ok_or(ErrorCode::MathOverflow)?
                .checked_sub(1000) // Minimum liquidity lock
                .ok_or(ErrorCode::MathOverflow)?
        } else {
            // Subsequent liquidity
            let tng_ratio = tng_amount.checked_mul(1_000_000)
                .ok_or(ErrorCode::MathOverflow)?
                .checked_div(pool.tng_reserve)
                .ok_or(ErrorCode::MathOverflow)?;
                
            let other_ratio = other_amount.checked_mul(1_000_000)
                .ok_or(ErrorCode::MathOverflow)?
                .checked_div(pool.other_reserve)
                .ok_or(ErrorCode::MathOverflow)?;
                
            // Use the smaller ratio to ensure balanced liquidity
            let ratio = tng_ratio.min(other_ratio);
            
            // Get current LP supply (simplified)
            ratio.checked_mul(pool.tng_reserve.checked_add(pool.other_reserve).unwrap_or(0))
                .ok_or(ErrorCode::MathOverflow)?
                .checked_div(1_000_000)
                .ok_or(ErrorCode::MathOverflow)?
        };

        require!(
            lp_tokens >= minimum_lp_tokens,
            ErrorCode::SlippageExceeded
        );

        // Transfer tokens from user to pool vaults
        let transfer_tng_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.user_tng_account.to_account_info(),
                to: ctx.accounts.tng_vault.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        token::transfer(transfer_tng_ctx, tng_amount)?;

        let transfer_other_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.user_other_account.to_account_info(),
                to: ctx.accounts.other_vault.to_account_info(),
                authority: ctx.accounts.user.to_account_info(),
            },
        );
        token::transfer(transfer_other_ctx, other_amount)?;

        // Update pool reserves
        pool.tng_reserve = pool.tng_reserve.checked_add(tng_amount)
            .ok_or(ErrorCode::MathOverflow)?;
        pool.other_reserve = pool.other_reserve.checked_add(other_amount)
            .ok_or(ErrorCode::MathOverflow)?;

        msg!("Liquidity added successfully");
        msg!("LP Tokens: {}", lp_tokens);
        msg!("New TNG Reserve: {}", pool.tng_reserve);
        msg!("New Other Reserve: {}", pool.other_reserve);

        Ok(())
    }

    /// Multi-hop swap through multiple pools for better prices
    pub fn multi_hop_swap(
        _ctx: Context<MultiHopSwap>,
        route: Vec<SwapRoute>,
        amount_in: u64,
        minimum_amount_out: u64,
    ) -> Result<()> {
        msg!("Executing multi-hop swap with {} hops", route.len());
        msg!("Input amount: {}, Minimum output: {}", amount_in, minimum_amount_out);
        
        require!(route.len() > 0, ErrorCode::InvalidRoute);
        require!(route.len() <= 3, ErrorCode::TooManyHops);
        
        let mut current_amount = amount_in;
        
        // Execute swaps through each hop in the route
        for (i, swap_route) in route.iter().enumerate() {
            msg!("Processing hop {}: {} -> {}", i + 1, swap_route.input_mint, swap_route.output_mint);
            
            // Simplified calculation for demo - in production would call actual pools
            let output_amount = current_amount * 99 / 100; // Assume 1% fee per hop
            current_amount = output_amount;
        }
        
        // Check if final output meets minimum requirement
        require!(
            current_amount >= minimum_amount_out,
            ErrorCode::InsufficientOutput
        );
        
        msg!("Multi-hop swap completed. Final output: {}", current_amount);
        Ok(())
    }

    /// Register external pool for liquidity aggregation
    pub fn register_external_pool(
        ctx: Context<RegisterExternalPool>,
        pool_address: Pubkey,
        pool_type: PoolType,
        token_a: Pubkey,
        token_b: Pubkey,
        fee_tier: u64,
    ) -> Result<()> {
        msg!("Registering external pool: {}", pool_address);
        
        let pool_registry = &mut ctx.accounts.pool_registry;
        let external_pool = ExternalPool {
            pool_address,
            pool_type,
            token_a,
            token_b,
            fee_tier,
            is_active: true,
            total_volume: 0,
            registered_at: Clock::get()?.unix_timestamp,
        };
        
        pool_registry.pools.push(external_pool);
        pool_registry.total_pools += 1;
        
        msg!("External pool registered successfully. Total pools: {}", pool_registry.total_pools);
        Ok(())
    }

}

// ============================================================================
// Account Contexts
// ============================================================================

#[derive(Accounts)]
pub struct MultiHopSwap<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(mut)]
    pub payer: Signer<'info>,

    pub pool_registry: Account<'info, PoolRegistry>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct RegisterExternalPool<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,

    #[account(mut)]
    pub payer: Signer<'info>,

    #[account(
        mut,
        seeds = [b"pool_registry"],
        bump = pool_registry.bump
    )]
    pub pool_registry: Account<'info, PoolRegistry>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct InitializePool<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,

    #[account(mut)]
    pub payer: Signer<'info>, // payer = sponsor

    #[account(
        init,
        payer = payer, // payer = sponsor
        space = 8 + 32 + 32 + 32 + 32 + 32 + 32 + 8 + 8 + 1 + 1, // SwapPool size
        seeds = [b"swap_pool", tng_mint.key().as_ref(), other_mint.key().as_ref()],
        bump
    )]
    pub swap_pool: Account<'info, SwapPool>,

    pub tng_mint: Account<'info, Mint>,
    pub other_mint: Account<'info, Mint>,

    #[account(
        init,
        payer = payer, // payer = sponsor
        associated_token::mint = tng_mint,
        associated_token::authority = swap_pool,
    )]
    pub tng_vault: Account<'info, TokenAccount>,

    #[account(
        init,
        payer = payer, // payer = sponsor
        associated_token::mint = other_mint,
        associated_token::authority = swap_pool,
    )]
    pub other_vault: Account<'info, TokenAccount>,

    #[account(
        init,
        payer = payer, // payer = sponsor
        mint::decimals = 9,
        mint::authority = swap_pool,
    )]
    pub lp_mint: Account<'info, Mint>,
    
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct SwapTngForOther<'info> {
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(mut)]
    pub payer: Signer<'info>, // payer = sponsor

    #[account(
        mut,
        seeds = [b"swap_pool", swap_pool.tng_mint.as_ref(), swap_pool.other_mint.as_ref()],
        bump = swap_pool.bump,
        constraint = swap_pool.is_active @ ErrorCode::PoolInactive
    )]
    pub swap_pool: Account<'info, SwapPool>,

    #[account(
        mut,
        associated_token::mint = swap_pool.tng_mint,
        associated_token::authority = user,
    )]
    pub user_tng_account: Account<'info, TokenAccount>,
    
    #[account(
        init_if_needed,
        payer = payer, // payer = sponsor
        associated_token::mint = other_mint,
        associated_token::authority = user,
    )]
    pub user_other_account: Account<'info, TokenAccount>,

    #[account(address = swap_pool.other_mint)]
    pub other_mint: Account<'info, Mint>,

    #[account(
        mut,
        address = swap_pool.tng_vault
    )]
    pub tng_vault: Account<'info, TokenAccount>,
    
    #[account(
        mut,
        address = swap_pool.other_vault
    )]
    pub other_vault: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct SwapOtherForTng<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(mut)]
    pub payer: Signer<'info>, // payer = sponsor

    #[account(
        mut,
        seeds = [b"swap_pool", swap_pool.tng_mint.as_ref(), swap_pool.other_mint.as_ref()],
        bump = swap_pool.bump,
        constraint = swap_pool.is_active @ ErrorCode::PoolInactive
    )]
    pub swap_pool: Account<'info, SwapPool>,
    
    #[account(
        init_if_needed,
        payer = payer, // payer = sponsor
        associated_token::mint = tng_mint,
        associated_token::authority = user,
    )]
    pub user_tng_account: Account<'info, TokenAccount>,

    #[account(address = swap_pool.tng_mint)]
    pub tng_mint: Account<'info, Mint>,

    #[account(
        mut,
        associated_token::mint = swap_pool.other_mint,
        associated_token::authority = user,
    )]
    pub user_other_account: Account<'info, TokenAccount>,
    
    #[account(
        mut,
        address = swap_pool.tng_vault
    )]
    pub tng_vault: Account<'info, TokenAccount>,
    
    #[account(
        mut,
        address = swap_pool.other_vault
    )]
    pub other_vault: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct AddLiquidity<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(mut)]
    pub payer: Signer<'info>, // payer = sponsor
    
    #[account(
        mut,
        seeds = [b"swap_pool", swap_pool.tng_mint.as_ref(), swap_pool.other_mint.as_ref()],
        bump = swap_pool.bump,
        constraint = swap_pool.is_active @ ErrorCode::PoolInactive
    )]
    pub swap_pool: Account<'info, SwapPool>,

    #[account(
        mut,
        associated_token::mint = tng_mint,
        associated_token::authority = user,
    )]
    pub user_tng_account: Account<'info, TokenAccount>,
    
    #[account(
        mut,
        associated_token::mint = other_mint,
        associated_token::authority = user,
    )]
    pub user_other_account: Account<'info, TokenAccount>,

    #[account(address = swap_pool.tng_mint)]
    pub tng_mint: Account<'info, Mint>,
    
    #[account(address = swap_pool.other_mint)]
    pub other_mint: Account<'info, Mint>,

    #[account(
        init_if_needed,
        payer = payer, // payer = sponsor
        associated_token::mint = lp_mint,
        associated_token::authority = user,
    )]
    pub user_lp_account: Account<'info, TokenAccount>,

    #[account(address = swap_pool.lp_mint)]
    pub lp_mint: Account<'info, Mint>,

    #[account(
        mut,
        address = swap_pool.tng_vault
    )]
    pub tng_vault: Account<'info, TokenAccount>,
    
    #[account(
        mut,
        address = swap_pool.other_vault
    )]
    pub other_vault: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

// ============================================================================
// Account Structs
// ============================================================================

#[account]
pub struct SwapPool {
    pub authority: Pubkey,        // Pool authority
    pub tng_mint: Pubkey,         // TNG token mint
    pub other_mint: Pubkey,       // Other token mint (SOL or USDC)
    pub tng_vault: Pubkey,        // TNG token vault
    pub other_vault: Pubkey,      // Other token vault
    pub lp_mint: Pubkey,          // LP token mint
    pub tng_reserve: u64,         // TNG reserve amount
    pub other_reserve: u64,       // Other token reserve amount
    pub bump: u8,                 // PDA bump seed
    pub is_active: bool,          // Pool status
}

#[account]
pub struct PoolRegistry {
    pub authority: Pubkey,
    pub pools: Vec<ExternalPool>,
    pub total_pools: u64,
    pub bump: u8,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct ExternalPool {
    pub pool_address: Pubkey,
    pub pool_type: PoolType,
    pub token_a: Pubkey,
    pub token_b: Pubkey,
    pub fee_tier: u64,
    pub is_active: bool,
    pub total_volume: u64,
    pub registered_at: i64,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct SwapRoute {
    pub pool_address: Pubkey,
    pub input_mint: Pubkey,
    pub output_mint: Pubkey,
    pub fee_tier: u64,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub enum PoolType {
    Raydium,
    Orca,
    Serum,
    Jupiter,
    Internal,
}

// ============================================================================
// Helper Functions
// ============================================================================

/// Calculate swap output amount with fees
fn calculate_swap_output(amount_in: u64, fee_tier: u64) -> Result<u64> {
    // Simple calculation - in production would use actual AMM formulas
    // Apply fee (fee_tier is in basis points)
    let fee_amount = (amount_in as u128 * fee_tier as u128) / 10000u128;
    let amount_after_fee = amount_in.checked_sub(fee_amount as u64).ok_or(ErrorCode::InsufficientLiquidity)?;
    
    // Simplified output calculation (would use x*y=k formula in production)
    let output = (amount_after_fee as u128 * 98) / 100; // Assume ~2% slippage
    Ok(output as u64)
}

// ============================================================================
// Additional Contexts
// ============================================================================


// ============================================================================
// Error Codes
// ============================================================================

#[error_code]
pub enum ErrorCode {
    #[msg("Mathematical overflow occurred")]
    MathOverflow,
    #[msg("Insufficient liquidity in pool")]
    InsufficientLiquidity,
    #[msg("Slippage tolerance exceeded")]
    SlippageExceeded,
    #[msg("Pool is not active")]
    PoolInactive,
    #[msg("Invalid token mint")]
    InvalidTokenMint,
    #[msg("Insufficient user balance")]
    InsufficientBalance,
    #[msg("Invalid swap route")]
    InvalidRoute,
    #[msg("Too many hops in route")]
    TooManyHops,
    #[msg("Insufficient output amount")]
    InsufficientOutput,
}