import { PublicKey, Keypair, Connection, clusterApiUrl, sendAndConfirmTransaction } from "@solana/web3.js";
import { TngLearnContractService, CreateCourseParams, SubmitAnswerParams } from "./contract-service";
import fs from 'fs';
import path from 'path';

/**
 * Скрипт для выполнения операций с курсами через TNG Learn смарт-контракт
 */

// Конфигурация
const RPC_URL = process.env.SOLANA_RPC_URL || clusterApiUrl("devnet");
const TNG_MINT = new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs");

/**
 * Загрузить keypair из файла
 */
function loadKeypair(keypairPath: string): Keypair {
  try {
    const keypairData = JSON.parse(fs.readFileSync(keypairPath, 'utf8'));
    return Keypair.fromSecretKey(new Uint8Array(keypairData));
  } catch (error) {
    console.error(` Error loading keypair from ${keypairPath}:`, error);
    throw error;
  }
}

/**
 * Создать курс
 */
export async function createCourse(
  creatorKeypairPath: string,
  courseParams: CreateCourseParams
): Promise<string> {
  console.log(" Creating new course...");
  console.log(" Course params:", courseParams);

  const connection = new Connection(RPC_URL, "confirmed");
  const creatorKeypair = loadKeypair(creatorKeypairPath);
  const learnService = new TngLearnContractService(connection, TNG_MINT);

  console.log(" Creator:", creatorKeypair.publicKey.toString());

  try {
    // Проверяем, что платформа инициализирована
    const isInitialized = await learnService.isLearnPlatformInitialized();
    if (!isInitialized) {
      throw new Error("Learn platform is not initialized");
    }

    // Проверяем, что курс с таким ID не существует
    const existingCourse = await learnService.getCourse(courseParams.courseId);
    if (existingCourse) {
      throw new Error(`Course with ID ${courseParams.courseId} already exists`);
    }

    // Создаем транзакцию
    const transaction = await learnService.buildCreateCourseTransaction(
      creatorKeypair.publicKey,
      creatorKeypair.publicKey,
      courseParams
    );

    // Подписываем и отправляем
    const signature = await sendAndConfirmTransaction(
      connection,
      transaction,
      [creatorKeypair],
      { commitment: "confirmed" }
    );

    console.log(" Course created successfully!");
    console.log(" Transaction signature:", signature);
    console.log(" Explorer:", `https://explorer.solana.com/tx/${signature}?cluster=devnet`);

    // Проверяем, что курс действительно создан
    const course = await learnService.getCourse(courseParams.courseId);
    if (course) {
      console.log(" Course details:");
      console.log("- ID:", course.courseId);
      console.log("- Title:", course.title);
      console.log("- Description:", course.description);
      console.log("- Reward:", learnService.formatTNGAmount(course.rewardAmount));
      console.log("- Creator:", course.creator.toString());
      console.log("- Active:", course.isActive);
    }

    return signature;

  } catch (error) {
    console.error(" Error creating course:", error);
    throw error;
  }
}

/**
 * Отправить ответ на курс (завершить курс)
 */
export async function submitAnswer(
  userKeypairPath: string,
  submitParams: SubmitAnswerParams
): Promise<string> {
  console.log(" Submitting answer...");
  console.log(" Submit params:", submitParams);

  const connection = new Connection(RPC_URL, "confirmed");
  const userKeypair = loadKeypair(userKeypairPath);
  const learnService = new TngLearnContractService(connection, TNG_MINT);

  console.log(" User:", userKeypair.publicKey.toString());

  try {
    // Проверяем, что курс существует
    const course = await learnService.getCourse(submitParams.courseId);
    if (!course) {
      throw new Error(`Course with ID ${submitParams.courseId} not found`);
    }

    // Проверяем, не завершен ли уже курс пользователем
    const existingUserCourse = await learnService.getUserCourse(
      userKeypair.publicKey,
      submitParams.courseId
    );
    
    if (existingUserCourse && existingUserCourse.isCompleted) {
      throw new Error("Course already completed by this user");
    }

    // Создаем транзакцию
    const transaction = await learnService.buildSubmitAnswerTransaction(
      userKeypair.publicKey,
      userKeypair.publicKey,
      submitParams
    );

    // Подписываем и отправляем
    const signature = await sendAndConfirmTransaction(
      connection,
      transaction,
      [userKeypair],
      { commitment: "confirmed" }
    );

    console.log(" Answer submitted successfully!");
    console.log(" Transaction signature:", signature);
    console.log(" Explorer:", `https://explorer.solana.com/tx/${signature}?cluster=devnet`);

    // Проверяем результат
    const userCourse = await learnService.getUserCourse(
      userKeypair.publicKey,
      submitParams.courseId
    );
    
    if (userCourse) {
      console.log(" User course status:");
      console.log("- Course ID:", userCourse.courseId);
      console.log("- Completed:", userCourse.isCompleted);
      console.log("- Reward claimed:", userCourse.isRewardClaimed);
      console.log("- Answer hash:", userCourse.answerHash);
    }

    return signature;

  } catch (error) {
    console.error(" Error submitting answer:", error);
    throw error;
  }
}

/**
 * Получить награду за завершенный курс
 */
export async function claimReward(
  userKeypairPath: string,
  courseId: number
): Promise<string> {
  console.log(" Claiming reward...");
  console.log(" Course ID:", courseId);

  const connection = new Connection(RPC_URL, "confirmed");
  const userKeypair = loadKeypair(userKeypairPath);
  const learnService = new TngLearnContractService(connection, TNG_MINT);

  console.log(" User:", userKeypair.publicKey.toString());

  try {
    // Проверяем, что курс завершен пользователем
    const userCourse = await learnService.getUserCourse(
      userKeypair.publicKey,
      courseId
    );
    
    if (!userCourse || !userCourse.isCompleted) {
      throw new Error("Course not completed by this user");
    }

    if (userCourse.isRewardClaimed) {
      throw new Error("Reward already claimed");
    }

    // Получаем информацию о курсе для показа размера награды
    const course = await learnService.getCourse(courseId);
    if (!course) {
      throw new Error(`Course with ID ${courseId} not found`);
    }

    console.log(" Reward amount:", learnService.formatTNGAmount(course.rewardAmount));

    // Создаем транзакцию
    const transaction = await learnService.buildClaimRewardTransaction(
      userKeypair.publicKey,
      userKeypair.publicKey,
      courseId
    );

    // Подписываем и отправляем
    const signature = await sendAndConfirmTransaction(
      connection,
      transaction,
      [userKeypair],
      { commitment: "confirmed" }
    );

    console.log(" Reward claimed successfully!");
    console.log(" Transaction signature:", signature);
    console.log(" Explorer:", `https://explorer.solana.com/tx/${signature}?cluster=devnet`);

    // Проверяем результат
    const updatedUserCourse = await learnService.getUserCourse(
      userKeypair.publicKey,
      courseId
    );
    
    if (updatedUserCourse) {
      console.log(" Updated user course status:");
      console.log("- Course ID:", updatedUserCourse.courseId);
      console.log("- Completed:", updatedUserCourse.isCompleted);
      console.log("- Reward claimed:", updatedUserCourse.isRewardClaimed);
    }

    return signature;

  } catch (error) {
    console.error(" Error claiming reward:", error);
    throw error;
  }
}

/**
 * CLI функция для выполнения операций
 */
async function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.log(" TNG Learn Course Operations");
    console.log("");
    console.log("Usage:");
    console.log("  npm run course:create <keypair-path> <course-id> <title> <description> <reward-amount>");
    console.log("  npm run course:submit <keypair-path> <course-id> <answer-hash>");
    console.log("  npm run course:claim <keypair-path> <course-id>");
    console.log("");
    console.log("Examples:");
    console.log("  npm run course:create ./keys/sponsor.json 1 'Solana Basics' 'Learn Solana fundamentals' 1000000000");
    console.log("  npm run course:submit ./keys/user.json 1 'answer123'");
    console.log("  npm run course:claim ./keys/user.json 1");
    return;
  }

  const operation = args[0];

  try {
    switch (operation) {
      case "create":
        if (args.length < 6) {
          throw new Error("Missing arguments for create operation");
        }
        const [, keypairPath, courseIdStr, title, description, rewardAmountStr] = args;
        await createCourse(keypairPath, {
          courseId: parseInt(courseIdStr),
          title,
          description,
          rewardAmount: parseInt(rewardAmountStr)
        });
        break;

      case "submit":
        if (args.length < 4) {
          throw new Error("Missing arguments for submit operation");
        }
        const [, submitKeypairPath, submitCourseIdStr, answerHash] = args;
        await submitAnswer(submitKeypairPath, {
          courseId: parseInt(submitCourseIdStr),
          answerHash
        });
        break;

      case "claim":
        if (args.length < 3) {
          throw new Error("Missing arguments for claim operation");
        }
        const [, claimKeypairPath, claimCourseIdStr] = args;
        await claimReward(claimKeypairPath, parseInt(claimCourseIdStr));
        break;

      default:
        throw new Error(`Unknown operation: ${operation}`);
    }
  } catch (error) {
    console.error(" Operation failed:", error);
    process.exit(1);
  }
}

// Запускаем только если скрипт вызван напрямую
if (require.main === module) {
  main().catch(console.error);
}






