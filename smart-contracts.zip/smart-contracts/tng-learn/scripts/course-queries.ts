import { PublicKey, Connection, clusterApiUrl } from "@solana/web3.js";
import { TngLearnContractService } from "./contract-service";
import fs from 'fs';

/**
 * Скрипт для запросов данных из TNG Learn смарт-контракта
 */

// Конфигурация
const RPC_URL = process.env.SOLANA_RPC_URL || clusterApiUrl("devnet");
const TNG_MINT = new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs");

/**
 * Получить конфигурацию Learn платформы
 */
export async function getLearnConfig(): Promise<void> {
  console.log(" Getting Learn platform configuration...");

  const connection = new Connection(RPC_URL, "confirmed");
  const learnService = new TngLearnContractService(connection, TNG_MINT);

  try {
    const config = await learnService.getLearnConfig();
    
    if (!config) {
      console.log(" Learn platform is not initialized");
      return;
    }

    console.log(" Learn platform configuration:");
    console.log("- Admin:", config.admin.toString());
    console.log("- Total courses:", config.totalCourses);
    console.log("- Total rewards distributed:", learnService.formatTNGAmount(config.totalRewardsDistributed));
    console.log("- Is active:", config.isActive);

  } catch (error) {
    console.error(" Error getting config:", error);
    throw error;
  }
}

/**
 * Получить все курсы
 */
export async function getAllCourses(): Promise<void> {
  console.log(" Getting all courses...");

  const connection = new Connection(RPC_URL, "confirmed");
  const learnService = new TngLearnContractService(connection, TNG_MINT);

  try {
    const courses = await learnService.getAllCourses();
    
    if (courses.length === 0) {
      console.log(" No courses found");
      return;
    }

    console.log(` Found ${courses.length} course(s):`);
    console.log("");

    for (const course of courses) {
      console.log(` Course #${course.courseId}:`);
      console.log("- Title:", course.title);
      console.log("- Description:", course.description);
      console.log("- Creator:", course.creator.toString());
      console.log("- Reward:", learnService.formatTNGAmount(course.rewardAmount));
      console.log("- Active:", course.isActive);
      console.log("- Created at:", new Date(course.createdAt * 1000).toISOString());
      
      // Получаем баланс хранилища
      const vaultBalance = await learnService.getCourseVaultBalance(course.courseId);
      console.log("- Vault balance:", learnService.formatTNGAmount(vaultBalance));
      console.log("");
    }

  } catch (error) {
    console.error(" Error getting courses:", error);
    throw error;
  }
}

/**
 * Получить информацию о конкретном курсе
 */
export async function getCourseInfo(courseId: number): Promise<void> {
  console.log(` Getting course #${courseId} information...`);

  const connection = new Connection(RPC_URL, "confirmed");
  const learnService = new TngLearnContractService(connection, TNG_MINT);

  try {
    const course = await learnService.getCourse(courseId);
    
    if (!course) {
      console.log(` Course #${courseId} not found`);
      return;
    }

    console.log(` Course #${courseId} details:`);
    console.log("- Title:", course.title);
    console.log("- Description:", course.description);
    console.log("- Creator:", course.creator.toString());
    console.log("- Reward:", learnService.formatTNGAmount(course.rewardAmount));
    console.log("- Active:", course.isActive);
    console.log("- Created at:", new Date(course.createdAt * 1000).toISOString());

    // Получаем баланс хранилища
    const vaultBalance = await learnService.getCourseVaultBalance(courseId);
    console.log("- Vault balance:", learnService.formatTNGAmount(vaultBalance));

    // Получаем PDA адреса
    const [coursePda] = learnService.getCoursePda(courseId);
    const vaultPda = await learnService.getCourseVaultPda(courseId);
    
    console.log("");
    console.log(" On-chain addresses:");
    console.log("- Course PDA:", coursePda.toString());
    console.log("- Vault PDA:", vaultPda.toString());

  } catch (error) {
    console.error(` Error getting course #${courseId}:`, error);
    throw error;
  }
}

/**
 * Получить прогресс пользователя
 */
export async function getUserProgress(userPublicKey: string): Promise<void> {
  console.log(` Getting user progress for: ${userPublicKey}`);

  const connection = new Connection(RPC_URL, "confirmed");
  const learnService = new TngLearnContractService(connection, TNG_MINT);

  try {
    const userPubkey = new PublicKey(userPublicKey);
    const progress = await learnService.getUserProgress(userPubkey);

    console.log(" User progress:");
    console.log("- Completed courses:", progress.completedCourses);
    console.log("- Total rewards claimed:", progress.totalRewardsClaimed);
    console.log("- User courses:", progress.userCourses.length);

    if (progress.userCourses.length > 0) {
      console.log("");
      console.log(" Course details:");
      
      for (const userCourse of progress.userCourses) {
        console.log(`- Course #${userCourse.courseId}:`);
        console.log("  - Completed:", userCourse.isCompleted);
        console.log("  - Reward claimed:", userCourse.isRewardClaimed);
        console.log("  - Answer hash:", userCourse.answerHash);
        
        if (userCourse.completedAt > 0) {
          console.log("  - Completed at:", new Date(userCourse.completedAt * 1000).toISOString());
        }
        
        // Получаем PDA для пользовательского курса
        const [userCoursePda] = learnService.getUserCoursePda(userPubkey, userCourse.courseId);
        console.log("  - PDA:", userCoursePda.toString());
        console.log("");
      }
    }

  } catch (error) {
    console.error(" Error getting user progress:", error);
    throw error;
  }
}

/**
 * Получить прогресс пользователя по конкретному курсу
 */
export async function getUserCourseProgress(
  userPublicKey: string, 
  courseId: number
): Promise<void> {
  console.log(` Getting user progress for course #${courseId}: ${userPublicKey}`);

  const connection = new Connection(RPC_URL, "confirmed");
  const learnService = new TngLearnContractService(connection, TNG_MINT);

  try {
    const userPubkey = new PublicKey(userPublicKey);
    const userCourse = await learnService.getUserCourse(userPubkey, courseId);

    if (!userCourse) {
      console.log(` User has not started course #${courseId}`);
      return;
    }

    console.log(` User progress for course #${courseId}:`);
    console.log("- Completed:", userCourse.isCompleted);
    console.log("- Reward claimed:", userCourse.isRewardClaimed);
    console.log("- Answer hash:", userCourse.answerHash);
    
    if (userCourse.completedAt > 0) {
      console.log("- Completed at:", new Date(userCourse.completedAt * 1000).toISOString());
    }

    // Получаем PDA
    const [userCoursePda] = learnService.getUserCoursePda(userPubkey, courseId);
    console.log("- PDA:", userCoursePda.toString());

    // Если курс завершен, но награда не получена, показываем информацию о награде
    if (userCourse.isCompleted && !userCourse.isRewardClaimed) {
      const course = await learnService.getCourse(courseId);
      if (course) {
        console.log(" Available reward:", learnService.formatTNGAmount(course.rewardAmount));
      }
    }

  } catch (error) {
    console.error(" Error getting user course progress:", error);
    throw error;
  }
}

/**
 * Экспортировать все данные платформы в JSON
 */
export async function exportPlatformData(outputFile?: string): Promise<void> {
  console.log(" Exporting platform data...");

  const connection = new Connection(RPC_URL, "confirmed");
  const learnService = new TngLearnContractService(connection, TNG_MINT);

  try {
    // Получаем конфигурацию
    const config = await learnService.getLearnConfig();
    
    // Получаем все курсы
    const courses = await learnService.getAllCourses();

    // Получаем балансы хранилищ
    const coursesWithVaults = await Promise.all(
      courses.map(async (course) => {
        const vaultBalance = await learnService.getCourseVaultBalance(course.courseId);
        return {
          ...course,
          creator: course.creator.toString(),
          vaultBalance,
          vaultBalanceFormatted: learnService.formatTNGAmount(vaultBalance)
        };
      })
    );

    const exportData = {
      exportedAt: new Date().toISOString(),
      network: "devnet",
      programId: learnService.programId.toString(),
      tngMint: TNG_MINT.toString(),
      config: config ? {
        ...config,
        admin: config.admin.toString(),
        totalRewardsDistributedFormatted: learnService.formatTNGAmount(config.totalRewardsDistributed)
      } : null,
      courses: coursesWithVaults,
      totalCourses: courses.length,
      totalVaultBalance: coursesWithVaults.reduce((sum, course) => sum + course.vaultBalance, 0)
    };

    const filename = outputFile || `learn-platform-export-${Date.now()}.json`;
    fs.writeFileSync(filename, JSON.stringify(exportData, null, 2));

    console.log(" Platform data exported successfully!");
    console.log(" File:", filename);
    console.log(" Summary:");
    console.log("- Total courses:", exportData.totalCourses);
    console.log("- Total vault balance:", learnService.formatTNGAmount(exportData.totalVaultBalance));
    console.log("- Platform admin:", exportData.config?.admin || "N/A");

  } catch (error) {
    console.error(" Error exporting platform data:", error);
    throw error;
  }
}

/**
 * CLI функция для выполнения запросов
 */
async function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.log(" TNG Learn Data Queries");
    console.log("");
    console.log("Usage:");
    console.log("  npm run query:config");
    console.log("  npm run query:courses");
    console.log("  npm run query:course <course-id>");
    console.log("  npm run query:user <user-public-key>");
    console.log("  npm run query:user-course <user-public-key> <course-id>");
    console.log("  npm run query:export [output-file]");
    console.log("");
    console.log("Examples:");
    console.log("  npm run query:config");
    console.log("  npm run query:courses");
    console.log("  npm run query:course 1");
    console.log("  npm run query:user 9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM");
    console.log("  npm run query:user-course 9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM 1");
    console.log("  npm run query:export platform-data.json");
    return;
  }

  const operation = args[0];

  try {
    switch (operation) {
      case "config":
        await getLearnConfig();
        break;

      case "courses":
        await getAllCourses();
        break;

      case "course":
        if (args.length < 2) {
          throw new Error("Missing course ID argument");
        }
        await getCourseInfo(parseInt(args[1]));
        break;

      case "user":
        if (args.length < 2) {
          throw new Error("Missing user public key argument");
        }
        await getUserProgress(args[1]);
        break;

      case "user-course":
        if (args.length < 3) {
          throw new Error("Missing user public key or course ID argument");
        }
        await getUserCourseProgress(args[1], parseInt(args[2]));
        break;

      case "export":
        await exportPlatformData(args[1]);
        break;

      default:
        throw new Error(`Unknown operation: ${operation}`);
    }
  } catch (error) {
    console.error(" Query failed:", error);
    process.exit(1);
  }
}

// Запускаем только если скрипт вызван напрямую
if (require.main === module) {
  main().catch(console.error);
}






