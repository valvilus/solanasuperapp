import * as anchor from "@coral-xyz/anchor";
import { Program, AnchorProvider, Wallet } from "@coral-xyz/anchor";
import { 
  PublicKey, 
  Keypair, 
  SystemProgram,
  Connection,
  clusterApiUrl
} from "@solana/web3.js";
import {
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
} from "@solana/spl-token";
import fs from 'fs';

// Load keypairs
const sponsorKeypair = Keypair.fromSecretKey(
  new Uint8Array(JSON.parse(fs.readFileSync('../../keys/mvp-sponsor-keypair.json', 'utf-8')))
);

// Token mint addresses
const TNG_MINT = new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs");

async function initialize() {
  // Configure the client to use the devnet cluster
  const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
  const wallet = new Wallet(sponsorKeypair);
  const provider = new AnchorProvider(connection, wallet, {
    commitment: "confirmed",
  });
  anchor.setProvider(provider);

  // Load program
  const idl = JSON.parse(fs.readFileSync('./target/idl/tng_learn.json', 'utf-8'));
  const program = new Program(idl, provider);

  console.log(" Initializing TNG Learn...");
  console.log(" Program ID:", program.programId.toString());
  console.log(" Payer:", sponsorKeypair.publicKey.toString());
  console.log(" TNG Mint:", TNG_MINT.toString());

  // Find PDA for learn config
  const [learnConfigPda, bump] = PublicKey.findProgramAddressSync(
    [Buffer.from("learn_config")],
    program.programId
  );

  console.log(" Learn Config PDA:", learnConfigPda.toString());
  console.log(" Bump:", bump);

  try {
    console.log(" Proceeding with TNG Learn initialization...");

    // Initialize the learn config
    const tx = await program.methods
      .initialize(sponsorKeypair.publicKey) // Передаем admin параметр
      .accounts({
        learnConfig: learnConfigPda, // Используем camelCase как в IDL
        payer: sponsorKeypair.publicKey,
        systemProgram: SystemProgram.programId, // Используем camelCase как в IDL
      })
      .signers([sponsorKeypair])
      .rpc();

    console.log(" TNG Learn initialized!");
    console.log(" Transaction signature:", tx);
    console.log(" Explorer:", `https://explorer.solana.com/tx/${tx}?cluster=devnet`);

    console.log(" Learn configuration created successfully!");

    // Save deployment info
    const deploymentInfo = {
      network: "devnet",
      programId: program.programId.toString(),
      learnConfig: learnConfigPda.toString(),
      bump: bump,
      timestamp: new Date().toISOString(),
      txSignature: tx
    };

    fs.writeFileSync('./deployment-info.json', JSON.stringify(deploymentInfo, null, 2));
    console.log(" Deployment info saved to deployment-info.json");

  } catch (error) {
    console.error(" Error initializing TNG Learn:", error);
    throw error;
  }
}

initialize()
  .then(() => {
    console.log(" TNG Learn initialization completed!");
    process.exit(0);
  })
  .catch((error) => {
    console.error(" Initialization failed:", error);
    process.exit(1);
  });