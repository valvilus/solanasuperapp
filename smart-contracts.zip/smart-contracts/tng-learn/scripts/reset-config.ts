import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { TngLearn } from "../target/types/tng_learn";
import { PublicKey, Keypair, SystemProgram } from "@solana/web3.js";
import fs from 'fs';
import path from 'path';

// Конфигурация
const CLUSTER = "devnet";
const TNG_MINT = new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs"); // Новый TNG mint

async function main() {
  console.log(" Resetting TNG Learn Platform Configuration...");

  // Загружаем sponsor кошелек
  const sponsorKeypairPath = path.join(__dirname, "../keys/mvp-sponsor-keypair.json");
  let sponsorKeypair: Keypair;
  
  try {
    const sponsorKeypairData = JSON.parse(fs.readFileSync(sponsorKeypairPath, 'utf8'));
    sponsorKeypair = Keypair.fromSecretKey(new Uint8Array(sponsorKeypairData));
    console.log(" Sponsor keypair loaded:", sponsorKeypair.publicKey.toString());
  } catch (error) {
    console.error(" Error loading sponsor keypair:", error);
    process.exit(1);
  }

  // Настройка провайдера
  const connection = new anchor.web3.Connection("https://api.devnet.solana.com", "confirmed");
  const wallet = new anchor.Wallet(sponsorKeypair);
  const provider = new anchor.AnchorProvider(connection, wallet, {});
  anchor.setProvider(provider);

  const program = anchor.workspace.TngLearn as Program<TngLearn>;

  try {
    // Генерируем PDA для старой конфигурации
    const [oldLearnConfigPda] = PublicKey.findProgramAddressSync(
      [Buffer.from("learn_config")],
      program.programId
    );

    console.log(" Old Learn Config PDA:", oldLearnConfigPda.toString());

    // Проверяем существующую конфигурацию
    try {
      const existingConfig = await program.account.learnConfig.fetch(oldLearnConfigPda);
      console.log(" Found existing config:");
      console.log("- Admin:", existingConfig.admin.toString());
      console.log("- Total courses:", existingConfig.totalCourses.toString());
      console.log("- Is active:", existingConfig.isActive);

      // Создаем новую конфигурацию с версией 2
      const [newLearnConfigPda] = PublicKey.findProgramAddressSync(
        [Buffer.from("learn_config_v2")],
        program.programId
      );

      console.log(" New Learn Config PDA:", newLearnConfigPda.toString());

      // Проверяем, не существует ли уже новая конфигурация
      try {
        const newConfig = await program.account.learnConfig.fetch(newLearnConfigPda);
        console.log(" New configuration already exists!");
        console.log("- Admin:", newConfig.admin.toString());
        return;
      } catch (error) {
        console.log(" New configuration doesn't exist, creating...");
      }

      // Инициализируем новую платформу с правильным TNG mint
      const adminPublicKey = sponsorKeypair.publicKey;
      
      console.log(" Creating new configuration with admin:", adminPublicKey.toString());
      console.log(" Using TNG mint:", TNG_MINT.toString());

      // Не можем создать новую инициализацию с тем же методом
      // Нужно использовать существующую конфигурацию или модифицировать контракт
      console.log(" Cannot create new config with same contract. Using existing config.");
      
      // Обновляем deployment info с правильным TNG mint для приложения
      const deploymentInfo = {
        network: CLUSTER,
        programId: program.programId.toString(),
        learnConfigPda: oldLearnConfigPda.toString(), // Используем существующий PDA
        admin: adminPublicKey.toString(),
        tngMint: TNG_MINT.toString(), // Правильный TNG mint для приложения!
        deployedAt: new Date().toISOString(),
        status: "initialized",
        note: "Updated deployment info with correct TNG mint (contract still uses old mint)",
        warning: "Contract mint and app mint are different - need contract upgrade",
        explorerUrls: {
          program: `https://explorer.solana.com/address/${program.programId.toString()}?cluster=${CLUSTER}`,
          config: `https://explorer.solana.com/address/${oldLearnConfigPda.toString()}?cluster=${CLUSTER}`
        }
      };

      fs.writeFileSync(
        path.join(__dirname, "../deployment-info.json"),
        JSON.stringify(deploymentInfo, null, 2)
      );

      console.log(" Updated deployment info saved");
      console.log("  WARNING: Contract still uses old mint, but app will use correct TNG mint");
      return;

      // This code is unreachable due to return above - commenting out
      // console.log(" New platform configuration created successfully!");
      // console.log("Transaction signature:", tx);
      // console.log("Admin:", adminPublicKey.toString());
      console.log("New Learn Config PDA:", newLearnConfigPda.toString());

      // Проверяем новую конфигурацию
      const newConfig = await program.account.learnConfig.fetch(newLearnConfigPda);
      console.log(" New Platform Status:");
      console.log("- Admin:", newConfig.admin.toString());
      console.log("- Total courses:", newConfig.totalCourses.toString());
      console.log("- Total rewards distributed:", newConfig.totalRewardsDistributed.toString());
      console.log("- Is active:", newConfig.isActive);

      // This code is unreachable due to return above - commenting out
      // const deploymentInfo = {
      //   network: CLUSTER,
      //   programId: program.programId.toString(),
      //   learnConfigPda: newLearnConfigPda.toString(), // Новый PDA!
      //   admin: adminPublicKey.toString(),
      //   tngMint: TNG_MINT.toString(), // Правильный TNG mint!
      //   deployedAt: new Date().toISOString(),
      //   status: "initialized",
      //   note: "Reset configuration with correct TNG mint",
      //   explorerUrls: {
      //     program: `https://explorer.solana.com/address/${program.programId.toString()}?cluster=${CLUSTER}`,
      //     config: `https://explorer.solana.com/address/${newLearnConfigPda.toString()}?cluster=${CLUSTER}`,
      //     transaction: `https://explorer.solana.com/tx/${tx}?cluster=${CLUSTER}`
      //   }
      // };

      fs.writeFileSync(
        path.join(__dirname, "../deployment-info.json"),
        JSON.stringify(deploymentInfo, null, 2)
      );

      console.log(" New deployment info saved to deployment-info.json");
      console.log(" Explorer links:");
      console.log("Program:", deploymentInfo.explorerUrls.program);
      console.log("Config:", deploymentInfo.explorerUrls.config);
      console.log("Transaction:", deploymentInfo.explorerUrls.transaction);

    } catch (configError) {
      console.log(" No existing configuration found, creating fresh one...");
      
      // Если старой конфигурации нет, создаем обычным способом
      const adminPublicKey = sponsorKeypair.publicKey;
      
      const tx = await program.methods
        .initialize(adminPublicKey)
        .accounts({
          payer: sponsorKeypair.publicKey,
        })
        .signers([sponsorKeypair])
        .rpc();

      console.log(" Fresh platform initialized!");
      console.log("Transaction:", tx);
      
      // Сохраняем правильную конфигурацию
      const deploymentInfo = {
        network: CLUSTER,
        programId: program.programId.toString(),
        learnConfigPda: oldLearnConfigPda.toString(),
        admin: adminPublicKey.toString(),
        tngMint: TNG_MINT.toString(),
        deployedAt: new Date().toISOString(),
        status: "initialized",
        explorerUrls: {
          program: `https://explorer.solana.com/address/${program.programId.toString()}?cluster=${CLUSTER}`,
          config: `https://explorer.solana.com/address/${oldLearnConfigPda.toString()}?cluster=${CLUSTER}`,
          transaction: `https://explorer.solana.com/tx/${tx}?cluster=${CLUSTER}`
        }
      };

      fs.writeFileSync(
        path.join(__dirname, "../deployment-info.json"),
        JSON.stringify(deploymentInfo, null, 2)
      );
    }

  } catch (error) {
    console.error(" Error resetting platform:", error);
    
    if (error instanceof Error) {
      console.error("Error message:", error.message);
    }
    
    if (error.logs) {
      console.error("Program logs:");
      error.logs.forEach((log: string) => console.error(log));
    }
    
    process.exit(1);
  }
}

main().catch((error) => {
  console.error(" Reset script failed:", error);
  process.exit(1);
});
