import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { TngLearn } from "../target/types/tng_learn";
import { PublicKey, Keypair } from "@solana/web3.js";
import fs from 'fs';
import path from 'path';

// Конфигурация
const CLUSTER = "devnet";
const TNG_MINT = new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs"); // Новый TNG mint

async function main() {
  console.log(" Initializing TNG Learn Platform...");

  // Загружаем sponsor кошелек
  const sponsorKeypairPath = path.join(__dirname, "../keys/mvp-sponsor-keypair.json");
  let sponsorKeypair: Keypair;
  
  try {
    const sponsorKeypairData = JSON.parse(fs.readFileSync(sponsorKeypairPath, 'utf8'));
    sponsorKeypair = Keypair.fromSecretKey(new Uint8Array(sponsorKeypairData));
    console.log(" Sponsor keypair loaded:", sponsorKeypair.publicKey.toString());
  } catch (error) {
    console.error(" Error loading sponsor keypair:", error);
    process.exit(1);
  }

  // Настройка провайдера
  const connection = new anchor.web3.Connection("https://api.devnet.solana.com", "confirmed");
  const wallet = new anchor.Wallet(sponsorKeypair);
  const provider = new anchor.AnchorProvider(connection, wallet, {});
  anchor.setProvider(provider);

  const program = anchor.workspace.TngLearn as Program<TngLearn>;

  try {
    // Генерируем PDA для конфигурации
    const [learnConfigPda] = PublicKey.findProgramAddressSync(
      [Buffer.from("learn_config")],
      program.programId
    );

    console.log(" Learn Config PDA:", learnConfigPda.toString());

    // Проверяем, не инициализирована ли уже платформа
    try {
      const existingConfig = await program.account.learnConfig.fetch(learnConfigPda);
      console.log(" Platform already initialized!");
      console.log("Admin:", existingConfig.admin.toString());
      console.log("Total courses:", existingConfig.totalCourses.toString());
      console.log("Is active:", existingConfig.isActive);
      
      // Если платформа уже инициализирована, мы не можем её переинициализировать
      // Нужно использовать другой подход или создать новый PDA
      console.log(" Need to create new configuration or use existing one...");
      return;
    } catch (error) {
      // Конфигурация не найдена, продолжаем инициализацию
      console.log(" Platform not initialized, proceeding...");
    }

    // Инициализируем платформу
    const adminPublicKey = sponsorKeypair.publicKey; // В MVP sponsor = admin

    console.log(" Initializing with admin:", adminPublicKey.toString());

    const tx = await program.methods
      .initialize(adminPublicKey)
      .accounts({
        payer: sponsorKeypair.publicKey,
      })
      .signers([sponsorKeypair])
      .rpc();

    console.log(" Platform initialized successfully!");
    console.log("Transaction signature:", tx);
    console.log("Admin:", adminPublicKey.toString());
    console.log("Learn Config PDA:", learnConfigPda.toString());

    // Проверяем инициализацию
    const config = await program.account.learnConfig.fetch(learnConfigPda);
    console.log(" Platform Status:");
    console.log("- Admin:", config.admin.toString());
    console.log("- Total courses:", config.totalCourses.toString());
    console.log("- Total rewards distributed:", config.totalRewardsDistributed.toString());
    console.log("- Is active:", config.isActive);

    // Сохраняем информацию о деплое
    const deploymentInfo = {
      network: CLUSTER,
      programId: program.programId.toString(),
      learnConfigPda: learnConfigPda.toString(),
      admin: adminPublicKey.toString(),
      tngMint: TNG_MINT.toString(),
      deployedAt: new Date().toISOString(),
      status: "initialized",
      explorerUrls: {
        program: `https://explorer.solana.com/address/${program.programId.toString()}?cluster=${CLUSTER}`,
        config: `https://explorer.solana.com/address/${learnConfigPda.toString()}?cluster=${CLUSTER}`,
        transaction: `https://explorer.solana.com/tx/${tx}?cluster=${CLUSTER}`
      }
    };

    fs.writeFileSync(
      path.join(__dirname, "../deployment-info.json"),
      JSON.stringify(deploymentInfo, null, 2)
    );

    console.log(" Deployment info saved to deployment-info.json");
    console.log(" Explorer links:");
    console.log("Program:", deploymentInfo.explorerUrls.program);
    console.log("Config:", deploymentInfo.explorerUrls.config);
    console.log("Transaction:", deploymentInfo.explorerUrls.transaction);

  } catch (error) {
    console.error(" Error initializing platform:", error);
    
    if (error instanceof Error) {
      console.error("Error message:", error.message);
    }
    
    if (error.logs) {
      console.error("Program logs:");
      error.logs.forEach((log: string) => console.error(log));
    }
    
    process.exit(1);
  }
}

main().catch((error) => {
  console.error(" Script failed:", error);
  process.exit(1);
});
