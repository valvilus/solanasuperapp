import * as anchor from "@coral-xyz/anchor";
import { Program, AnchorProvider, Wallet } from "@coral-xyz/anchor";
import { TngLearn } from "../target/types/tng_learn";
import { 
  PublicKey, 
  Keypair, 
  Connection,
  SystemProgram,
  SYSVAR_RENT_PUBKEY,
} from "@solana/web3.js";
import {
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  getAssociatedTokenAddress,
  createAssociatedTokenAccountInstruction,
  getAccount
} from "@solana/spl-token";
import fs from 'fs';
import path from 'path';

// Конфигурация
const CLUSTER = "devnet";
const TNG_MINT = new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs"); // Правильный TNG mint

async function main() {
  console.log(" Testing Create Course...");

  // Загружаем sponsor кошелек
  const sponsorKeypairPath = path.join(__dirname, "../keys/mvp-sponsor-keypair.json");
  let sponsorKeypair: Keypair;
  
  try {
    const sponsorKeypairData = JSON.parse(fs.readFileSync(sponsorKeypairPath, 'utf8'));
    sponsorKeypair = Keypair.fromSecretKey(new Uint8Array(sponsorKeypairData));
    console.log(" Sponsor keypair loaded:", sponsorKeypair.publicKey.toString());
  } catch (error) {
    console.error(" Error loading sponsor keypair:", error);
    process.exit(1);
  }

  // Настройка провайдера
  const connection = new anchor.web3.Connection("https://api.devnet.solana.com", "confirmed");
  const wallet = new anchor.Wallet(sponsorKeypair);
  const provider = new anchor.AnchorProvider(connection, wallet, {});
  anchor.setProvider(provider);

  const program = anchor.workspace.TngLearn as Program<TngLearn>;

  try {
    // Параметры курса
    const courseId = 1;
    const title = "Test Course";
    const description = "Test Description";  
    const rewardAmount = new anchor.BN(100_000_000); // 100 TNG

    console.log(" Course parameters:");
    console.log("- Course ID:", courseId);
    console.log("- Title:", title);
    console.log("- Description:", description);
    console.log("- Reward:", rewardAmount.toString());

    // Генерируем все необходимые PDA
    const [learnConfigPda] = PublicKey.findProgramAddressSync(
      [Buffer.from("learn_config")],
      program.programId
    );

    const [coursePda] = PublicKey.findProgramAddressSync(
      [Buffer.from("course"), new anchor.BN(courseId).toArrayLike(Buffer, "le", 8)],
      program.programId
    );

    // Создаем ATA для vault (используем Associated Token Program)
    const courseVaultAddress = await getAssociatedTokenAddress(
      TNG_MINT,
      coursePda,
      true  // allowOwnerOffCurve
    );

    // Creator's token account
    const creatorTokenAccount = await getAssociatedTokenAddress(
      TNG_MINT,
      sponsorKeypair.publicKey
    );

    console.log(" PDAs:");
    console.log("- Learn Config:", learnConfigPda.toString());
    console.log("- Course PDA:", coursePda.toString());
    console.log("- Course Vault:", courseVaultAddress.toString());
    console.log("- Creator Token Account:", creatorTokenAccount.toString());
    console.log("- TNG Mint:", TNG_MINT.toString());

    // Проверяем баланс creator'а
    try {
      const creatorTokenAccountInfo = await getAccount(connection, creatorTokenAccount);
      console.log(" Creator balance:", creatorTokenAccountInfo.amount.toString());
    } catch (error) {
      console.log(" Creator doesn't have TNG token account");
      process.exit(1);
    }

    // Создаем курс
    console.log(" Creating course...");

    const tx = await program.methods
      .createCourse(
        title,                    // title: String
        description,              // description: String  
        rewardAmount,             // reward_amount: u64
        new anchor.BN(courseId)   // course_id: u64
      )
      .accountsPartial({
        course: coursePda,
        courseVault: courseVaultAddress,
        learnConfig: learnConfigPda,
        creator: sponsorKeypair.publicKey,
        creatorTokenAccount: creatorTokenAccount,
        tngMint: TNG_MINT,
        payer: sponsorKeypair.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      } as any)
      .signers([sponsorKeypair])
      .rpc();

    console.log(" Course created successfully!");
    console.log("Transaction signature:", tx);
    console.log(" Explorer:", `https://explorer.solana.com/tx/${tx}?cluster=${CLUSTER}`);

    // Проверяем созданный курс
    const courseAccount = await program.account.course.fetch(coursePda);
    console.log(" Course details:");
    console.log("- ID:", courseAccount.courseId.toString());
    console.log("- Title:", courseAccount.title);
    console.log("- Description:", courseAccount.description);
    console.log("- Creator:", courseAccount.creator.toString());
    console.log("- Reward:", courseAccount.rewardAmount.toString());
    console.log("- Active:", courseAccount.isActive);

    // Проверяем vault balance
    const vaultAccount = await getAccount(connection, courseVaultAddress);
    console.log(" Vault balance:", vaultAccount.amount.toString());

  } catch (error) {
    console.error(" Error creating course:", error);
    
    if (error instanceof Error) {
      console.error("Error message:", error.message);
    }
    
    if (error.logs) {
      console.error("Program logs:");
      error.logs.forEach((log: string) => console.error(log));
    }
    
    process.exit(1);
  }
}

main().catch((error) => {
  console.error(" Test failed:", error);
  process.exit(1);
});
