import * as anchor from "@coral-xyz/anchor";
import { Program, AnchorProvider, Wallet } from "@coral-xyz/anchor";
import { TngLearn } from "../target/types/tng_learn";
import { 
  PublicKey, 
  Keypair, 
  Connection,
  Transaction,
  SystemProgram,
  SYSVAR_RENT_PUBKEY,
  clusterApiUrl
} from "@solana/web3.js";
import {
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  getAssociatedTokenAddress,
  createAssociatedTokenAccountInstruction,
  getAccount
} from "@solana/spl-token";
import fs from 'fs';
import path from 'path';

export interface CreateCourseParams {
  title: string;
  description: string;
  rewardAmount: number;
  courseId: number;
}

export interface SubmitAnswerParams {
  courseId: number;
  answerHash: string;
}

export interface Course {
  courseId: number;
  title: string;
  description: string;
  creator: PublicKey;
  rewardAmount: number;
  isActive: boolean;
  createdAt: number;
}

export interface UserCourse {
  user: PublicKey;
  courseId: number;
  isCompleted: boolean;
  isRewardClaimed: boolean;
  completedAt: number;
  answerHash: string;
}

export interface LearnConfig {
  admin: PublicKey;
  totalCourses: number;
  totalRewardsDistributed: number;
  isActive: boolean;
}

export interface UserProgress {
  completedCourses: number;
  totalRewardsClaimed: number;
  userCourses: UserCourse[];
}

/**
 * Сервис для взаимодействия с TNG Learn смарт-контрактом
 */
export class TngLearnContractService {
  private connection: Connection;
  private program: Program<TngLearn>;
  private tngMint: PublicKey;

  constructor(connection: Connection, tngMint?: PublicKey) {
    this.connection = connection;
    this.tngMint = tngMint || new PublicKey("FMACx4PexHrMux1j2RLHW6fBc5PuCrzi2LV7bEqUKygs");
    
    // Загружаем программу из IDL
    try {
      const idlPath = path.join(__dirname, "../target/idl/tng_learn.json");
      const idl = JSON.parse(fs.readFileSync(idlPath, 'utf-8'));
      // Создаем простой provider для работы с Program
      const provider = new AnchorProvider(this.connection, {} as Wallet, {});
      this.program = new Program(idl, provider);
    } catch (error) {
      console.error(" Error loading program IDL:", error);
      throw new Error("Failed to load TNG Learn program");
    }
  }

  /**
   * Получить PDA для конфигурации Learn платформы
   */
  public getLearnConfigPda(): [PublicKey, number] {
    return PublicKey.findProgramAddressSync(
      [Buffer.from("learn_config")],
      this.program.programId
    );
  }

  /**
   * Получить PDA для курса
   */
  public getCoursePda(courseId: number): [PublicKey, number] {
    const courseIdBuffer = Buffer.alloc(8);
    courseIdBuffer.writeBigUInt64LE(BigInt(courseId), 0);
    
    return PublicKey.findProgramAddressSync(
      [Buffer.from("course"), courseIdBuffer],
      this.program.programId
    );
  }

  /**
   * Получить PDA для прогресса пользователя
   */
  public getUserCoursePda(user: PublicKey, courseId: number): [PublicKey, number] {
    const courseIdBuffer = Buffer.alloc(8);
    courseIdBuffer.writeBigUInt64LE(BigInt(courseId), 0);
    
    return PublicKey.findProgramAddressSync(
      [Buffer.from("user_course"), user.toBuffer(), courseIdBuffer],
      this.program.programId
    );
  }

  /**
   * Получить PDA для хранилища наград курса
   */
  public async getCourseVaultPda(courseId: number): Promise<PublicKey> {
    const [coursePda] = this.getCoursePda(courseId);
    return await getAssociatedTokenAddress(this.tngMint, coursePda, true);
  }

  /**
   * Проверить, инициализирована ли Learn платформа
   */
  public async isLearnPlatformInitialized(): Promise<boolean> {
    try {
      const [configPda] = this.getLearnConfigPda();
      await this.program.account.learnConfig.fetch(configPda);
      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * Получить конфигурацию Learn платформы
   */
  public async getLearnConfig(): Promise<LearnConfig | null> {
    try {
      const [configPda] = this.getLearnConfigPda();
      const config = await this.program.account.learnConfig.fetch(configPda);
      
      return {
        admin: config.admin,
        totalCourses: config.totalCourses.toNumber(),
        totalRewardsDistributed: config.totalRewardsDistributed.toNumber(),
        isActive: config.isActive
      };
    } catch (error) {
      console.error("Error fetching learn config:", error);
      return null;
    }
  }

  /**
   * Получить все курсы
   */
  public async getAllCourses(): Promise<Course[]> {
    try {
      const courses = await this.program.account.course.all();
      
      return courses.map(courseAccount => ({
        courseId: courseAccount.account.courseId.toNumber(),
        title: courseAccount.account.title,
        description: courseAccount.account.description,
        creator: courseAccount.account.creator,
        rewardAmount: courseAccount.account.rewardAmount.toNumber(),
        isActive: courseAccount.account.isActive,
        createdAt: courseAccount.account.createdAt.toNumber()
      }));
    } catch (error) {
      console.error("Error fetching courses:", error);
      return [];
    }
  }

  /**
   * Получить курс по ID
   */
  public async getCourse(courseId: number): Promise<Course | null> {
    try {
      const [coursePda] = this.getCoursePda(courseId);
      const course = await this.program.account.course.fetch(coursePda);
      
      return {
        courseId: course.courseId.toNumber(),
        title: course.title,
        description: course.description,
        creator: course.creator,
        rewardAmount: course.rewardAmount.toNumber(),
        isActive: course.isActive,
        createdAt: course.createdAt.toNumber()
      };
    } catch (error) {
      console.error(`Error fetching course ${courseId}:`, error);
      return null;
    }
  }

  /**
   * Получить прогресс пользователя по курсу
   */
  public async getUserCourse(user: PublicKey, courseId: number): Promise<UserCourse | null> {
    try {
      const [userCoursePda] = this.getUserCoursePda(user, courseId);
      const userCourse = await this.program.account.userCourse.fetch(userCoursePda);
      
      return {
        user: userCourse.user,
        courseId: userCourse.courseId.toNumber(),
        isCompleted: userCourse.isCompleted,
        isRewardClaimed: userCourse.isRewardClaimed,
        completedAt: userCourse.completedAt.toNumber(),
        answerHash: userCourse.answerHash
      };
    } catch (error) {
      // Возвращаем null если запись не найдена (пользователь не проходил курс)
      return null;
    }
  }

  /**
   * Получить общий прогресс пользователя
   */
  public async getUserProgress(user: PublicKey): Promise<UserProgress> {
    try {
      // Получаем все записи пользователя
      const userCourses = await this.program.account.userCourse.all([
        {
          memcmp: {
            offset: 8, // Skip discriminator
            bytes: user.toBase58()
          }
        }
      ]);

      const processedUserCourses = userCourses.map(uc => ({
        user: uc.account.user,
        courseId: uc.account.courseId.toNumber(),
        isCompleted: uc.account.isCompleted,
        isRewardClaimed: uc.account.isRewardClaimed,
        completedAt: uc.account.completedAt.toNumber(),
        answerHash: uc.account.answerHash
      }));

      const completedCourses = processedUserCourses.filter(uc => uc.isCompleted).length;
      const totalRewardsClaimed = processedUserCourses
        .filter(uc => uc.isRewardClaimed)
        .length; // В реальности это должна быть сумма наград

      return {
        completedCourses,
        totalRewardsClaimed,
        userCourses: processedUserCourses
      };
    } catch (error) {
      console.error("Error fetching user progress:", error);
      return {
        completedCourses: 0,
        totalRewardsClaimed: 0,
        userCourses: []
      };
    }
  }

  /**
   * Получить баланс хранилища курса
   */
  public async getCourseVaultBalance(courseId: number): Promise<number> {
    try {
      const vaultAddress = await this.getCourseVaultPda(courseId);
      const vaultAccount = await getAccount(this.connection, vaultAddress);
      return Number(vaultAccount.amount);
    } catch (error) {
      console.error(`Error fetching vault balance for course ${courseId}:`, error);
      return 0;
    }
  }

  /**
   * Построить транзакцию создания курса
   */
  public async buildCreateCourseTransaction(
    creator: PublicKey,
    payer: PublicKey,
    params: CreateCourseParams
  ): Promise<Transaction> {
    const [coursePda] = this.getCoursePda(params.courseId);
    const vaultAddress = await this.getCourseVaultPda(params.courseId);
    const [learnConfigPda] = this.getLearnConfigPda();
    const creatorTokenAccount = await getAssociatedTokenAddress(this.tngMint, creator);

    const transaction = new Transaction();

    // Добавляем инструкцию создания ATA для хранилища если нужно
    try {
      await getAccount(this.connection, vaultAddress);
    } catch (error) {
      // ATA не существует, создаем
      transaction.add(
        createAssociatedTokenAccountInstruction(
          payer,
          vaultAddress,
          coursePda,
          this.tngMint
        )
      );
    }

    // Добавляем инструкцию создания курса
    const createCourseIx = await this.program.methods
      .createCourse(
        params.title,                          // title: String
        params.description,                    // description: String  
        new anchor.BN(params.rewardAmount),    // reward_amount: u64
        new anchor.BN(params.courseId)         // course_id: u64
      )
      .accounts({
        course: coursePda,
        courseVault: vaultAddress,
        learnConfig: learnConfigPda,
        creator: creator,
        creatorTokenAccount: creatorTokenAccount,
        tngMint: this.tngMint,
        payer: payer,
        tokenProgram: TOKEN_PROGRAM_ID,
        associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      })
      .instruction();

    transaction.add(createCourseIx);

    // Устанавливаем recent blockhash
    const { blockhash } = await this.connection.getLatestBlockhash();
    transaction.recentBlockhash = blockhash;
    transaction.feePayer = payer;

    return transaction;
  }

  /**
   * Построить транзакцию отправки ответа
   */
  public async buildSubmitAnswerTransaction(
    user: PublicKey,
    payer: PublicKey,
    params: SubmitAnswerParams
  ): Promise<Transaction> {
    const [coursePda] = this.getCoursePda(params.courseId);
    const [userCoursePda] = this.getUserCoursePda(user, params.courseId);

    const transaction = new Transaction();

    const submitAnswerIx = await this.program.methods
      .submitAnswer(
        new anchor.BN(params.courseId),  // course_id: u64
        params.answerHash                // answer_hash: String
      )
      .accounts({
        userCourse: userCoursePda,
        course: coursePda,
        user: user,
        payer: payer,
        systemProgram: SystemProgram.programId,
      })
      .instruction();

    transaction.add(submitAnswerIx);

    // Устанавливаем recent blockhash
    const { blockhash } = await this.connection.getLatestBlockhash();
    transaction.recentBlockhash = blockhash;
    transaction.feePayer = payer;

    return transaction;
  }

  /**
   * Построить транзакцию получения награды
   */
  public async buildClaimRewardTransaction(
    user: PublicKey,
    payer: PublicKey,
    courseId: number
  ): Promise<Transaction> {
    const [coursePda] = this.getCoursePda(courseId);
    const [userCoursePda] = this.getUserCoursePda(user, courseId);
    const vaultAddress = await this.getCourseVaultPda(courseId);
    const userTokenAccount = await getAssociatedTokenAddress(this.tngMint, user);

    const transaction = new Transaction();

    // Добавляем инструкцию создания ATA для пользователя если нужно
    try {
      await getAccount(this.connection, userTokenAccount);
    } catch (error) {
      // ATA не существует, создаем
      transaction.add(
        createAssociatedTokenAccountInstruction(
          payer,
          userTokenAccount,
          user,
          this.tngMint
        )
      );
    }

    const [learnConfigPda] = this.getLearnConfigPda();

    const claimRewardIx = await this.program.methods
      .claimReward(new anchor.BN(courseId))  // course_id: u64
      .accounts({
        userCourse: userCoursePda,
        course: coursePda,
        courseVault: vaultAddress,
        learnConfig: learnConfigPda,
        user: user,
        userTokenAccount: userTokenAccount,
        tngMint: this.tngMint,
        payer: payer,
        tokenProgram: TOKEN_PROGRAM_ID,
        associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      })
      .instruction();

    transaction.add(claimRewardIx);

    // Устанавливаем recent blockhash
    const { blockhash } = await this.connection.getLatestBlockhash();
    transaction.recentBlockhash = blockhash;
    transaction.feePayer = payer;

    return transaction;
  }

  /**
   * Форматировать сумму TNG токенов
   */
  public formatTNGAmount(lamports: number): string {
    const tokens = lamports / 1_000_000_000; // 9 decimals
    return `${tokens.toFixed(2)} TNG`;
  }

  /**
   * Получить ID программы
   */
  public get programId(): PublicKey {
    return this.program.programId;
  }
}

// Экспорт для использования в других скриптах
export function createLearnService(rpcUrl?: string): TngLearnContractService {
  const connection = new Connection(rpcUrl || clusterApiUrl("devnet"), "confirmed");
  return new TngLearnContractService(connection);
}


