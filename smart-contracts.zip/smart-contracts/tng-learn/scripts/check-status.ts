import * as anchor from "@coral-xyz/anchor";
import { Program, AnchorProvider, Wallet } from "@coral-xyz/anchor";
import { 
  PublicKey, 
  Keypair, 
  Connection,
  clusterApiUrl
} from "@solana/web3.js";
import fs from 'fs';

// Load keypairs
const sponsorKeypair = Keypair.fromSecretKey(
  new Uint8Array(JSON.parse(fs.readFileSync('../../keys/mvp-sponsor-keypair.json', 'utf-8')))
);

async function checkStatus() {
  // Configure the client to use the devnet cluster
  const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
  const wallet = new Wallet(sponsorKeypair);
  const provider = new AnchorProvider(connection, wallet, {
    commitment: "confirmed",
  });
  anchor.setProvider(provider);

  // Load program
  const idl = JSON.parse(fs.readFileSync('./target/idl/tng_learn.json', 'utf-8'));
  const program = new Program(idl, provider);

  console.log(" Checking TNG Learn status...");
  console.log(" Program ID:", program.programId.toString());

  // Find PDA for learn config
  const [learnConfigPda, bump] = PublicKey.findProgramAddressSync(
    [Buffer.from("learn_config")],
    program.programId
  );

  console.log(" Learn Config PDA:", learnConfigPda.toString());
  console.log(" Bump:", bump);

  try {
    // Check if account exists
    const accountInfo = await connection.getAccountInfo(learnConfigPda);
    
    if (accountInfo) {
      console.log(" Account exists!");
      console.log(" Account owner:", accountInfo.owner.toString());
      console.log(" Lamports:", accountInfo.lamports);
      console.log(" Data length:", accountInfo.data.length);
      
      try {
        // Try to fetch the account data using the program
        const learnConfig = await program.account.learnConfig.fetch(learnConfigPda);
        console.log(" Learn Config Data:");
        console.log("  Admin:", learnConfig.admin.toString());
        console.log("  Total Courses:", learnConfig.totalCourses.toString());
        console.log("  Total Rewards Distributed:", learnConfig.totalRewardsDistributed.toString());
        console.log("  Is Active:", learnConfig.isActive);
        console.log("  Bump:", learnConfig.bump);
        console.log(" TNG Learn is already initialized and ready to use!");
      } catch (fetchError) {
        console.log(" Account exists but data fetch failed:", fetchError);
        console.log(" Raw data (first 50 bytes):", accountInfo.data.slice(0, 50));
      }
    } else {
      console.log(" Account does not exist - needs initialization");
    }

  } catch (error) {
    console.error(" Error checking status:", error);
  }
}

checkStatus()
  .then(() => {
    console.log(" Status check completed!");
    process.exit(0);
  })
  .catch((error) => {
    console.error(" Status check failed:", error);
    process.exit(1);
  });
