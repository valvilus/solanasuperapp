# TNG Learn Smart Contract Scripts

Набор скриптов для работы с TNG Learn смарт-контрактом на Solana.

## Установка

```bash
npm install
```

## Инициализация

Перед использованием контракта необходимо его инициализировать:

```bash
npm run initialize
```

Эта команда:
- Загружает sponsor keypair из `keys/mvp-sponsor-keypair.json`
- Инициализирует Learn платформу с sponsor'ом в качестве админа
- Сохраняет информацию о деплое в `deployment-info.json`

## Операции с курсами

### Создание курса

```bash
npm run course:create <keypair-path> <course-id> <title> <description> <reward-amount>
```

Пример:
```bash
npm run course:create ./keys/sponsor.json 1 "Solana Basics" "Learn Solana fundamentals" 1000000000
```

### Отправка ответа (завершение курса)

```bash
npm run course:submit <keypair-path> <course-id> <answer-hash>
```

Пример:
```bash
npm run course:submit ./keys/user.json 1 "answer123"
```

### Получение награды

```bash
npm run course:claim <keypair-path> <course-id>
```

Пример:
```bash
npm run course:claim ./keys/user.json 1
```

## Запросы данных

### Получить конфигурацию платформы

```bash
npm run query:config
```

### Получить все курсы

```bash
npm run query:courses
```

### Получить информацию о курсе

```bash
npm run query:course <course-id>
```

Пример:
```bash
npm run query:course 1
```

### Получить прогресс пользователя

```bash
npm run query:user <user-public-key>
```

Пример:
```bash
npm run query:user 9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM
```

### Получить прогресс пользователя по курсу

```bash
npm run query:user-course <user-public-key> <course-id>
```

Пример:
```bash
npm run query:user-course 9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM 1
```

### Экспортировать все данные

```bash
npm run query:export [output-file]
```

Пример:
```bash
npm run query:export platform-data.json
```

## Структура файлов

- `scripts/initialize-learn.ts` - Инициализация платформы
- `scripts/contract-service.ts` - Сервис для работы с контрактом
- `scripts/course-operations.ts` - Операции с курсами
- `scripts/course-queries.ts` - Запросы данных

## Переменные окружения

- `SOLANA_RPC_URL` - URL RPC ноды Solana (по умолчанию: devnet)

## Ключи

Убедитесь, что у вас есть необходимые keypair файлы:
- `keys/mvp-sponsor-keypair.json` - Главный sponsor keypair
- Другие keypair файлы для пользователей

## Примеры использования

### Полный цикл работы с курсом

1. Инициализация платформы:
```bash
npm run initialize
```

2. Создание курса (sponsor):
```bash
npm run course:create ./keys/sponsor.json 1 "Solana DeFi" "Learn DeFi on Solana" 2000000000
```

3. Прохождение курса (пользователь):
```bash
npm run course:submit ./keys/user.json 1 "my_answer_hash"
```

4. Получение награды:
```bash
npm run course:claim ./keys/user.json 1
```

5. Проверка прогресса:
```bash
npm run query:user 9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM
```

### Мониторинг платформы

```bash
# Общая статистика
npm run query:config

# Все курсы
npm run query:courses

# Экспорт данных
npm run query:export backup-$(date +%Y%m%d).json
```

## Troubleshooting

### Ошибка "Program not found"
Убедитесь, что программа развернута и адрес правильный в IDL файле.

### Ошибка "Account not found"
Убедитесь, что платформа инициализирована (`npm run initialize`).

### Ошибка с токенами
Убедитесь, что TNG mint адрес правильный и у пользователей есть токены/ATA.

## Разработка

Для модификации скриптов:
1. Измените соответствующий TypeScript файл
2. Запустите линтер: `npm run lint:fix`
3. Протестируйте изменения

## Интеграция с фронтендом

Эти скрипты служат основой для интеграции с веб-приложением. Сервис `TngLearnContractService` может быть импортирован и использован в Next.js API routes.









