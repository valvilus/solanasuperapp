use anchor_lang::prelude::*;
use anchor_spl::token::{self, Mint, Token, TokenAccount, Transfer};
use anchor_spl::associated_token::AssociatedToken;

declare_id!("SJL8TzuoUi8LvNSD3jeoYxtrVTcdNUdWFTe17JAgCgB");

#[program]
pub mod tng_learn {
    use super::*;

    /// Инициализация платформы обучения
    pub fn initialize(
        ctx: Context<Initialize>,
        admin: Pubkey,
    ) -> Result<()> {
        let learn_config = &mut ctx.accounts.learn_config;
        learn_config.admin = admin;
        learn_config.total_courses = 0;
        learn_config.total_rewards_distributed = 0;
        learn_config.is_active = true;
        learn_config.bump = ctx.bumps.learn_config;

        msg!("TNG Learn platform initialized with admin: {}", admin);
        Ok(())
    }

    /// Создание нового курса
    pub fn create_course(
        ctx: Context<CreateCourse>,
        title: String,
        description: String,
        reward_amount: u64,
        course_id: String,
    ) -> Result<()> {
        require!(title.len() <= 100, LearnError::TitleTooLong);
        require!(description.len() <= 500, LearnError::DescriptionTooLong);
        require!(reward_amount > 0, LearnError::InvalidRewardAmount);

        let course = &mut ctx.accounts.course;
        let learn_config = &mut ctx.accounts.learn_config;

        // Проверяем что курс еще не создан (для init_if_needed)
        require!(course.course_id.is_empty(), LearnError::CourseAlreadyExists);

        course.course_id = course_id.clone();
        course.title = title.clone();
        course.description = description.clone();
        course.creator = ctx.accounts.creator.key();
        course.reward_amount = reward_amount;
        course.total_completions = 0;
        course.is_active = true;
        course.created_at = Clock::get()?.unix_timestamp;
        course.bump = ctx.bumps.course;

        // Обновляем общую статистику
        learn_config.total_courses = learn_config.total_courses.checked_add(1).unwrap();

        // Переводим токены в vault для будущих наград
        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.creator_token_account.to_account_info(),
                to: ctx.accounts.course_vault.to_account_info(),
                authority: ctx.accounts.creator.to_account_info(),
            },
        );
        token::transfer(transfer_ctx, reward_amount)?;

        emit!(CourseCreated {
            course_id,
            title: title.clone(),
            creator: ctx.accounts.creator.key(),
            reward_amount,
            timestamp: Clock::get()?.unix_timestamp,
        });

        msg!("Course created: {} with reward: {} TNG", title, reward_amount);
        Ok(())
    }

    /// Отправка ответа/завершение курса пользователем
    pub fn submit_answer(
        ctx: Context<SubmitAnswer>,
        course_id: String,
        answer_hash: String, // Хэш ответа для верификации
    ) -> Result<()> {
        require!(answer_hash.len() <= 64, LearnError::InvalidAnswerHash);

        let user_course = &mut ctx.accounts.user_course;
        let course = &mut ctx.accounts.course;

        require!(course.is_active, LearnError::CourseNotActive);
        require!(!user_course.is_completed, LearnError::AlreadyCompleted);

        user_course.user = ctx.accounts.user.key();
        user_course.course_id = course_id.clone();
        user_course.answer_hash = answer_hash.clone();
        user_course.is_completed = true;
        user_course.completed_at = Clock::get()?.unix_timestamp;
        user_course.is_reward_claimed = false;
        user_course.bump = ctx.bumps.user_course;

        // Увеличиваем счетчик завершений курса
        course.total_completions = course.total_completions.checked_add(1).unwrap();

        emit!(AnswerSubmitted {
            course_id: course_id.clone(),
            user: ctx.accounts.user.key(),
            answer_hash,
            timestamp: Clock::get()?.unix_timestamp,
        });

        msg!("Answer submitted for course {} by user {}", course_id, ctx.accounts.user.key());
        Ok(())
    }

    /// Получение награды за завершение курса
    pub fn claim_reward(
        ctx: Context<ClaimReward>,
        course_id: String,
    ) -> Result<()> {
        let user_course = &mut ctx.accounts.user_course;
        let course = &ctx.accounts.course;
        let learn_config = &mut ctx.accounts.learn_config;

        require!(user_course.is_completed, LearnError::CourseNotCompleted);
        require!(!user_course.is_reward_claimed, LearnError::RewardAlreadyClaimed);

        // Переводим награду пользователю из vault
        let course_id_bytes = course.course_id.as_bytes();
        let seeds = &[
            b"course",
            course_id_bytes.as_ref(),
            &[course.bump],
        ];
        let signer = &[&seeds[..]];

        let transfer_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.course_vault.to_account_info(),
                to: ctx.accounts.user_token_account.to_account_info(),
                authority: ctx.accounts.course.to_account_info(),
            },
            signer,
        );
        token::transfer(transfer_ctx, course.reward_amount)?;

        // Обновляем статус
        user_course.is_reward_claimed = true;
        user_course.claimed_at = Some(Clock::get()?.unix_timestamp);

        // Обновляем общую статистику
        learn_config.total_rewards_distributed = learn_config.total_rewards_distributed
            .checked_add(course.reward_amount).unwrap();

        emit!(RewardClaimed {
            course_id: course_id.clone(),
            user: ctx.accounts.user.key(),
            reward_amount: course.reward_amount,
            timestamp: Clock::get()?.unix_timestamp,
        });

        msg!("Reward claimed: {} TNG for course {} by user {}", 
             course.reward_amount, course_id, ctx.accounts.user.key());
        Ok(())
    }

    /// Закрытие курса создателем (опционально)
    pub fn close_course(
        ctx: Context<CloseCourse>,
        course_id: String,
    ) -> Result<()> {
        let course = &mut ctx.accounts.course;
        
        require!(course.creator == ctx.accounts.creator.key(), LearnError::NotCourseCreator);
        require!(course.is_active, LearnError::CourseNotActive);

        course.is_active = false;

        emit!(CourseClosed {
            course_id: course_id.clone(),
            creator: ctx.accounts.creator.key(),
            timestamp: Clock::get()?.unix_timestamp,
        });

        msg!("Course {} closed by creator", course_id);
        Ok(())
    }
}

// ============================================================================
// Accounts
// ============================================================================

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(
        init,
        payer = payer,
        space = LearnConfig::LEN,
        seeds = [b"learn_config"],
        bump
    )]
    pub learn_config: Account<'info, LearnConfig>,
    
    #[account(mut)]
    pub payer: Signer<'info>, // sponsor
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(title: String, description: String, reward_amount: u64, course_id: String)]
pub struct CreateCourse<'info> {
    #[account(
        init_if_needed,
        payer = payer,
        space = Course::LEN,
        seeds = [b"course", course_id.as_bytes()],
        bump
    )]
    pub course: Account<'info, Course>,

    #[account(
        init,
        payer = payer,
        associated_token::mint = tng_mint,
        associated_token::authority = course
    )]
    pub course_vault: Account<'info, TokenAccount>,

    #[account(
        mut,
        seeds = [b"learn_config"],
        bump = learn_config.bump
    )]
    pub learn_config: Account<'info, LearnConfig>,

    #[account(mut)]
    pub creator: Signer<'info>,

    #[account(
        init_if_needed,
        payer = payer,
        associated_token::mint = tng_mint,
        associated_token::authority = creator
    )]
    pub creator_token_account: Account<'info, TokenAccount>,

    pub tng_mint: Account<'info, Mint>,

    #[account(mut)]
    pub payer: Signer<'info>, // sponsor

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(course_id: String, answer_hash: String)]
pub struct SubmitAnswer<'info> {
    #[account(
        init_if_needed,
        payer = payer,
        space = UserCourse::LEN,
        seeds = [b"user_course", user.key().as_ref(), course_id.as_bytes()],
        bump
    )]
    pub user_course: Account<'info, UserCourse>,

    #[account(
        mut,
        seeds = [b"course", course_id.as_bytes()],
        bump = course.bump
    )]
    pub course: Account<'info, Course>,

    pub user: Signer<'info>,

    #[account(mut)]
    pub payer: Signer<'info>, // sponsor

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(course_id: String)]
pub struct ClaimReward<'info> {
    #[account(
        mut,
        seeds = [b"user_course", user.key().as_ref(), course_id.as_bytes()],
        bump = user_course.bump
    )]
    pub user_course: Account<'info, UserCourse>,

    #[account(
        seeds = [b"course", course_id.as_bytes()],
        bump = course.bump
    )]
    pub course: Account<'info, Course>,

    #[account(
        mut,
        associated_token::mint = tng_mint,
        associated_token::authority = course
    )]
    pub course_vault: Account<'info, TokenAccount>,

    #[account(
        mut,
        seeds = [b"learn_config"],
        bump = learn_config.bump
    )]
    pub learn_config: Account<'info, LearnConfig>,

    pub user: Signer<'info>,

    #[account(
        init_if_needed,
        payer = payer,
        associated_token::mint = tng_mint,
        associated_token::authority = user
    )]
    pub user_token_account: Account<'info, TokenAccount>,

    pub tng_mint: Account<'info, Mint>,

    #[account(mut)]
    pub payer: Signer<'info>, // sponsor

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(course_id: String)]
pub struct CloseCourse<'info> {
    #[account(
        mut,
        seeds = [b"course", course_id.as_bytes()],
        bump = course.bump
    )]
    pub course: Account<'info, Course>,

    pub creator: Signer<'info>,
}

// ============================================================================
// Account Structs
// ============================================================================

#[account]
pub struct LearnConfig {
    pub admin: Pubkey,
    pub total_courses: u64,
    pub total_rewards_distributed: u64,
    pub is_active: bool,
    pub bump: u8,
}

impl LearnConfig {
    pub const LEN: usize = 8 + 32 + 8 + 8 + 1 + 1;
}

#[account]
pub struct Course {
    pub course_id: String,
    pub title: String,
    pub description: String,
    pub creator: Pubkey,
    pub reward_amount: u64,
    pub total_completions: u64,
    pub is_active: bool,
    pub created_at: i64,
    pub bump: u8,
}

impl Course {
    pub const LEN: usize = 8 + (4 + 64) + (4 + 100) + (4 + 500) + 32 + 8 + 8 + 1 + 8 + 1; // course_id: String (64 max)
}

#[account]
pub struct UserCourse {
    pub user: Pubkey,
    pub course_id: String,
    pub answer_hash: String,
    pub is_completed: bool,
    pub completed_at: i64,
    pub is_reward_claimed: bool,
    pub claimed_at: Option<i64>,
    pub bump: u8,
}

impl UserCourse {
    pub const LEN: usize = 8 + 32 + (4 + 64) + (4 + 64) + 1 + 8 + 1 + (1 + 8) + 1; // course_id: String (64 max)
}

// ============================================================================
// Events
// ============================================================================

#[event]
pub struct CourseCreated {
    pub course_id: String,
    pub title: String,
    pub creator: Pubkey,
    pub reward_amount: u64,
    pub timestamp: i64,
}

#[event]
pub struct AnswerSubmitted {
    pub course_id: String,
    pub user: Pubkey,
    pub answer_hash: String,
    pub timestamp: i64,
}

#[event]
pub struct RewardClaimed {
    pub course_id: String,
    pub user: Pubkey,
    pub reward_amount: u64,
    pub timestamp: i64,
}

#[event]
pub struct CourseClosed {
    pub course_id: String,
    pub creator: Pubkey,
    pub timestamp: i64,
}

// ============================================================================
// Errors
// ============================================================================

#[error_code]
pub enum LearnError {
    #[msg("Title is too long (max 100 characters)")]
    TitleTooLong,
    
    #[msg("Description is too long (max 500 characters)")]
    DescriptionTooLong,
    
    #[msg("Invalid reward amount")]
    InvalidRewardAmount,
    
    #[msg("Course is not active")]
    CourseNotActive,
    
    #[msg("Course already completed by this user")]
    AlreadyCompleted,
    
    #[msg("Invalid answer hash")]
    InvalidAnswerHash,
    
    #[msg("Course not completed yet")]
    CourseNotCompleted,
    
    #[msg("Reward already claimed")]
    RewardAlreadyClaimed,
    
    #[msg("Not the course creator")]
    NotCourseCreator,
    
    #[msg("Course already exists")]
    CourseAlreadyExists,
}